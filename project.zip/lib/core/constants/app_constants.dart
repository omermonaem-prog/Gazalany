/// ثوابت التطبيق الأساسية
class AppConstants {
  AppConstants._();

  static const String appName = 'MyFinance';
  static const String appNameArabic = 'جزلاني';
  static const String appTagline = 'السيادة والرفاهية المالية';
  static const String defaultCurrency = 'SAR';
  static const String defaultCurrencySymbol = 'ر.س';

  // القيود المالية
  static const int minEmergencyMonthsCoverage = 3;
  static const int maxEmergencyMonthsCoverage = 6;
  static const int budgetWarningThresholdPercent = 70;
  static const int budgetCriticalThresholdPercent = 90;

  // الرسوم والحركات
  static const Duration defaultAnimationDuration = Duration(milliseconds: 300);
  static const Duration splashDelay = Duration(milliseconds: 1200);
}

