import 'package:flutter/material.dart';

/// رموز ألوان هوية Premium Fintech — Minimal Luxury
class AppColors {
  AppColors._();

  // الخلفيات والأسطح الفاتحة (Canvas & Surfaces - Light)
  static const Color canvasLight = Color(0xFFF8F6F0); // بيج كريمي دافئ
  static const Color surfaceLight = Color(0xFFFFFFFF); // أبيض لؤلؤي صافٍ
  static const Color surfaceSubtleLight = Color(0xFFF2EFE9); // كريمي ناعم للفواصل
  static const Color borderSubtleLight = Color(0xFFE5DFD3); // حدود البطاقات الناعمة
  static const Color borderGoldLight = Color(0xFFC5A059); // إطار ذهبي للبطاقات المميزة

  // ألوان الهوية والسيادة (Brand & Identity)
  static const Color forestGreen = Color(0xFF0E3B2E); // أخضر الغابة الداكن الملكي
  static const Color forestGreenLight = Color(0xFF165342); // أخضر زمردي تفاعلي
  static const Color champagneGold = Color(0xFFC5A059); // ذهب شامبين مطفي
  static const Color champagneGoldBright = Color(0xFFDFBC75); // بريق ذهبي ناعم
  static const Color sageSoft = Color(0xFF7A9B8D); // ميرمية هادئة للمؤشرات

  // الألوان المالية والوظيفية (Financial Functional)
  static const Color cashIn = Color(0xFF1B7A54); // أخضر مالي إيجابي (الدخل)
  static const Color cashOut = Color(0xFFA63A3A); // قرمزي نبيذي دافئ (المصروفات)
  static const Color warningAmber = Color(0xFFD9822B); // كهرمان تحذيري (70-90% ميزانية)
  static const Color criticalRed = Color(0xFF8C1D1D); // أحمر وقاري للطوارئ وتجاوز الحد
  static const Color slateMuted = Color(0xFF5E6D67); // رمادي رصاصي ناعم للنصوص الثانوية
  static const Color textMain = Color(0xFF141C18); // رصاصي فحمي داكن للنصوص الأساسية

  // وضع السكون الليلي الفاخر (Dark Luxury Mode)
  static const Color darkCanvas = Color(0xFF0A1410); // أردواز الغابة العميق
  static const Color darkSurface = Color(0xFF11201A); // زمرد داكن فاخر للبطاقات
  static const Color darkSubtle = Color(0xFF192D25); // سطح وسيط
  static const Color darkBorder = Color(0xFF233C32); // حدود البطاقات الداكنة
}

