import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'app_typography.dart';

/// إعدادات الثيم والواجهة لمشروع MyFinance
class AppTheme {
  AppTheme._();

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: AppColors.canvasLight,
      colorScheme: const ColorScheme.light(
        primary: AppColors.forestGreen,
        secondary: AppColors.champagneGold,
        surface: AppColors.surfaceLight,
        error: AppColors.criticalRed,
        onPrimary: Colors.white,
        onSecondary: AppColors.textMain,
        onSurface: AppColors.textMain,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: AppTypography.headingH2.copyWith(color: AppColors.forestGreen),
        iconTheme: const IconThemeData(color: AppColors.forestGreen),
      ),
      cardTheme: CardTheme(
        color: AppColors.surfaceLight,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: AppColors.borderSubtleLight, width: 1),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.forestGreen,
          foregroundColor: Colors.white,
          elevation: 2,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: AppColors.champagneGold, width: 1),
          ),
          textStyle: AppTypography.bodyPrimary.copyWith(
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.darkCanvas,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.champagneGold,
        secondary: AppColors.sageSoft,
        surface: AppColors.darkSurface,
        error: AppColors.criticalRed,
        onPrimary: AppColors.darkCanvas,
        onSecondary: Colors.white,
        onSurface: Colors.white,
      ),
      cardTheme: CardTheme(
        color: AppColors.darkSurface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: AppColors.darkBorder, width: 1),
        ),
      ),
    );
  }
}

