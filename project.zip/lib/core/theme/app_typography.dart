import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

/// منظومة الخطوط العربية المتوافقة مع هوية Minimal Luxury
class AppTypography {
  AppTypography._();

  static TextStyle get displayLarge => GoogleFonts.ibmPlexSansArabic(
        fontSize: 32,
        fontWeight: FontWeight.w700,
        height: 1.2,
        color: AppColors.textMain,
      );

  static TextStyle get headingH1 => GoogleFonts.ibmPlexSansArabic(
        fontSize: 24,
        fontWeight: FontWeight.w600,
        height: 1.3,
        color: AppColors.forestGreen,
      );

  static TextStyle get headingH2 => GoogleFonts.ibmPlexSansArabic(
        fontSize: 20,
        fontWeight: FontWeight.w600,
        height: 1.3,
        color: AppColors.textMain,
      );

  static TextStyle get headingH3 => GoogleFonts.ibmPlexSansArabic(
        fontSize: 17,
        fontWeight: FontWeight.w500,
        height: 1.4,
        color: AppColors.textMain,
      );

  static TextStyle get bodyPrimary => GoogleFonts.ibmPlexSansArabic(
        fontSize: 15,
        fontWeight: FontWeight.w400,
        height: 1.5,
        color: AppColors.textMain,
      );

  static TextStyle get bodySecondary => GoogleFonts.ibmPlexSansArabic(
        fontSize: 13,
        fontWeight: FontWeight.w400,
        height: 1.4,
        color: AppColors.slateMuted,
      );

  static TextStyle get financialNumberLarge => GoogleFonts.ibmPlexSansArabic(
        fontSize: 30,
        fontWeight: FontWeight.w700,
        height: 1.1,
        color: AppColors.champagneGoldBright,
      );

  static TextStyle get financialNumberMedium => GoogleFonts.ibmPlexSansArabic(
        fontSize: 18,
        fontWeight: FontWeight.w600,
        height: 1.2,
        color: AppColors.textMain,
      );
}


