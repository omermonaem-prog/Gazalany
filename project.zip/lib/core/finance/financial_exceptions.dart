/// الاستثناءات المالية المحددة لمحرك MyFinance المالي
abstract class FinancialException implements Exception {
  final String message;
  final String code;

  const FinancialException(this.message, {required this.code});

  @override
  String toString() => '[$code] $message';
}

/// رصيد غير كافٍ لإجراء العملية
class InsufficientFundsException extends FinancialException {
  final int availableMinorUnits;
  final int requiredMinorUnits;

  const InsufficientFundsException({
    required this.availableMinorUnits,
    required this.requiredMinorUnits,
    String? customMessage,
  }) : super(
          customMessage ??
              'الرصيد غير كافٍ: المتاح ($availableMinorUnits هللة) أقل من المطلوب ($requiredMinorUnits هللة)',
          code: 'INSUFFICIENT_FUNDS',
        );
}

/// العملية تم تنفيذها مسبقاً (منع تكرار العملية Idempotency)
class DuplicateTransactionException extends FinancialException {
  final String idempotencyKey;

  const DuplicateTransactionException(this.idempotencyKey)
      : super(
          'تم تنفيذ هذه العملية مسبقاً بمفتاح منع التكرار ($idempotencyKey)',
          code: 'DUPLICATE_TRANSACTION',
        );
}

/// قيد عدم السالبية مهدد بالاختراق
class NegativeBalanceForbiddenException extends FinancialException {
  final String accountId;
  final int projectedBalanceMinorUnits;

  const NegativeBalanceForbiddenException({
    required this.accountId,
    required this.projectedBalanceMinorUnits,
  }) : super(
          'قيد النزاهة المحاسبية: لا يمكن أن يصبح رصيد الحساب ($accountId) سالباً ($projectedBalanceMinorUnits)',
          code: 'NEGATIVE_BALANCE_FORBIDDEN',
        );
}

/// قواعد توزيع الدخل غير صالحة أو لا تطابق النسبة المحددة
class InvalidAllocationException extends FinancialException {
  const InvalidAllocationException(String details)
      : super(
          'خطأ في توزيع الدخل: $details',
          code: 'INVALID_ALLOCATION',
        );
}

/// محاولة توزيع الدخل دون تأكيد المستخدم المسبق
class UnconfirmedAllocationException extends FinancialException {
  const UnconfirmedAllocationException()
      : super(
          'قاعدة ملزمة: لا يمكن اعتماد توزيع الدخل قبل تأكيد ومعاينة المستخدم الصريحة',
          code: 'UNCONFIRMED_ALLOCATION',
        );
}

/// المعاملة قد تم عكسها بالفعل ولا يجوز عكسها مرتين
class TransactionAlreadyReversedException extends FinancialException {
  final String transactionId;

  const TransactionAlreadyReversedException(this.transactionId)
      : super(
          'المعاملة ($transactionId) تم عكسها مسبقاً ولا يمكن عكسها مرة أخرى',
          code: 'ALREADY_REVERSED',
        );
}

/// محاولة دمج أو مقارنة عملات مختلفة دون تحويل صريح
class CurrencyMismatchException extends FinancialException {
  final String expected;
  final String actual;

  const CurrencyMismatchException({
    required this.expected,
    required this.actual,
  }) : super(
          'تعارض في العملات: لا يمكن جمع أو مقارنة $actual مع $expected دون تحويل صرف صريح',
          code: 'CURRENCY_MISMATCH',
        );
}

/// الحساب المطلوب مؤرشف أو غير نشط
class AccountArchivedException extends FinancialException {
  final String accountId;

  const AccountArchivedException(this.accountId)
      : super(
          'الحساب ($accountId) مؤرشف ولا يمكن إجراء عمليات مالية جديدة عليه',
          code: 'ACCOUNT_ARCHIVED',
        );
}

/// كيان مالي غير موجود (حساب، هدف، دين...)
class EntityNotFoundException extends FinancialException {
  final String entityType;
  final String entityId;

  const EntityNotFoundException({
    required this.entityType,
    required this.entityId,
  }) : super(
          'لم يتم العثور على $entityType بالمعرف ($entityId)',
          code: 'ENTITY_NOT_FOUND',
        );
}

