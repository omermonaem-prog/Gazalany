import 'financial_exceptions.dart';

/// كائن القيمة المالية (Money Value Object)
///
/// يلتزم بالمعايير المحاسبية الصارمة:
/// 1. منع الأعداد العشرية العائمة (No IEEE 754 Floating-Points)
/// 2. التخزين بوحدات الهللة/السنت كأعداد صحيحة 64-bit (Minor Units)
/// 3. خوارزمية التوزيع الصفري بدقة الهللة (Largest Remainder Apportionment)
/// 4. التحقق التلقائي من تطابق العملات
class Money implements Comparable<Money> {
  final int minorUnits;
  final String currency;

  const Money.fromMinorUnits(this.minorUnits, [this.currency = 'SAR']);

  /// إنشاء من قيمة رئيسية (مثلاً 100.50 ر.س -> 10050 هللة)
  factory Money.fromMajorUnits(num majorUnits, [String currency = 'SAR']) {
    final minor = (majorUnits * 100).round();
    return Money.fromMinorUnits(minor, currency);
  }

  /// إنشاء مبلغ صفري
  const Money.zero([String currency = 'SAR']) : this.fromMinorUnits(0, currency);

  /// تحويل نص مالي إلى كائن Money
  factory Money.parse(String text, [String currency = 'SAR']) {
    final cleaned = text
        .replaceAll(RegExp(r'[^0-9.-]'), '')
        .trim();
    if (cleaned.isEmpty) {
      throw ArgumentError('نص مالي فارغ أو غير صالح: $text');
    }
    final parsed = double.tryParse(cleaned);
    if (parsed == null) {
      throw ArgumentError('تعذر تحليل المبلغ المالي: $text');
    }
    return Money.fromMajorUnits(parsed, currency);
  }

  // ── الخصائص الحسابية ──────────────────────────────────────────

  bool get isZero => minorUnits == 0;
  bool get isPositive => minorUnits > 0;
  bool get isNegative => minorUnits < 0;

  /// القيمة المطلقة للمبلغ
  Money abs() => Money.fromMinorUnits(minorUnits.abs(), currency);

  /// التحويل للوحدة الرئيسية (للعرض فقط — ليس للعمليات الحسابية)
  double toMajorUnits() => minorUnits / 100.0;

  // ── العمليات الحسابية والنزاهة ─────────────────────────────────

  void _assertSameCurrency(Money other) {
    if (currency != other.currency) {
      throw CurrencyMismatchException(
        expected: currency,
        actual: other.currency,
      );
    }
  }

  Money operator +(Money other) {
    _assertSameCurrency(other);
    return Money.fromMinorUnits(minorUnits + other.minorUnits, currency);
  }

  Money operator -(Money other) {
    _assertSameCurrency(other);
    return Money.fromMinorUnits(minorUnits - other.minorUnits, currency);
  }

  /// ضرب بعدد صحيح (تجنباً للأعداد العشرية العائمة)
  Money operator *(int factor) {
    return Money.fromMinorUnits(minorUnits * factor, currency);
  }

  /// نسبة بين مبلغين بنفس العملة
  double operator /(Money other) {
    _assertSameCurrency(other);
    if (other.minorUnits == 0) {
      throw ArgumentError('لا يمكن القسمة على مبلغ صفري');
    }
    return minorUnits / other.minorUnits;
  }

  Money operator -() {
    return Money.fromMinorUnits(-minorUnits, currency);
  }

  /// ضرب بنسبة مئوية محسوبة بنقاط الأساس (Basis Points: 100% = 10000)
  /// لضمان أقصى دقة وتجنب أي خطأ تقريب
  Money multiplyBasisPoints(int basisPoints) {
    final result = (minorUnits * basisPoints + 5000) ~/ 10000;
    return Money.fromMinorUnits(result, currency);
  }

  // ── خوارزمية التوزيع الصفري العادل (Largest Remainder Method) ──
  ///
  /// توزع مبلغاً إجمالياً على أوزان أو نسب محددة مع ضمان رياضي حاسم:
  /// مجموع المبالغ الموزعة = المبلغ الأصلي بالضبط دون زيادة أو نقصان هللة واحدة!
  static List<Money> apportion(Money total, List<int> weights) {
    if (weights.isEmpty) return [];
    final totalWeight = weights.fold<int>(0, (sum, w) => sum + w);
    if (totalWeight <= 0) {
      throw ArgumentError('مجموع الأوزان يجب أن يكون موجباً');
    }

    final totalMinor = total.minorUnits;
    final results = List<int>.filled(weights.length, 0);
    final remainders = List<int>.filled(weights.length, 0);

    var assignedTotal = 0;

    for (var i = 0; i < weights.length; i++) {
      final product = totalMinor * weights[i];
      final share = product ~/ totalWeight;
      results[i] = share;
      remainders[i] = product % totalWeight;
      assignedTotal += share;
    }

    // توزيع باقي الهللات على أصحاب أكبر كسر
    var remainderToDistribute = totalMinor - assignedTotal;
    
    // إنشاء مؤشرات مرتبة تنازلياً حسب قيمة الباقي
    final indices = List<int>.generate(weights.length, (i) => i);
    indices.sort((a, b) => remainders[b].compareTo(remainders[a]));

    for (var i = 0; i < remainderToDistribute; i++) {
      results[indices[i % indices.length]]++;
    }

    return results.map((m) => Money.fromMinorUnits(m, total.currency)).toList();
  }

  /// توزيع بنسب مئوية (مثلاً [50.0, 30.0, 20.0] تمثل 50%، 30%، 20%)
  static List<Money> apportionByPercentages(Money total, List<double> percentages) {
    // تحويل النسب إلى أوزان صحيحة دقيقة (مضروبة في 100 لتشمل منزلتين عشريتين)
    final weights = percentages.map((p) => (p * 100).round()).toList();
    return apportion(total, weights);
  }

  // ── المقارنات ────────────────────────────────────────────────

  @override
  int compareTo(Money other) {
    _assertSameCurrency(other);
    return minorUnits.compareTo(other.minorUnits);
  }

  bool operator <(Money other) => compareTo(other) < 0;
  bool operator <=(Money other) => compareTo(other) <= 0;
  bool operator >(Money other) => compareTo(other) > 0;
  bool operator >=(Money other) => compareTo(other) >= 0;

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Money &&
        other.minorUnits == minorUnits &&
        other.currency == currency;
  }

  @override
  int get hashCode => minorUnits.hashCode ^ currency.hashCode;

  // ── التنسيق والعرض ───────────────────────────────────────────

  /// تنسيق المبلغ بالعربية الفصحى (مثال: "1,250.75 ر.س")
  String formatArabic({bool includeSymbol = true}) {
    final major = minorUnits.abs() ~/ 100;
    final minor = minorUnits.abs() % 100;
    final sign = isNegative ? '-' : '';

    // إضافة فواصل الآلاف
    final majorStr = _formatWithThousandSeparators(major);
    final minorStr = minor.toString().padLeft(2, '0');

    final formattedNumber = '$sign$majorStr.$minorStr';
    if (!includeSymbol) return formattedNumber;

    final symbol = currency == 'SAR' ? 'ر.س' : currency;
    return '$formattedNumber $symbol';
  }

  /// تنسيق إنجليزي (مثال: "SAR 1,250.75")
  String formatEnglish({bool includeSymbol = true}) {
    final major = minorUnits.abs() ~/ 100;
    final minor = minorUnits.abs() % 100;
    final sign = isNegative ? '-' : '';

    final majorStr = _formatWithThousandSeparators(major);
    final minorStr = minor.toString().padLeft(2, '0');

    final formattedNumber = '$sign$majorStr.$minorStr';
    if (!includeSymbol) return formattedNumber;

    return '$currency $formattedNumber';
  }

  static String _formatWithThousandSeparators(int number) {
    final s = number.toString();
    final buffer = StringBuffer();
    var count = 0;
    for (var i = s.length - 1; i >= 0; i--) {
      buffer.write(s[i]);
      count++;
      if (count % 3 == 0 && i != 0) {
        buffer.write(',');
      }
    }
    return buffer.toString().split('').reversed.join();
  }

  @override
  String toString() => formatEnglish();
}

