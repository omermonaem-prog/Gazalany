import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';

enum LuxuryButtonType { primary, secondary, danger }

/// زر تفاعلي فاخر (Luxury Button)
class LuxuryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final LuxuryButtonType type;
  final bool isLoading;

  const LuxuryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.type = LuxuryButtonType.primary,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    Color bg;
    Color fg;
    BorderSide border;

    switch (type) {
      case LuxuryButtonType.primary:
        bg = AppColors.forestGreen;
        fg = Colors.white;
        border = const BorderSide(color: AppColors.champagneGold, width: 1);
        break;
      case LuxuryButtonType.secondary:
        bg = AppColors.surfaceSubtleLight;
        fg = AppColors.forestGreen;
        border = const BorderSide(color: AppColors.borderSubtleLight, width: 1);
        break;
      case LuxuryButtonType.danger:
        bg = AppColors.criticalRed;
        fg = Colors.white;
        border = const BorderSide(color: AppColors.criticalRed, width: 1);
        break;
    }

    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: bg,
          foregroundColor: fg,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: border,
          ),
          elevation: type == LuxuryButtonType.primary ? 2 : 0,
        ),
        child: isLoading
            ? SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2, color: fg),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[
                    Icon(icon, size: 18, color: fg),
                    const SizedBox(width: 8),
                  ],
                  Text(
                    label,
                    style: AppTypography.bodyPrimary.copyWith(
                      fontWeight: FontWeight.w600,
                      color: fg,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

