import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';

/// بطاقة صافي الثروة الذهبية الملكية (Hero Net Worth Card)
class NetWorthCard extends StatelessWidget {
  final double netWorth;
  final double monthlyChangePercentage;
  final String currencySymbol;
  final VoidCallback? onTap;

  const NetWorthCard({
    super.key,
    required this.netWorth,
    this.monthlyChangePercentage = 0.0,
    this.currencySymbol = 'ر.س',
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.forestGreen, AppColors.forestGreenLight],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.champagneGold, width: 1),
          boxShadow: [
            BoxShadow(
              color: AppColors.champagneGold.withValues(alpha: 0.18),
              blurRadius: 24,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'صافي الثروة الكلي',
                  style: AppTypography.bodySecondary.copyWith(
                    color: const Color(0xFFD2DCD7),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.lock_outline, size: 12, color: AppColors.champagneGoldBright),
                      const SizedBox(width: 4),
                      Text(
                        'مشفر محلياً',
                        style: AppTypography.bodySecondary.copyWith(
                          fontSize: 11,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  netWorth.toStringAsFixed(2),
                  style: AppTypography.financialNumberLarge,
                ),
                const SizedBox(width: 6),
                Text(
                  currencySymbol,
                  style: AppTypography.bodyPrimary.copyWith(
                    color: AppColors.champagneGoldBright,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                '▲ +${monthlyChangePercentage.toStringAsFixed(1)}% هذا الشهر • تحديث لحظي',
                style: AppTypography.bodySecondary.copyWith(
                  fontSize: 11,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

