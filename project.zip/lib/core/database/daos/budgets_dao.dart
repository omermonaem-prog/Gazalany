import 'package:drift/drift.dart';
import '../app_database.dart';

part 'budgets_dao.g.dart';

/// DAO الميزانيات الشهرية
@DriftAccessor(tables: [Budgets, Categories])
class BudgetsDao extends DatabaseAccessor<AppDatabase>
    with _$BudgetsDaoMixin {
  BudgetsDao(super.db);

  Stream<List<BudgetEntry>> watchBudgetsByMonth(String yearMonth) =>
      (select(budgets)
            ..where((b) => b.periodYearMonth.equals(yearMonth)))
          .watch();

  Future<BudgetEntry?> getBudgetForCategory(
          String categoryId, String yearMonth) =>
      (select(budgets)
            ..where((b) =>
                b.categoryId.equals(categoryId) &
                b.periodYearMonth.equals(yearMonth)))
          .getSingleOrNull();

  Future<void> upsertBudget(BudgetsCompanion entry) =>
      into(budgets).insertOnConflictUpdate(entry);

  Future<void> updateAllocated(
    String id,
    int newAllocatedMinorUnits,
  ) =>
      (update(budgets)..where((b) => b.id.equals(id))).write(
        BudgetsCompanion(
            allocatedMinorUnits: Value(newAllocatedMinorUnits)),
      );
}

