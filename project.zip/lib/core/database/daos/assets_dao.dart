import 'package:drift/drift.dart';
import '../app_database.dart';

part 'assets_dao.g.dart';

/// DAO الأصول الرأسمالية وصافي الثروة
@DriftAccessor(tables: [Assets])
class AssetsDao extends DatabaseAccessor<AppDatabase> with _$AssetsDaoMixin {
  AssetsDao(super.db);

  Stream<List<AssetEntry>> watchAllAssets() => select(assets).watch();

  Future<AssetEntry?> getAssetById(String id) =>
      (select(assets)..where((a) => a.id.equals(id))).getSingleOrNull();

  Future<void> insertAsset(AssetsCompanion entry) =>
      into(assets).insert(entry);

  Future<bool> updateAsset(AssetsCompanion entry) =>
      update(assets).replace(entry);

  /// مجموع القيمة السوقية الحالية لكل الأصول (بوحدة Minor Units)
  Future<int> getTotalMarketValueMinorUnits() async {
    final query = selectOnly(assets)
      ..addColumns([assets.currentMarketValueMinorUnits.sum()]);
    final result = await query.getSingle();
    return result.read(assets.currentMarketValueMinorUnits.sum()) ?? 0;
  }

  /// تحديث القيمة السوقية لأصل (إعادة تقييم)
  Future<void> revaluateAsset(
    String id,
    int newMarketValueMinorUnits,
  ) =>
      (update(assets)..where((a) => a.id.equals(id))).write(
        AssetsCompanion(
          currentMarketValueMinorUnits: Value(newMarketValueMinorUnits),
          lastValuationDate: Value(DateTime.now()),
        ),
      );
}

