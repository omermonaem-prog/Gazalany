// GENERATED CODE - DO NOT MODIFY BY HAND
// ملاحظة: هذا الملف يُولَّد تلقائياً بتشغيل:
//   flutter pub run build_runner build --delete-conflicting-outputs
//
// في بيئة الاختبار نستخدم NativeDatabase.memory() مباشرة مع AppDatabase
// بدون الحاجة لكود مولَّد مسبقاً، إذ يوفره Drift وقت الاختبار ذاتياً.

