import 'package:drift/drift.dart' show Value;
import '../app_database.dart';
import '../daos/accounts_dao.dart';
import '../daos/transactions_dao.dart';

/// محرك المعاملات الذرية المالية — الضامن الأعلى للنزاهة المحاسبية
///
/// القاعدة: أي عملية تمسّ أكثر من جدول في آنٍ واحد
/// (تحويل، توزيع راتب، سداد قسط دين…) يجب أن تمر بهذا المحرك
/// الذي يلفّها في `db.transaction()` فإذا فشلت أي خطوة
/// تراجع SQLite كل القيود ذراعياً (Atomic Rollback).
class FinancialTransactionEngine {
  final AppDatabase _db;

  FinancialTransactionEngine(this._db);

  /// ── تحويل داخلي بين محفظتين ─────────────────────────────────
  /// المعادلة المحاسبية: Δ Source + Δ Destination = 0
  Future<void> executeInternalTransfer({
    required String txnId,
    required String fromAccountId,
    required String toAccountId,
    required int amountMinorUnits,
    required DateTime date,
    String? note,
  }) async {
    assert(amountMinorUnits > 0, 'مبلغ التحويل يجب أن يكون موجباً');
    assert(fromAccountId != toAccountId, 'لا يمكن التحويل من وإلى نفس الحساب');

    await _db.transaction(() async {
      final accountsDao = _db.accountsDao;
      final txnDao = _db.transactionsDao;

      // 1. التحقق من كفاية الرصيد
      final source = await accountsDao.getAccountById(fromAccountId);
      if (source == null) throw ArgumentError('الحساب المصدر غير موجود');
      if (source.balanceMinorUnits < amountMinorUnits) {
        throw ArgumentError(
          'الرصيد غير كافٍ: المتاح ${source.balanceMinorUnits} < المطلوب $amountMinorUnits',
        );
      }

      // 2. تسجيل قيد المعاملة الواحد (نوع transfer)
      await txnDao.insertTransaction(TransactionsCompanion.insert(
        id: txnId,
        accountId: fromAccountId,
        destinationAccountId: Value(toAccountId),
        type: 'transfer',
        amountMinorUnits: amountMinorUnits,
        transactionDate: date,
        note: Value(note),
        createdAt: DateTime.now(),
      ));

      // 3. تحديث الرصيدين ذرياً
      await accountsDao.updateBalance(
        fromAccountId,
        source.balanceMinorUnits - amountMinorUnits,
      );
      final dest = await accountsDao.getAccountById(toAccountId);
      if (dest == null) throw ArgumentError('الحساب الوجهة غير موجود');
      await accountsDao.updateBalance(
        toAccountId,
        dest.balanceMinorUnits + amountMinorUnits,
      );
    });
  }

  /// ── تسجيل مصروف وخصمه من الميزانية ─────────────────────────
  Future<void> executeExpense({
    required String txnId,
    required String accountId,
    required String? categoryId,
    required int amountMinorUnits,
    required DateTime date,
    String? note,
    String? receiptImagePath,
  }) async {
    assert(amountMinorUnits > 0, 'مبلغ المصروف يجب أن يكون موجباً');

    await _db.transaction(() async {
      final accountsDao = _db.accountsDao;
      final txnDao = _db.transactionsDao;

      final account = await accountsDao.getAccountById(accountId);
      if (account == null) throw ArgumentError('الحساب غير موجود');
      if (account.balanceMinorUnits < amountMinorUnits) {
        throw ArgumentError('رصيد غير كافٍ لإتمام المصروف');
      }

      await txnDao.insertTransaction(TransactionsCompanion.insert(
        id: txnId,
        accountId: accountId,
        categoryId: Value(categoryId),
        type: 'expense',
        amountMinorUnits: amountMinorUnits,
        transactionDate: date,
        note: Value(note),
        receiptImagePath: Value(receiptImagePath),
        createdAt: DateTime.now(),
      ));

      await accountsDao.updateBalance(
        accountId,
        account.balanceMinorUnits - amountMinorUnits,
      );
    });
  }

  /// ── إيداع الدخل / الراتب ─────────────────────────────────────
  Future<void> executeIncomeDeposit({
    required String txnId,
    required String accountId,
    required String? categoryId,
    required int amountMinorUnits,
    required DateTime date,
    String? note,
  }) async {
    assert(amountMinorUnits > 0, 'مبلغ الدخل يجب أن يكون موجباً');

    await _db.transaction(() async {
      final accountsDao = _db.accountsDao;
      final txnDao = _db.transactionsDao;

      final account = await accountsDao.getAccountById(accountId);
      if (account == null) throw ArgumentError('الحساب المستقبل غير موجود');

      await txnDao.insertTransaction(TransactionsCompanion.insert(
        id: txnId,
        accountId: accountId,
        categoryId: Value(categoryId),
        type: 'income',
        amountMinorUnits: amountMinorUnits,
        transactionDate: date,
        note: Value(note),
        createdAt: DateTime.now(),
      ));

      await accountsDao.updateBalance(
        accountId,
        account.balanceMinorUnits + amountMinorUnits,
      );
    });
  }

  /// ── سداد قسط دين ─────────────────────────────────────────────
  Future<void> executeDebtPayment({
    required String paymentId,
    required String txnId,
    required String debtId,
    required String fromAccountId,
    required int amountMinorUnits,
    required DateTime date,
    String? note,
  }) async {
    await _db.transaction(() async {
      final accountsDao = _db.accountsDao;
      final txnDao = _db.transactionsDao;
      final debtsDao = _db.debtsDao;

      final account = await accountsDao.getAccountById(fromAccountId);
      if (account == null) throw ArgumentError('الحساب غير موجود');
      if (account.balanceMinorUnits < amountMinorUnits) {
        throw ArgumentError('رصيد غير كافٍ لسداد القسط');
      }

      // 1. تسجيل المعاملة
      await txnDao.insertTransaction(TransactionsCompanion.insert(
        id: txnId,
        accountId: fromAccountId,
        type: 'expense',
        amountMinorUnits: amountMinorUnits,
        transactionDate: date,
        note: Value(note ?? 'سداد قسط دين'),
        createdAt: DateTime.now(),
      ));

      // 2. خصم من الحساب
      await accountsDao.updateBalance(
        fromAccountId,
        account.balanceMinorUnits - amountMinorUnits,
      );

      // 3. تخفيض رصيد الدين المتبقي (يرفع صافي الثروة تلقائياً)
      await debtsDao.applyPayment(debtId, amountMinorUnits);

      // 4. تسجيل دفعة الدين في سجلها المستقل
      await debtsDao.insertDebtPayment(DebtPaymentsCompanion.insert(
        id: paymentId,
        debtId: debtId,
        accountId: fromAccountId,
        amountMinorUnits: amountMinorUnits,
        paymentDate: date,
        note: Value(note),
      ));
    });
  }
}

