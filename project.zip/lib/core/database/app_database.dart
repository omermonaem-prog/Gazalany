import 'package:drift/drift.dart';

import 'daos/accounts_dao.dart';
import 'daos/assets_dao.dart';
import 'daos/budgets_dao.dart';
import 'daos/debts_dao.dart';
import 'daos/emergency_fund_dao.dart';
import 'daos/goals_dao.dart';
import 'daos/obligations_dao.dart';
import 'daos/transactions_dao.dart';

export 'daos/accounts_dao.dart';
export 'daos/assets_dao.dart';
export 'daos/budgets_dao.dart';
export 'daos/debts_dao.dart';
export 'daos/emergency_fund_dao.dart';
export 'daos/goals_dao.dart';
export 'daos/obligations_dao.dart';
export 'daos/transactions_dao.dart';

part 'app_database.g.dart';

// ==========================================
// 1. جدول الحسابات والمحافظ (Accounts)
// ==========================================
@DataClassName('AccountEntry')
class Accounts extends Table {
  TextColumn get id => text()();
  TextColumn get name => text().withLength(min: 1, max: 100)();
  TextColumn get type => text()(); // 'bank', 'cash', 'e_wallet', 'vault'
  TextColumn get currency => text().withDefault(const Constant('SAR'))();
  IntColumn get balanceMinorUnits =>
      integer().withDefault(const Constant(0))();
  BoolColumn get isArchived =>
      boolean().withDefault(const Constant(false))();
  TextColumn get colorHex => text()();
  TextColumn get iconName => text()();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

// ==========================================
// 2. جدول التصنيفات (Categories)
// ==========================================
@DataClassName('CategoryEntry')
class Categories extends Table {
  TextColumn get id => text()();
  TextColumn get parentId => text()
      .nullable()
      .references(Categories, #id, onDelete: KeyAction.setNull)();
  TextColumn get name => text().withLength(min: 1, max: 100)();
  TextColumn get iconName => text()();
  TextColumn get colorHex => text()();
  BoolColumn get isIncome =>
      boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

// ==========================================
// 3. جدول الميزانيات الشهرية (Budgets)
// ==========================================
@DataClassName('BudgetEntry')
class Budgets extends Table {
  TextColumn get id => text()();
  TextColumn get categoryId =>
      text().references(Categories, #id, onDelete: KeyAction.cascade)();
  TextColumn get periodYearMonth => text()(); // '2026-10'
  IntColumn get allocatedMinorUnits => integer()();
  IntColumn get warningThresholdPercent =>
      integer().withDefault(const Constant(80))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};

  @override
  List<Set<Column>> get uniqueKeys => [
        {categoryId, periodYearMonth}
      ];
}

// ==========================================
// 4. جدول المعاملات المالية (Transactions)
// ==========================================
@DataClassName('TransactionEntry')
class Transactions extends Table {
  TextColumn get id => text()();
  TextColumn get accountId =>
      text().references(Accounts, #id, onDelete: KeyAction.restrict)();
  TextColumn get categoryId => text()
      .nullable()
      .references(Categories, #id, onDelete: KeyAction.setNull)();
  TextColumn get destinationAccountId => text()
      .nullable()
      .references(Accounts, #id, onDelete: KeyAction.setNull)();
  TextColumn get type =>
      text()(); // 'expense', 'income', 'transfer', 'reconciliation'
  IntColumn get amountMinorUnits => integer()();
  DateTimeColumn get transactionDate => dateTime()();
  TextColumn get note => text().nullable()();
  TextColumn get receiptImagePath => text().nullable()();
  BoolColumn get isDeleted =>
      boolean().withDefault(const Constant(false))();
  DateTimeColumn get deletedAt => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

// ==========================================
// 5. قواعد توزيع الدخل (Income Allocation Rules)
// ==========================================
@DataClassName('IncomeAllocationRuleEntry')
class IncomeAllocationRules extends Table {
  TextColumn get id => text()();
  TextColumn get title => text()();
  TextColumn get targetType =>
      text()(); // 'emergency_fund', 'goal', 'obligation', 'budget'
  TextColumn get targetId => text()();
  TextColumn get allocationMode =>
      text()(); // 'percentage', 'fixed_amount'
  RealColumn get valueNumeric => real()();
  IntColumn get priorityOrder => integer()();
  BoolColumn get isActive =>
      boolean().withDefault(const Constant(true))();

  @override
  Set<Column> get primaryKey => {id};
}

// ==========================================
// 6. الالتزامات والفواتير (Obligations)
// ==========================================
@DataClassName('ObligationEntry')
class Obligations extends Table {
  TextColumn get id => text()();
  TextColumn get title => text()();
  TextColumn get billerName => text().nullable()();
  IntColumn get amountMinorUnits => integer()();
  TextColumn get recurrenceType =>
      text()(); // 'monthly', 'quarterly', 'yearly', 'weekly'
  IntColumn get dueDayOfMonth => integer()();
  TextColumn get linkedAccountId => text()
      .nullable()
      .references(Accounts, #id, onDelete: KeyAction.setNull)();
  BoolColumn get isLockedFromSalary =>
      boolean().withDefault(const Constant(true))();
  BoolColumn get isActive =>
      boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

// ==========================================
// 7. صندوق الطوارئ (Emergency Fund)
// ==========================================
@DataClassName('EmergencyFundConfigEntry')
class EmergencyFundConfig extends Table {
  TextColumn get id =>
      text().withDefault(const Constant('primary_fund'))();
  IntColumn get targetMinorUnits => integer()();
  IntColumn get currentMinorUnits =>
      integer().withDefault(const Constant(0))();
  IntColumn get targetMonthsCoverage =>
      integer().withDefault(const Constant(3))();
  DateTimeColumn get lastWithdrawalDate => dateTime().nullable()();
  BoolColumn get compensationPlanActive =>
      boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
}

@DataClassName('EmergencyWithdrawalEntry')
class EmergencyWithdrawals extends Table {
  TextColumn get id => text()();
  IntColumn get amountMinorUnits => integer()();
  TextColumn get reason => text()();
  TextColumn get compensationPlanNotes => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

// ==========================================
// 8. الأهداف المالية (Goals)
// ==========================================
@DataClassName('GoalEntry')
class Goals extends Table {
  TextColumn get id => text()();
  TextColumn get title => text()();
  IntColumn get targetMinorUnits => integer()();
  IntColumn get savedMinorUnits =>
      integer().withDefault(const Constant(0))();
  DateTimeColumn get targetDate => dateTime().nullable()();
  TextColumn get status =>
      text().withDefault(const Constant('active'))();
  TextColumn get iconName => text()();
  TextColumn get colorHex => text()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

// ==========================================
// 9. الديون والأقساط (Debts & Payments)
// ==========================================
@DataClassName('DebtEntry')
class Debts extends Table {
  TextColumn get id => text()();
  TextColumn get title => text()();
  TextColumn get counterpartyName => text()();
  TextColumn get type => text()(); // 'payable', 'receivable'
  IntColumn get totalMinorUnits => integer()();
  IntColumn get remainingMinorUnits => integer()();
  IntColumn get monthlyInstallmentMinorUnits => integer().nullable()();
  DateTimeColumn get startDate => dateTime()();
  DateTimeColumn get dueDate => dateTime().nullable()();
  TextColumn get status =>
      text().withDefault(const Constant('active'))();

  @override
  Set<Column> get primaryKey => {id};
}

@DataClassName('DebtPaymentEntry')
class DebtPayments extends Table {
  TextColumn get id => text()();
  TextColumn get debtId =>
      text().references(Debts, #id, onDelete: KeyAction.cascade)();
  TextColumn get accountId =>
      text().references(Accounts, #id, onDelete: KeyAction.restrict)();
  IntColumn get amountMinorUnits => integer()();
  DateTimeColumn get paymentDate => dateTime()();
  TextColumn get note => text().nullable()();

  @override
  Set<Column> get primaryKey => {id};
}

// ==========================================
// 10. الأصول الرأسمالية (Assets)
// ==========================================
@DataClassName('AssetEntry')
class Assets extends Table {
  TextColumn get id => text()();
  TextColumn get title => text()();
  TextColumn get category =>
      text()(); // 'real_estate', 'vehicle', 'gold', 'stocks', 'other'
  IntColumn get purchaseCostMinorUnits => integer()();
  IntColumn get currentMarketValueMinorUnits => integer()();
  DateTimeColumn get purchaseDate => dateTime()();
  DateTimeColumn get lastValuationDate => dateTime()();
  TextColumn get notes => text().nullable()();

  @override
  Set<Column> get primaryKey => {id};
}

// ==========================================
// قاعدة البيانات المركزية (AppDatabase)
// ==========================================
@DriftDatabase(
  tables: [
    Accounts,
    Categories,
    Budgets,
    Transactions,
    IncomeAllocationRules,
    Obligations,
    EmergencyFundConfig,
    EmergencyWithdrawals,
    Goals,
    Debts,
    DebtPayments,
    Assets,
  ],
  daos: [
    AccountsDao,
    TransactionsDao,
    BudgetsDao,
    GoalsDao,
    DebtsDao,
    AssetsDao,
    EmergencyFundDao,
    ObligationsDao,
  ],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase(super.e);

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (Migrator m) async {
          await m.createAll();
          // الفهارس المخصصة لسرعة الاستعلامات اللحظية
          await customStatement(
              'CREATE INDEX IF NOT EXISTS idx_txn_account  ON transactions(account_id);');
          await customStatement(
              'CREATE INDEX IF NOT EXISTS idx_txn_date     ON transactions(transaction_date);');
          await customStatement(
              'CREATE INDEX IF NOT EXISTS idx_txn_category ON transactions(category_id);');
          await customStatement(
              'CREATE INDEX IF NOT EXISTS idx_budget_period ON budgets(period_year_month);');
          await customStatement(
              'CREATE INDEX IF NOT EXISTS idx_debt_status   ON debts(status);');
        },
        onUpgrade: (Migrator m, int from, int to) async {
          // ترقية آمنة لا تفقد بيانات المستخدم — تُضاف Migrations هنا مستقبلاً
          // مثال للإصدار 2: await m.addColumn(accounts, accounts.someNewColumn);
        },
        beforeOpen: (details) async {
          // إلزامي: تفعيل المفاتيح الخارجية في SQLite
          await customStatement('PRAGMA foreign_keys = ON;');
        },
      );
}
