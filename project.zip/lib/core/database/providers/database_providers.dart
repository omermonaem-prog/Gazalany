import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../app_database.dart';
import '../connection/open_connection.dart';

/// مزود قاعدة البيانات الوحيد — Singleton عبر كل التطبيق
final databaseProvider = Provider<AppDatabase>((ref) {
  final db = AppDatabase(openDatabaseConnection());
  ref.onDispose(db.close);
  return db;
});

// ── مزودو الـ DAOs (وصول مباشر من أي Notifier) ──────────

final accountsDaoProvider = Provider<AccountsDao>(
  (ref) => ref.watch(databaseProvider).accountsDao,
);

final transactionsDaoProvider = Provider<TransactionsDao>(
  (ref) => ref.watch(databaseProvider).transactionsDao,
);

final budgetsDaoProvider = Provider<BudgetsDao>(
  (ref) => ref.watch(databaseProvider).budgetsDao,
);

final goalsDaoProvider = Provider<GoalsDao>(
  (ref) => ref.watch(databaseProvider).goalsDao,
);

final debtsDaoProvider = Provider<DebtsDao>(
  (ref) => ref.watch(databaseProvider).debtsDao,
);

final assetsDaoProvider = Provider<AssetsDao>(
  (ref) => ref.watch(databaseProvider).assetsDao,
);

final emergencyFundDaoProvider = Provider<EmergencyFundDao>(
  (ref) => ref.watch(databaseProvider).emergencyFundDao,
);

final obligationsDaoProvider = Provider<ObligationsDao>(
  (ref) => ref.watch(databaseProvider).obligationsDao,
);

