import 'package:flutter/material.dart';

/// خيارات مصير الفائض المالي عند إغلاق الشهر (وفق النظام 05 والقواعد الصارمة)
enum SurplusAction {
  /// 1. ترحيل الفائض للشهر التالي في نفس الميزانية
  rollover,

  /// 2. إعادته للسيولة العامة المتاحة للإنفاق
  returnToLiquidity,

  /// 3. إضافته للادخار العام
  addToSavings,

  /// 4. تخصيصه لهدف مالي لتقريب إنجازه
  allocateToGoal,

  /// 5. تحويله لصندوق الطوارئ لتعزيز ملاذ الأمان
  transferToEmergency;

  String get labelArabic {
    switch (this) {
      case SurplusAction.rollover:
        return 'ترحيل للشهر القادم';
      case SurplusAction.returnToLiquidity:
        return 'إعادة للسيولة المتاحة';
      case SurplusAction.addToSavings:
        return 'إضافة للادخار العام';
      case SurplusAction.allocateToGoal:
        return 'تخصيص لهدف ادخاري';
      case SurplusAction.transferToEmergency:
        return 'صب في صندوق الطوارئ';
    }
  }

  String get descriptionArabic {
    switch (this) {
      case SurplusAction.rollover:
        return 'ينقل الفائض كرصيد افتتاحي إضافي لنفس الميزانية في الشهر التالي';
      case SurplusAction.returnToLiquidity:
        return 'يتحرر المبلغ ليصبح ضمن السيولة المرنة المتاحة للإنفاق العام';
      case SurplusAction.addToSavings:
        return 'يعزز محفظة الادخار العام الاستثماري طويل الأجل';
      case SurplusAction.allocateToGoal:
        return 'يُحجز المبلغ لصالح أحد أهدافك النشطة لتسريع تحقيقه';
      case SurplusAction.transferToEmergency:
        return 'يغذي صندوق الطوارئ المعزول لحين اكتمال تغطية الأشهر المستهدفة';
    }
  }

  IconData get icon {
    switch (this) {
      case SurplusAction.rollover:
        return Icons.arrow_forward_ios;
      case SurplusAction.returnToLiquidity:
        return Icons.water_drop_outlined;
      case SurplusAction.addToSavings:
        return Icons.savings_outlined;
      case SurplusAction.allocateToGoal:
        return Icons.flag_outlined;
      case SurplusAction.transferToEmergency:
        return Icons.shield_outlined;
    }
  }
}

