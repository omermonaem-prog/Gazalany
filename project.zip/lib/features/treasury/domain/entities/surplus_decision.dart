import '../../../../core/finance/money.dart';
import 'surplus_action.dart';

/// قرار المستخدم اليدوي بشأن فائض ميزانية محددة
class SurplusDecision {
  final String categoryId;
  final String categoryName;
  final Money surplusAmount;
  final SurplusAction action;
  final String? targetGoalId;
  final String? targetGoalTitle;
  final String? notes;

  const SurplusDecision({
    required this.categoryId,
    required this.categoryName,
    required this.surplusAmount,
    this.action = SurplusAction.rollover,
    this.targetGoalId,
    this.targetGoalTitle,
    this.notes,
  });

  SurplusDecision copyWith({
    String? categoryId,
    String? categoryName,
    Money? surplusAmount,
    SurplusAction? action,
    String? targetGoalId,
    String? targetGoalTitle,
    String? notes,
  }) {
    return SurplusDecision(
      categoryId: categoryId ?? this.categoryId,
      categoryName: categoryName ?? this.categoryName,
      surplusAmount: surplusAmount ?? this.surplusAmount,
      action: action ?? this.action,
      targetGoalId: targetGoalId ?? this.targetGoalId,
      targetGoalTitle: targetGoalTitle ?? this.targetGoalTitle,
      notes: notes ?? this.notes,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is SurplusDecision &&
        other.categoryId == categoryId &&
        other.surplusAmount == surplusAmount &&
        other.action == action &&
        other.targetGoalId == targetGoalId;
  }

  @override
  int get hashCode =>
      categoryId.hashCode ^
      surplusAmount.hashCode ^
      action.hashCode ^
      targetGoalId.hashCode;
}

