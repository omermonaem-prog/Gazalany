import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_finance/core/database/providers/database_providers.dart';
import 'package:my_finance/core/finance/money.dart';
import '../../financial_engine/application/central_financial_engine.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import '../../financial_engine/presentation/providers/financial_engine_providers.dart';
import '../../expenses_budgets/application/expenses_budgets_controller.dart';
import '../data/repositories/treasury_repository_impl.dart';
import '../domain/entities/closed_month_record.dart';
import '../domain/entities/surplus_action.dart';
import '../domain/entities/surplus_decision.dart';
import '../domain/repositories/treasury_repository.dart';
import 'treasury_state.dart';

/// موفر مستودع الخزينة
final treasuryRepositoryProvider = Provider<TreasuryRepository>((ref) {
  final db = ref.watch(databaseProvider);
  return TreasuryRepositoryImpl(db);
});

/// موفر متحكم الخزينة وإغلاق الشهر
final treasuryControllerProvider =
    StateNotifierProvider<TreasuryController, TreasuryState>((ref) {
  final engine = ref.watch(centralFinancialEngineProvider);
  final repo = ref.watch(treasuryRepositoryProvider);
  return TreasuryController(engine: engine, repository: repo, ref: ref);
});

/// المتحكم المسؤول عن الخزينة الموحدة، التحويلات، وإغلاق الشهر المالي
class TreasuryController extends StateNotifier<TreasuryState> {
  final CentralFinancialEngine _engine;
  final TreasuryRepository _repository;
  final Ref? _ref;

  TreasuryController({
    required CentralFinancialEngine engine,
    required TreasuryRepository repository,
    Ref? ref,
  })  : _engine = engine,
        _repository = repository,
        _ref = ref,
        super(const TreasuryState()) {
    loadTreasuryData();
  }

  /// تحميل لقطة الخزينة الموحدة وسجل الأشهر المغلقة
  Future<void> loadTreasuryData() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final snapshot = await _repository.getTreasurySnapshot();
      final closedMonths = await _repository.getAllClosedMonthRecords();

      state = state.copyWith(
        isLoading: false,
        snapshot: snapshot,
        closedMonths: closedMonths,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'تعذر تحميل بيانات الخزينة: $e',
      );
    }
  }

  /// ── المرحلة 1: تحضير ملخص إغلاق الشهر واستخراج فوائض الميزانيات ──
  Future<void> loadMonthEndSummary(String periodYearMonth) async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final summary = await _repository.getMonthEndSummary(periodYearMonth);

      // تجهيز القرارات الافتراضية لكل تصنيف به فائض
      final decisionsMap = <String, SurplusDecision>{};
      for (final s in summary.budgetSurpluses) {
        decisionsMap[s.categoryId] = s;
      }

      state = state.copyWith(
        isLoading: false,
        activeMonthSummary: summary,
        userDecisions: decisionsMap,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'تعذر تحميل ملخص إغلاق الشهر: $e',
      );
    }
  }

  /// تحديث قرار المستخدم لمصير فائض ميزانية معينة
  void updateSurplusDecision(SurplusDecision decision) {
    final updated = Map<String, SurplusDecision>.from(state.userDecisions);
    updated[decision.categoryId] = decision;
    state = state.copyWith(userDecisions: updated);
  }

  /// إلغاء عملية الإغلاق دون تطبيق أي تغيير
  void cancelClosing() {
    state = state.copyWith(
      clearActiveMonthSummary: true,
      userDecisions: const {},
      clearError: true,
    );
  }

  /// حساب الشهر التالي بصيغة 'YYYY-MM'
  static String getNextYearMonth(String currentYM) {
    final parts = currentYM.split('-');
    var year = int.parse(parts[0]);
    var month = int.parse(parts[1]);

    if (month == 12) {
      year += 1;
      month = 1;
    } else {
      month += 1;
    }
    return '$year-${month.toString().padLeft(2, '0')}';
  }

  /// ── المرحلة 2: تأكيد واعتماد إغلاق الشهر المالي ──
  ///
  /// القواعد:
  /// 1. تنفيذ القرار الذي اختاره المستخدم فقط (ترحيل، ادخار، طوارئ، أهداف، سيولة).
  /// 2. منع إغلاق الشهر مرتين (No Double Close).
  /// 3. تسجيل عملية الإغلاق والقرارات التي اتخذها المستخدم.
  /// 4. التحويل الداخلي لا يغير إجمالي الأموال.
  Future<bool> confirmAndExecuteMonthEndClosing({
    required String periodYearMonth,
    String? defaultAccountId,
    String? notes,
    required String idempotencyKey,
  }) async {
    if (state.isClosingMonth) return false;

    // 1. حظر الإغلاق المزدوج
    final alreadyClosed = await _repository.isMonthClosed(periodYearMonth);
    if (alreadyClosed) {
      state = state.copyWith(
        errorMessage: 'الشهر ($periodYearMonth) مغلق مسبقاً ولا يجوز إغلاقه مرتين',
      );
      return false;
    }

    final summary = state.activeMonthSummary;
    if (summary == null || summary.periodYearMonth != periodYearMonth) {
      state = state.copyWith(errorMessage: 'بيانات ملخص الإغلاق غير متطابقة');
      return false;
    }

    state = state.copyWith(isClosingMonth: true, clearError: true);

    try {
      final nextYM = getNextYearMonth(periodYearMonth);
      final executedDecisions = <SurplusDecision>[];
      final accId = defaultAccountId ??
          (state.snapshot?.accounts.isNotEmpty == true
              ? state.snapshot!.accounts.first.id
              : 'acc_main');

      // 2. تنفيذ القرارات التي حددها المستخدم لكل فائض
      for (final entry in state.userDecisions.entries) {
        final decision = entry.value;
        if (!decision.surplusAmount.isPositive) continue;

        switch (decision.action) {
          case SurplusAction.rollover:
            // أ) ترحيل للشهر التالي في نفس الميزانية
            if (_ref != null) {
              await _ref.read(expensesBudgetsControllerProvider.notifier).createOrUpdateBudget(
                    categoryId: decision.categoryId,
                    allocatedAmount: decision.surplusAmount,
                    periodYearMonth: nextYM,
                  );
            }
            break;

          case SurplusAction.returnToLiquidity:
            // ب) إعادته للسيولة العامة (يظل متاحاً دون حجز)
            break;

          case SurplusAction.addToSavings:
            // ج) إضافته للادخار العام
            final currentSavings = await _repository.getGeneralSavingsBalance();
            await _repository.updateGeneralSavingsBalance(currentSavings + decision.surplusAmount);
            break;

          case SurplusAction.allocateToGoal:
            // د) تخصيصه لهدف ادخاري محدد
            if (decision.targetGoalId != null) {
              await _engine.allocateToGoal(
                transactionId: 'close_${periodYearMonth}_goal_${decision.categoryId}',
                fromAccountId: accId,
                goalId: decision.targetGoalId!,
                amount: decision.surplusAmount,
                date: DateTime.now(),
                note: 'توجيه فائض شهر $periodYearMonth للهدف',
                idempotencyKey: '${idempotencyKey}_goal_${decision.categoryId}',
              );
            }
            break;

          case SurplusAction.transferToEmergency:
            // هـ) تحويله لصندوق الطوارئ
            final currentEF = await _engine.repository.getEmergencyFundBalance();
            await _engine.repository.updateEmergencyFundBalance(currentEF + decision.surplusAmount);
            break;
        }

        executedDecisions.add(decision);
      }

      // 3. توثيق وتسجيل إغلاق الشهر في الأرشيف
      final record = ClosedMonthRecord(
        id: 'closed_$periodYearMonth',
        periodYearMonth: periodYearMonth,
        closedAt: DateTime.now(),
        totalIncome: summary.totalIncome,
        totalExpenses: summary.totalExpenses,
        totalSurplus: summary.totalSurplus,
        decisions: executedDecisions,
        notes: notes,
        idempotencyKey: idempotencyKey,
      );

      await _repository.saveClosedMonthRecord(record);

      // 4. تحديث البيانات وحالة الخزينة
      await loadTreasuryData();

      state = state.copyWith(
        isClosingMonth: false,
        clearActiveMonthSummary: true,
        userDecisions: const {},
        successMessage: 'تم إغلاق شهر $periodYearMonth بنجاح وتنفيذ كافة قرارات الفائض',
      );

      return true;
    } catch (e) {
      state = state.copyWith(
        isClosingMonth: false,
        errorMessage: 'فشل إغلاق الشهر المالي: $e',
      );
      return false;
    }
  }

  /// ── المرحلة 3: تنفيذ تحويل داخلي ذري بين الحسابات ──
  ///
  /// القيد الصارم: التحويل الداخلي لا يغير إجمالي الأموال إطلاقاً
  Future<bool> executeInternalTransfer({
    required String fromAccountId,
    required String toAccountId,
    required Money amount,
    String? note,
    required String idempotencyKey,
  }) async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final txnId = 'trx_${DateTime.now().millisecondsSinceEpoch}';

      await _engine.transfer(
        transactionId: txnId,
        fromAccountId: fromAccountId,
        toAccountId: toAccountId,
        amount: amount,
        date: DateTime.now(),
        note: note,
        idempotencyKey: idempotencyKey,
      );

      await loadTreasuryData();

      state = state.copyWith(
        isLoading: false,
        successMessage: 'تم التحويل الداخلي بنجاح دون المساس بإجمالي الأموال',
      );
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل التحويل الداخلي: $e',
      );
      return false;
    }
  }

  void clearMessages() {
    state = state.copyWith(clearError: true, clearSuccess: true);
  }
}

