import '../domain/entities/closed_month_record.dart';
import '../domain/entities/month_end_summary.dart';
import '../domain/entities/surplus_decision.dart';
import '../domain/entities/treasury_snapshot.dart';

/// حالة الخزينة الموحدة وإغلاق الشهر المالي
class TreasuryState {
  final bool isLoading;
  final TreasurySnapshot? snapshot;
  final MonthEndSummary? activeMonthSummary;
  /// قرارات المستخدم اليدوية لكل تصنيف به فائض (categoryId -> decision)
  final Map<String, SurplusDecision> userDecisions;
  final List<ClosedMonthRecord> closedMonths;
  final bool isClosingMonth;
  final String? errorMessage;
  final String? successMessage;

  const TreasuryState({
    this.isLoading = false,
    this.snapshot,
    this.activeMonthSummary,
    this.userDecisions = const {},
    this.closedMonths = const [],
    this.isClosingMonth = false,
    this.errorMessage,
    this.successMessage,
  });

  TreasuryState copyWith({
    bool? isLoading,
    TreasurySnapshot? snapshot,
    MonthEndSummary? activeMonthSummary,
    bool clearActiveMonthSummary = false,
    Map<String, SurplusDecision>? userDecisions,
    List<ClosedMonthRecord>? closedMonths,
    bool? isClosingMonth,
    String? errorMessage,
    bool clearError = false,
    String? successMessage,
    bool clearSuccess = false,
  }) {
    return TreasuryState(
      isLoading: isLoading ?? this.isLoading,
      snapshot: snapshot ?? this.snapshot,
      activeMonthSummary: clearActiveMonthSummary
          ? null
          : (activeMonthSummary ?? this.activeMonthSummary),
      userDecisions: userDecisions ?? this.userDecisions,
      closedMonths: closedMonths ?? this.closedMonths,
      isClosingMonth: isClosingMonth ?? this.isClosingMonth,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      successMessage:
          clearSuccess ? null : (successMessage ?? this.successMessage),
    );
  }
}

