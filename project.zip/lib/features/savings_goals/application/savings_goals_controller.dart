import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_finance/core/database/providers/database_providers.dart';
import 'package:my_finance/core/finance/financial_exceptions.dart';
import 'package:my_finance/core/finance/money.dart';
import '../../financial_engine/application/central_financial_engine.dart';
import '../../financial_engine/presentation/providers/financial_engine_providers.dart';
import '../data/repositories/savings_goals_repository_impl.dart';
import '../domain/entities/emergency_movement.dart';
import '../domain/entities/goal_entity.dart';
import '../domain/entities/goal_funding_entry.dart';
import '../domain/entities/savings_movement.dart';
import '../domain/repositories/savings_goals_repository.dart';
import 'savings_goals_state.dart';

/// موفر مستودع الادخار والطوارئ والأهداف
final savingsGoalsRepositoryProvider = Provider<SavingsGoalsRepository>((ref) {
  final db = ref.watch(databaseProvider);
  return SavingsGoalsRepositoryImpl(db);
});

/// موفر متحكم الادخار والطوارئ والأهداف
final savingsGoalsControllerProvider =
    StateNotifierProvider<SavingsGoalsController, SavingsGoalsState>((ref) {
  final repo = ref.watch(savingsGoalsRepositoryProvider);
  final engine = ref.watch(centralFinancialEngineProvider);
  return SavingsGoalsController(repository: repo, engine: engine);
});

/// متحكم إدارة الادخار العام، صندوق الطوارئ، والأهداف المالية
class SavingsGoalsController extends StateNotifier<SavingsGoalsState> {
  final SavingsGoalsRepository _repository;
  final CentralFinancialEngine? _engine;

  SavingsGoalsController({
    required SavingsGoalsRepository repository,
    CentralFinancialEngine? engine,
  })  : _repository = repository,
        _engine = engine,
        super(const SavingsGoalsState()) {
    loadAll();
  }

  /// تحميل كافة بيانات الادخار والطوارئ والأهداف
  Future<void> loadAll() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final savings = await _repository.getGeneralSavingsBalance();
      final savingsMovements = await _repository.getSavingsMovements();

      final emergency = await _repository.getEmergencyFundBalance();
      final emergencyMovements = await _repository.getEmergencyMovements();

      final goals = await _repository.getAllGoals();

      state = state.copyWith(
        isLoading: false,
        generalSavings: savings,
        savingsMovements: savingsMovements,
        emergencyFund: emergency,
        emergencyMovements: emergencyMovements,
        goals: goals,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تحميل بيانات الادخار والأهداف: $e',
      );
    }
  }

  // ══════════════════════════════════════════════════════════════════
  // ── الادخار العام (General Savings) ──────────────────────────────
  // ══════════════════════════════════════════════════════════════════

  /// إيداع مالي في الادخار العام
  Future<bool> depositToSavings({
    required Money amount,
    String? fromAccountId,
    String? destinationDescription,
    String? notes,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ الإيداع يجب أن يكون موجباً');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      if (fromAccountId != null && _engine != null) {
        final acc = await _engine.repository.getAccountById(fromAccountId);
        if (acc == null) {
          throw EntityNotFoundException(entityType: 'حساب', entityId: fromAccountId);
        }
        if (acc.balance < amount) {
          throw InsufficientFundsException(
            availableMinorUnits: acc.balance.minorUnits,
            requiredMinorUnits: amount.minorUnits,
          );
        }
        await _engine.repository.updateAccountBalance(
          fromAccountId,
          acc.balance - amount,
        );
      }

      final newBalance = state.generalSavings + amount;
      await _repository.updateGeneralSavingsBalance(newBalance);

      final movement = SavingsMovement(
        id: 'sm_${DateTime.now().millisecondsSinceEpoch}',
        type: SavingsMovementType.deposit,
        amount: amount,
        date: DateTime.now(),
        destinationDescription: destinationDescription ?? 'إيداع إلى الادخار العام',
        notes: notes,
        idempotencyKey: idempotencyKey,
      );
      await _repository.recordSavingsMovement(movement);

      await loadAll();
      state = state.copyWith(successMessage: 'تم الإيداع في الادخار بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل الإيداع في الادخار: $e',
      );
      return false;
    }
  }

  /// استخدام/سحب يدوي من الادخار العام مع تحديد الوجهة بدقة
  Future<bool> withdrawFromSavings({
    required Money amount,
    required SavingsMovementType destinationType,
    required String destinationDescription,
    String? targetAccountId,
    String? targetGoalId,
    String? notes,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ السحب يجب أن يكون موجباً');
      return false;
    }
    if (amount > state.generalSavings) {
      state = state.copyWith(
        errorMessage: 'رصيد الادخار العام لا يكفي لتغطية هذا المبلغ',
      );
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final newSavings = state.generalSavings - amount;
      await _repository.updateGeneralSavingsBalance(newSavings);

      // تطبيق التأثير على الوجهة المختارة
      if (destinationType == SavingsMovementType.withdrawalToLiquidity) {
        if (targetAccountId != null && _engine != null) {
          final acc = await _engine.repository.getAccountById(targetAccountId);
          if (acc != null) {
            await _engine.repository.updateAccountBalance(
              targetAccountId,
              acc.balance + amount,
            );
          }
        }
      } else if (destinationType == SavingsMovementType.transferToEmergency) {
        final newEmergency = state.emergencyFund + amount;
        await _repository.updateEmergencyFundBalance(newEmergency);
        await _repository.recordEmergencyMovement(
          EmergencyMovement(
            id: 'em_${DateTime.now().millisecondsSinceEpoch}',
            type: EmergencyMovementType.deposit,
            amount: amount,
            reason: 'تحويل من الادخار العام',
            date: DateTime.now(),
            idempotencyKey: idempotencyKey,
          ),
        );
      } else if (destinationType == SavingsMovementType.transferToGoal && targetGoalId != null) {
        final goal = await _repository.getGoalById(targetGoalId);
        if (goal != null) {
          final newSaved = goal.savedAmount + amount;
          await _repository.updateGoalSavedAmount(targetGoalId, newSaved);
          await _repository.recordGoalFundingEntry(
            GoalFundingEntry(
              id: 'gfe_${DateTime.now().millisecondsSinceEpoch}',
              goalId: targetGoalId,
              sourceType: GoalFundingSource.generalSavings,
              sourceId: 'general_savings',
              sourceName: 'الادخار العام',
              amount: amount,
              date: DateTime.now(),
              notes: notes,
              isAllocation: true,
            ),
          );
        }
      }

      final movement = SavingsMovement(
        id: 'sm_${DateTime.now().millisecondsSinceEpoch}',
        type: destinationType,
        amount: amount,
        date: DateTime.now(),
        destinationDescription: destinationDescription,
        notes: notes,
        idempotencyKey: idempotencyKey,
      );
      await _repository.recordSavingsMovement(movement);

      await loadAll();
      state = state.copyWith(successMessage: 'تم تنفيذ العملية بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل استخدام مبالغ الادخار: $e',
      );
      return false;
    }
  }

  // ══════════════════════════════════════════════════════════════════
  // ── صندوق الطوارئ (Emergency Fund) ──────────────────────────────
  // ══════════════════════════════════════════════════════════════════

  /// سحب استثنائي طارئ يتطلب سبباً صريحاً وتأكيداً
  Future<bool> withdrawFromEmergency({
    required Money amount,
    required String reason,
    String? compensationPlan,
    String? toAccountId,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ السحب يجب أن يكون موجباً');
      return false;
    }
    if (reason.trim().isEmpty) {
      state = state.copyWith(errorMessage: 'يجب تقديم سبب واضح ومبرر للسحب الطارئ');
      return false;
    }
    if (amount > state.emergencyFund) {
      state = state.copyWith(
        errorMessage: 'رصيد صندوق الطوارئ غير كافٍ لتغطية المبلغ المطلوب',
      );
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final newBalance = state.emergencyFund - amount;
      await _repository.updateEmergencyFundBalance(newBalance);

      if (toAccountId != null && _engine != null) {
        final acc = await _engine.repository.getAccountById(toAccountId);
        if (acc != null) {
          await _engine.repository.updateAccountBalance(
            toAccountId,
            acc.balance + amount,
          );
        }
      }

      final movement = EmergencyMovement(
        id: 'em_${DateTime.now().millisecondsSinceEpoch}',
        type: EmergencyMovementType.withdrawal,
        amount: amount,
        reason: reason.trim(),
        compensationPlan: compensationPlan,
        date: DateTime.now(),
        idempotencyKey: idempotencyKey,
      );
      await _repository.recordEmergencyMovement(movement);

      await loadAll();
      state = state.copyWith(successMessage: 'تم تنفيذ السحب الطارئ وتحديث الرصيد بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل السحب من صندوق الطوارئ: $e',
      );
      return false;
    }
  }

  /// إيداع / تعزيز صندوق الطوارئ
  Future<bool> depositToEmergency({
    required Money amount,
    String? fromAccountId,
    String? notes,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ الإيداع يجب أن يكون موجباً');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      if (fromAccountId != null && _engine != null) {
        final acc = await _engine.repository.getAccountById(fromAccountId);
        if (acc == null) {
          throw EntityNotFoundException(entityType: 'حساب', entityId: fromAccountId);
        }
        if (acc.balance < amount) {
          throw InsufficientFundsException(
            availableMinorUnits: acc.balance.minorUnits,
            requiredMinorUnits: amount.minorUnits,
          );
        }
        await _engine.repository.updateAccountBalance(
          fromAccountId,
          acc.balance - amount,
        );
      }

      final newBalance = state.emergencyFund + amount;
      await _repository.updateEmergencyFundBalance(newBalance);

      final movement = EmergencyMovement(
        id: 'em_${DateTime.now().millisecondsSinceEpoch}',
        type: EmergencyMovementType.deposit,
        amount: amount,
        reason: notes ?? 'تعزيز صندوق الطوارئ',
        date: DateTime.now(),
        idempotencyKey: idempotencyKey,
      );
      await _repository.recordEmergencyMovement(movement);

      await loadAll();
      state = state.copyWith(successMessage: 'تم تعزيز رصيد صندوق الطوارئ بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تعزيز صندوق الطوارئ: $e',
      );
      return false;
    }
  }

  // ══════════════════════════════════════════════════════════════════
  // ── الأهداف المالية (Financial Goals) ────────────────────────────
  // ══════════════════════════════════════════════════════════════════

  /// إنشاء هدف مالي جديد (دون حركة أموال مبدئية)
  Future<bool> createGoal({
    required String title,
    required String description,
    required Money targetAmount,
    DateTime? targetDate,
    String iconName = 'flag',
    String colorHex = '#C5A059',
  }) async {
    if (title.trim().isEmpty) {
      state = state.copyWith(errorMessage: 'عنوان الهدف مطلوب');
      return false;
    }
    if (!targetAmount.isPositive) {
      state = state.copyWith(errorMessage: 'المبلغ المستهدف يجب أن يكون موجباً');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final goal = GoalEntity(
        id: 'goal_${DateTime.now().millisecondsSinceEpoch}',
        title: title.trim(),
        description: description.trim(),
        targetAmount: targetAmount,
        savedAmount: const Money.zero(),
        targetDate: targetDate,
        status: GoalStatus.active,
        iconName: iconName,
        colorHex: colorHex,
        createdAt: DateTime.now(),
      );

      await _repository.saveGoal(goal);
      await loadAll();
      state = state.copyWith(successMessage: 'تم إنشاء الهدف المالي بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل إنشاء الهدف: $e',
      );
      return false;
    }
  }

  /// تخصيص مبلغ لهدف مالي (تحويل محاسبي وليس مصروفاً)
  Future<bool> allocateToGoal({
    required String goalId,
    required GoalFundingSource sourceType,
    required Money amount,
    String? sourceAccountId,
    String? sourceAccountName,
    String? notes,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ التخصيص يجب أن يكون موجباً');
      return false;
    }

    final goal = await _repository.getGoalById(goalId);
    if (goal == null) {
      state = state.copyWith(errorMessage: 'الهدف غير موجود');
      return false;
    }
    if (goal.status == GoalStatus.purchased) {
      state = state.copyWith(errorMessage: 'لا يمكن تخصيص أموال لهدف تم شراؤه مسبقاً');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      if (sourceType == GoalFundingSource.account) {
        if (sourceAccountId == null) {
          throw ArgumentError('يجب تحديد الحساب المصدر للتخصيص');
        }
        if (_engine != null) {
          await _engine.allocateToGoal(
            transactionId: 'txn_alloc_${DateTime.now().millisecondsSinceEpoch}',
            fromAccountId: sourceAccountId,
            goalId: goalId,
            amount: amount,
            date: DateTime.now(),
            note: notes ?? 'تخصيص للهدف: ${goal.title}',
            idempotencyKey: idempotencyKey,
          );
        }
      } else {
        // الاقتطاع من الادخار العام
        if (amount > state.generalSavings) {
          throw InsufficientFundsException(
            availableMinorUnits: state.generalSavings.minorUnits,
            requiredMinorUnits: amount.minorUnits,
          );
        }
        final newSavings = state.generalSavings - amount;
        await _repository.updateGeneralSavingsBalance(newSavings);

        await _repository.recordSavingsMovement(
          SavingsMovement(
            id: 'sm_to_goal_${DateTime.now().millisecondsSinceEpoch}',
            type: SavingsMovementType.transferToGoal,
            amount: amount,
            date: DateTime.now(),
            destinationDescription: 'تخصيص للهدف: ${goal.title}',
            notes: notes,
            idempotencyKey: idempotencyKey,
          ),
        );
      }

      final newSaved = goal.savedAmount + amount;
      await _repository.updateGoalSavedAmount(goalId, newSaved);

      await _repository.recordGoalFundingEntry(
        GoalFundingEntry(
          id: 'gfe_${DateTime.now().millisecondsSinceEpoch}',
          goalId: goalId,
          sourceType: sourceType,
          sourceId: sourceAccountId ?? 'general_savings',
          sourceName: sourceAccountName ?? (sourceType == GoalFundingSource.account ? 'حساب بنكي' : 'الادخار العام'),
          amount: amount,
          date: DateTime.now(),
          notes: notes,
          isAllocation: true,
        ),
      );

      await loadAll();
      state = state.copyWith(successMessage: 'تم تخصيص المبلغ للهدف بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تخصيص المبلغ للهدف: $e',
      );
      return false;
    }
  }

  /// إلغاء تخصيص / استرداد مبالغ من الهدف وإعادتها للحساب أو الادخار
  Future<bool> deallocateFromGoal({
    required String goalId,
    required String toAccountId,
    required Money amount,
    String? notes,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ الاسترداد يجب أن يكون موجباً');
      return false;
    }

    final goal = await _repository.getGoalById(goalId);
    if (goal == null) {
      state = state.copyWith(errorMessage: 'الهدف غير موجود');
      return false;
    }
    if (amount > goal.savedAmount) {
      state = state.copyWith(errorMessage: 'المبلغ المطلوب استرداده أكبر من المخصص للهدف');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      if (_engine != null) {
        await _engine.deallocateFromGoal(
          transactionId: 'txn_dealloc_${DateTime.now().millisecondsSinceEpoch}',
          toAccountId: toAccountId,
          goalId: goalId,
          amount: amount,
          date: DateTime.now(),
          note: notes ?? 'استرداد مخصصات من الهدف: ${goal.title}',
          idempotencyKey: idempotencyKey,
        );
      }

      final newSaved = goal.savedAmount - amount;
      await _repository.updateGoalSavedAmount(goalId, newSaved);

      // إذا كان الهدف مكتملاً وانخفض الرصيد، يعود للنشط
      if (goal.status == GoalStatus.achieved && newSaved < goal.targetAmount) {
        await _repository.updateGoalStatus(goalId, GoalStatus.active);
      }

      await _repository.recordGoalFundingEntry(
        GoalFundingEntry(
          id: 'gfe_dealloc_${DateTime.now().millisecondsSinceEpoch}',
          goalId: goalId,
          sourceType: GoalFundingSource.account,
          sourceId: toAccountId,
          sourceName: 'استرداد للحساب',
          amount: amount,
          date: DateTime.now(),
          notes: notes,
          isAllocation: false,
        ),
      );

      await loadAll();
      state = state.copyWith(successMessage: 'تم استرداد المبلغ من الهدف بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل استرداد المبلغ: $e',
      );
      return false;
    }
  }

  /// شراء الهدف المالي بعد تحقيق الادخار المطلوب (إخراج من المحجوز وتحويله لمصروف)
  Future<bool> purchaseGoal({
    required String goalId,
    String? accountId,
    String? notes,
    required String idempotencyKey,
  }) async {
    final goal = await _repository.getGoalById(goalId);
    if (goal == null) {
      state = state.copyWith(errorMessage: 'الهدف غير موجود');
      return false;
    }
    if (goal.status == GoalStatus.purchased) {
      state = state.copyWith(errorMessage: 'تم شراء هذا الهدف مسبقاً');
      return false;
    }
    if (goal.savedAmount < goal.targetAmount) {
      state = state.copyWith(
        errorMessage: 'لم يكتمل ادخار كامل المبلغ المطلوب للهدف بعد',
      );
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      // تحديث حالة الهدف إلى "تم الشراء"
      await _repository.updateGoalStatus(goalId, GoalStatus.purchased);

      await loadAll();
      state = state.copyWith(
        successMessage: 'مبارك! تم تسجيل شراء الهدف المالي بنجاح 🎯',
      );
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تسجيل شراء الهدف: $e',
      );
      return false;
    }
  }

  /// إيقاف هدف مؤقتاً
  Future<void> pauseGoal(String goalId) async {
    try {
      await _repository.updateGoalStatus(goalId, GoalStatus.paused);
      await loadAll();
    } catch (e) {
      state = state.copyWith(errorMessage: 'فشل إيقاف الهدف: $e');
    }
  }

  /// استئناف هدف موقوف
  Future<void> resumeGoal(String goalId) async {
    try {
      final goal = await _repository.getGoalById(goalId);
      if (goal != null) {
        final status = goal.savedAmount >= goal.targetAmount
            ? GoalStatus.achieved
            : GoalStatus.active;
        await _repository.updateGoalStatus(goalId, status);
        await loadAll();
      }
    } catch (e) {
      state = state.copyWith(errorMessage: 'فشل استئناف الهدف: $e');
    }
  }

  /// تحميل سجل تمويل هدف معين
  Future<void> loadGoalFundingHistory(String goalId) async {
    try {
      final history = await _repository.getGoalFundingHistory(goalId);
      state = state.copyWith(selectedGoalFundingHistory: history);
    } catch (e) {
      state = state.copyWith(errorMessage: 'فشل تحميل سجل تمويل الهدف: $e');
    }
  }
}

