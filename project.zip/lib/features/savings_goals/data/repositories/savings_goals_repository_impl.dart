import 'package:drift/drift.dart';
import '../../../../core/database/app_database.dart';
import '../../../../core/finance/money.dart';
import 'package:my_finance/features/savings_goals/domain/entities/emergency_movement.dart';
import 'package:my_finance/features/savings_goals/domain/entities/goal_entity.dart';
import 'package:my_finance/features/savings_goals/domain/entities/goal_funding_entry.dart';
import 'package:my_finance/features/savings_goals/domain/entities/savings_movement.dart';
import 'package:my_finance/features/savings_goals/domain/repositories/savings_goals_repository.dart';

/// تطبيق مستودع الادخار والطوارئ والأهداف بالاعتماد على قاعدة البيانات
class SavingsGoalsRepositoryImpl implements SavingsGoalsRepository {
  final AppDatabase _db;
  Money _generalSavings = const Money.zero();
  final List<SavingsMovement> _cachedSavingsMovements = [];
  final List<EmergencyMovement> _cachedEmergencyMovements = [];
  final Map<String, GoalEntity> _cachedGoals = {};
  final List<GoalFundingEntry> _cachedFunding = [];

  SavingsGoalsRepositoryImpl(this._db);

  // ── الادخار العام ─────────────────────────────────────────────

  @override
  Future<Money> getGeneralSavingsBalance() async => _generalSavings;

  @override
  Future<void> updateGeneralSavingsBalance(Money newBalance) async {
    _generalSavings = newBalance;
  }

  @override
  Future<List<SavingsMovement>> getSavingsMovements() async {
    final list = List<SavingsMovement>.from(_cachedSavingsMovements);
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<void> recordSavingsMovement(SavingsMovement movement) async {
    _cachedSavingsMovements.add(movement);
  }

  // ── صندوق الطوارئ ───────────────────────────────────────────

  @override
  Future<Money> getEmergencyFundBalance() async {
    final config = await _db.emergencyFundDao.getConfig();
    return Money.fromMinorUnits(config?.currentMinorUnits ?? 0);
  }

  @override
  Future<void> updateEmergencyFundBalance(Money newBalance) async {
    await _db.emergencyFundDao.updateCurrentAmount(newBalance.minorUnits);
  }

  @override
  Future<List<EmergencyMovement>> getEmergencyMovements() async {
    final list = List<EmergencyMovement>.from(_cachedEmergencyMovements);
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<void> recordEmergencyMovement(EmergencyMovement movement) async {
    _cachedEmergencyMovements.add(movement);
    if (movement.type == EmergencyMovementType.withdrawal) {
      await _db.emergencyFundDao.withdrawFromFund(
        withdrawalId: movement.id,
        amountMinorUnits: movement.amount.minorUnits,
        reason: movement.reason,
        compensationPlanNotes: movement.compensationPlan,
      );
    } else {
      await _db.emergencyFundDao.addToFund(movement.amount.minorUnits);
    }
  }

  // ── الأهداف ───────────────────────────────────────────────────

  @override
  Future<List<GoalEntity>> getAllGoals() async {
    final list = _cachedGoals.values.toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  @override
  Future<GoalEntity?> getGoalById(String id) async => _cachedGoals[id];

  @override
  Future<void> saveGoal(GoalEntity goal) async {
    _cachedGoals[goal.id] = goal;
    await _db.goalsDao.insertGoal(GoalsCompanion.insert(
      id: goal.id,
      title: goal.title,
      targetMinorUnits: goal.targetAmount.minorUnits,
      savedMinorUnits: Value(goal.savedAmount.minorUnits),
      targetDate: Value(goal.targetDate),
      status: Value(goal.status.name),
      iconName: goal.iconName,
      colorHex: goal.colorHex,
      createdAt: goal.createdAt,
    ));
  }

  @override
  Future<void> updateGoalSavedAmount(String goalId, Money newAmount) async {
    final g = _cachedGoals[goalId];
    if (g != null) {
      final isAchieved = newAmount >= g.targetAmount;
      _cachedGoals[goalId] = g.copyWith(
        savedAmount: newAmount,
        status: isAchieved && g.status == GoalStatus.active
            ? GoalStatus.achieved
            : g.status,
      );
    }
    await _db.goalsDao.updateSavedAmount(goalId, newAmount.minorUnits);
  }

  @override
  Future<void> updateGoalStatus(String goalId, GoalStatus status) async {
    final g = _cachedGoals[goalId];
    if (g != null) {
      _cachedGoals[goalId] = g.copyWith(status: status);
    }
    await _db.goalsDao.updateGoalStatus(goalId, status.name);
  }

  @override
  Future<List<GoalFundingEntry>> getGoalFundingHistory(String goalId) async {
    final list = _cachedFunding.where((f) => f.goalId == goalId).toList();
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<void> recordGoalFundingEntry(GoalFundingEntry entry) async {
    _cachedFunding.add(entry);
  }
}

