import '../../../../core/finance/money.dart';
import 'package:my_finance/features/savings_goals/domain/entities/emergency_movement.dart';
import 'package:my_finance/features/savings_goals/domain/entities/goal_entity.dart';
import 'package:my_finance/features/savings_goals/domain/entities/goal_funding_entry.dart';
import 'package:my_finance/features/savings_goals/domain/entities/savings_movement.dart';
import 'package:my_finance/features/savings_goals/domain/repositories/savings_goals_repository.dart';

/// تطبيق محاكي لذاكرة الوصول العشوائي لمستودع الادخار والطوارئ والأهداف
class InMemorySavingsGoalsRepository implements SavingsGoalsRepository {
  Money generalSavings = const Money.zero();
  final List<SavingsMovement> savingsMovements = [];

  Money emergencyFund = const Money.zero();
  final List<EmergencyMovement> emergencyMovements = [];

  final Map<String, GoalEntity> goals = {};
  final List<GoalFundingEntry> fundingEntries = [];

  // ── الادخار العام ─────────────────────────────────────────────

  @override
  Future<Money> getGeneralSavingsBalance() async => generalSavings;

  @override
  Future<void> updateGeneralSavingsBalance(Money newBalance) async {
    generalSavings = newBalance;
  }

  @override
  Future<List<SavingsMovement>> getSavingsMovements() async {
    final list = List<SavingsMovement>.from(savingsMovements);
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<void> recordSavingsMovement(SavingsMovement movement) async {
    savingsMovements.add(movement);
  }

  // ── صندوق الطوارئ ───────────────────────────────────────────

  @override
  Future<Money> getEmergencyFundBalance() async => emergencyFund;

  @override
  Future<void> updateEmergencyFundBalance(Money newBalance) async {
    emergencyFund = newBalance;
  }

  @override
  Future<List<EmergencyMovement>> getEmergencyMovements() async {
    final list = List<EmergencyMovement>.from(emergencyMovements);
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<void> recordEmergencyMovement(EmergencyMovement movement) async {
    emergencyMovements.add(movement);
  }

  // ── الأهداف ───────────────────────────────────────────────────

  @override
  Future<List<GoalEntity>> getAllGoals() async {
    final list = goals.values.toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  @override
  Future<GoalEntity?> getGoalById(String id) async => goals[id];

  @override
  Future<void> saveGoal(GoalEntity goal) async {
    goals[goal.id] = goal;
  }

  @override
  Future<void> updateGoalSavedAmount(String goalId, Money newAmount) async {
    final g = goals[goalId];
    if (g != null) {
      final isAchieved = newAmount >= g.targetAmount;
      goals[goalId] = g.copyWith(
        savedAmount: newAmount,
        status: isAchieved && g.status == GoalStatus.active
            ? GoalStatus.achieved
            : g.status,
      );
    }
  }

  @override
  Future<void> updateGoalStatus(String goalId, GoalStatus status) async {
    final g = goals[goalId];
    if (g != null) {
      goals[goalId] = g.copyWith(status: status);
    }
  }

  @override
  Future<List<GoalFundingEntry>> getGoalFundingHistory(String goalId) async {
    final list = fundingEntries.where((f) => f.goalId == goalId).toList();
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<void> recordGoalFundingEntry(GoalFundingEntry entry) async {
    fundingEntries.add(entry);
  }
}

