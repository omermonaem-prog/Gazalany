import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/goal_entity.dart';
import 'package:my_finance/features/savings_goals/application/savings_goals_controller.dart';
import '../widgets/goal_progress_card.dart';
import 'add_goal_screen.dart';
import 'goal_detail_screen.dart';

/// شاشة قائمة الأهداف المالية (Financial Goals List Screen)
class GoalsListScreen extends ConsumerStatefulWidget {
  const GoalsListScreen({super.key});

  @override
  ConsumerState<GoalsListScreen> createState() => _GoalsListScreenState();
}

class _GoalsListScreenState extends ConsumerState<GoalsListScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  List<GoalEntity> _filterGoals(List<GoalEntity> goals, int tabIndex) {
    switch (tabIndex) {
      case 1:
        return goals.where((g) => g.status == GoalStatus.active).toList();
      case 2:
        return goals.where((g) => g.status == GoalStatus.achieved).toList();
      case 3:
        return goals.where((g) => g.status == GoalStatus.purchased).toList();
      default:
        return goals;
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(savingsGoalsControllerProvider);
    final controller = ref.read(savingsGoalsControllerProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('الأهداف المالية والمشتريات'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppColors.forestGreen,
          unselectedLabelColor: AppColors.slateMuted,
          indicatorColor: AppColors.forestGreen,
          onTap: (_) => setState(() {}),
          tabs: const [
            Tab(text: 'الكل'),
            Tab(text: 'نشط'),
            Tab(text: 'مكتمل'),
            Tab(text: 'تم الشراء'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddGoalScreen()),
          );
        },
        backgroundColor: AppColors.forestGreen,
        icon: const Icon(Icons.add, color: Colors.white),
        label: Text(
          'هدف جديد',
          style: AppTypography.bodyPrimary.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadAll(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Summary Banner: Total funds locked in goals
              LuxuryCard(
                backgroundColor: AppColors.surfaceLight,
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.champagneGold.withValues(alpha: 0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.lock_clock_rounded,
                        color: AppColors.champagneGold,
                        size: 26,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'إجمالي الأموال المحجوزة للأهداف',
                            style: AppTypography.bodySecondary,
                          ),
                          const SizedBox(height: 2),
                          Text(
                            state.totalGoalsSaved.formatArabic(),
                            style: AppTypography.headingH2.copyWith(
                              color: AppColors.forestGreen,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Goals List
              Builder(
                builder: (context) {
                  final filtered = _filterGoals(state.goals, _tabController.index);

                  if (filtered.isEmpty) {
                    return LuxuryCard(
                      padding: const EdgeInsets.all(32),
                      child: Center(
                        child: Column(
                          children: [
                            Icon(
                              Icons.flag_outlined,
                              size: 44,
                              color: AppColors.slateMuted.withValues(alpha: 0.5),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'لا توجد أهداف في هذا القسم حالياً',
                              style: AppTypography.bodyPrimary.copyWith(
                                color: AppColors.slateMuted,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }

                  return ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 14),
                    itemBuilder: (context, index) {
                      final goal = filtered[index];
                      return GoalProgressCard(
                        goal: goal,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => GoalDetailScreen(goalId: goal.id),
                            ),
                          );
                        },
                        onAllocate: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => GoalDetailScreen(goalId: goal.id),
                            ),
                          );
                        },
                        onPurchase: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => GoalDetailScreen(goalId: goal.id),
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

