import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/goal_entity.dart';
import '../../domain/entities/savings_movement.dart';
import 'package:my_finance/features/savings_goals/application/savings_goals_controller.dart';
import '../widgets/savings_usage_sheet.dart';

/// شاشة الادخار العام (General Savings Screen)
class SavingsScreen extends ConsumerWidget {
  const SavingsScreen({super.key});

  void _showDepositDialog(BuildContext context, WidgetRef ref) {
    final controller = ref.read(savingsGoalsControllerProvider.notifier);
    final amountController = TextEditingController();
    final notesController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('إيداع في الادخار العام', style: AppTypography.headingH3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'المبلغ (ر.س) *',
                hintText: '0.00',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: notesController,
              decoration: InputDecoration(
                labelText: 'ملاحظات (اختياري)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.forestGreen,
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              try {
                final amt = Money.parse(amountController.text.trim());
                final idpKey = 'deposit_savings_${DateTime.now().millisecondsSinceEpoch}';
                await controller.depositToSavings(
                  amount: amt,
                  notes: notesController.text.trim().isEmpty ? null : notesController.text.trim(),
                  idempotencyKey: idpKey,
                );
                if (context.mounted) Navigator.pop(ctx);
              } catch (_) {}
            },
            child: const Text('إيداع'),
          ),
        ],
      ),
    );
  }

  void _showUsageSheet(BuildContext context, WidgetRef ref, Money savings, List<GoalEntity> activeGoals) {
    final controller = ref.read(savingsGoalsControllerProvider.notifier);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surfaceLight,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => SavingsUsageSheet(
        currentSavings: savings,
        activeGoals: activeGoals,
        onConfirm: ({
          required amount,
          required destinationType,
          required destinationDescription,
          targetGoalId,
          notes,
        }) async {
          final idpKey = 'withdraw_savings_${DateTime.now().millisecondsSinceEpoch}';
          await controller.withdrawFromSavings(
            amount: amount,
            destinationType: destinationType,
            destinationDescription: destinationDescription,
            targetGoalId: targetGoalId,
            notes: notes,
            idempotencyKey: idpKey,
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(savingsGoalsControllerProvider);
    final controller = ref.read(savingsGoalsControllerProvider.notifier);

    final activeGoals = state.goals.where((g) => g.status == GoalStatus.active).toList();

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('الادخار العام'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadAll(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Hero Balance Card
              LuxuryCard(
                backgroundColor: AppColors.forestGreen,
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.12),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.savings_rounded,
                        color: AppColors.champagneGold,
                        size: 32,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'رصيد الادخار العام',
                      style: AppTypography.bodySecondary.copyWith(
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      state.generalSavings.formatArabic(),
                      style: AppTypography.displayLarge.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => _showDepositDialog(context, ref),
                            icon: const Icon(Icons.add, size: 18),
                            label: const Text('إيداع'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: AppColors.forestGreen,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: state.generalSavings.isPositive
                                ? () => _showUsageSheet(context, ref, state.generalSavings, activeGoals)
                                : null,
                            icon: const Icon(Icons.arrow_outward_rounded, size: 18),
                            label: const Text('استخدام'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white,
                              side: const BorderSide(color: Colors.white60),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Title: History
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('سجل حركات الادخار', style: AppTypography.headingH3),
                  Text(
                    '${state.savingsMovements.length} حركة',
                    style: AppTypography.bodySecondary,
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Movements list
              if (state.savingsMovements.isEmpty)
                LuxuryCard(
                  padding: const EdgeInsets.all(28),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(
                          Icons.history_toggle_off_rounded,
                          size: 40,
                          color: AppColors.slateMuted.withValues(alpha: 0.5),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'لا توجد حركات مسجلة في الادخار حتى الآن',
                          style: AppTypography.bodySecondary,
                        ),
                      ],
                    ),
                  ),
                )
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: state.savingsMovements.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final m = state.savingsMovements[index];
                    final isDeposit = m.type == SavingsMovementType.deposit;

                    return LuxuryCard(
                      padding: const EdgeInsets.all(14),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: isDeposit
                                  ? AppColors.cashIn.withValues(alpha: 0.12)
                                  : AppColors.cashOut.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(
                              isDeposit
                                  ? Icons.arrow_downward_rounded
                                  : Icons.arrow_upward_rounded,
                              color: isDeposit ? AppColors.cashIn : AppColors.cashOut,
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  m.destinationDescription,
                                  style: AppTypography.bodyPrimary.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  '${m.date.year}/${m.date.month.toString().padLeft(2, '0')}/${m.date.day.toString().padLeft(2, '0')}',
                                  style: AppTypography.bodySecondary.copyWith(fontSize: 12),
                                ),
                                if (m.notes != null && m.notes!.isNotEmpty) ...[
                                  const SizedBox(height: 2),
                                  Text(
                                    m.notes!,
                                    style: AppTypography.bodySecondary.copyWith(
                                      color: AppColors.slateMuted,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                          Text(
                            '${isDeposit ? '+' : '-'}${m.amount.formatArabic()}',
                            style: AppTypography.bodyPrimary.copyWith(
                              fontWeight: FontWeight.bold,
                              color: isDeposit ? AppColors.cashIn : AppColors.cashOut,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

