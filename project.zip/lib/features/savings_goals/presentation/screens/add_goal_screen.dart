import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import 'package:my_finance/features/savings_goals/application/savings_goals_controller.dart';

/// شاشة إنشاء هدف مالي جديد
class AddGoalScreen extends ConsumerStatefulWidget {
  const AddGoalScreen({super.key});

  @override
  ConsumerState<AddGoalScreen> createState() => _AddGoalScreenState();
}

class _AddGoalScreenState extends ConsumerState<AddGoalScreen> {
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _amountController = TextEditingController();
  DateTime? _selectedTargetDate;
  String? _error;

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: now.add(const Duration(days: 90)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 3650)),
    );
    if (picked != null) {
      setState(() => _selectedTargetDate = picked);
    }
  }

  Future<void> _submit() async {
    setState(() => _error = null);

    final title = _titleController.text.trim();
    if (title.isEmpty) {
      setState(() => _error = 'يرجى إدخال عنوان للهدف');
      return;
    }

    Money targetAmount;
    try {
      targetAmount = Money.parse(_amountController.text.trim());
      if (!targetAmount.isPositive) {
        setState(() => _error = 'يجب أن يكون المبلغ المستهدف أكبر من صفر');
        return;
      }
    } catch (_) {
      setState(() => _error = 'يرجى إدخال مبلغ صالح');
      return;
    }

    final controller = ref.read(savingsGoalsControllerProvider.notifier);
    final success = await controller.createGoal(
      title: title,
      description: _descriptionController.text.trim(),
      targetAmount: targetAmount,
      targetDate: _selectedTargetDate,
    );

    if (success && mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('إنشاء هدف مالي جديد'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Title Input
            TextField(
              controller: _titleController,
              decoration: InputDecoration(
                labelText: 'عنوان الهدف *',
                hintText: 'مثال: شراء سيارة جديدة، دورة تدريبية، سفر...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.flag_rounded),
              ),
            ),
            const SizedBox(height: 16),

            // Target Amount Input
            TextField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'المبلغ المستهدف (ر.س) *',
                hintText: '0.00',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
            ),
            const SizedBox(height: 16),

            // Target Date Picker
            InkWell(
              onTap: _pickDate,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.borderSubtleLight),
                  borderRadius: BorderRadius.circular(12),
                  color: AppColors.surfaceLight,
                ),
                child: Row(
                  children: [
                    const Icon(Icons.calendar_month_outlined, color: AppColors.forestGreen),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        _selectedTargetDate == null
                            ? 'تاريخ تحقيق الهدف (اختياري)'
                            : 'تاريخ الهدف: ${_selectedTargetDate!.year}/${_selectedTargetDate!.month.toString().padLeft(2, '0')}/${_selectedTargetDate!.day.toString().padLeft(2, '0')}',
                        style: AppTypography.bodyPrimary.copyWith(
                          color: _selectedTargetDate == null ? AppColors.slateMuted : AppColors.textMain,
                        ),
                      ),
                    ),
                    if (_selectedTargetDate != null)
                      IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () => setState(() => _selectedTargetDate = null),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Description Input
            TextField(
              controller: _descriptionController,
              maxLines: 3,
              decoration: InputDecoration(
                labelText: 'الوصف والملاحظات (اختياري)',
                hintText: 'تفاصيل الخطة، مواصفات المشتريات أو الأولويات...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.notes_rounded),
              ),
            ),
            const SizedBox(height: 24),

            if (_error != null) ...[
              Text(
                _error!,
                style: AppTypography.bodySecondary.copyWith(
                  color: AppColors.criticalRed,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
            ],

            LuxuryButton(
              label: 'حفظ الهدف المالي',
              icon: Icons.check_circle_outline,
              onPressed: _submit,
            ),
          ],
        ),
      ),
    );
  }
}

