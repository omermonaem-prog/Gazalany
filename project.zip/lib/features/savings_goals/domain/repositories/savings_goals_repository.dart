import '../../../../core/finance/money.dart';
import '../entities/emergency_movement.dart';
import '../entities/goal_entity.dart';
import '../entities/goal_funding_entry.dart';
import '../entities/savings_movement.dart';

/// العقد المجرد لمستودع الادخار وصندوق الطوارئ والأهداف
abstract class SavingsGoalsRepository {
  // ── الادخار العام ─────────────────────────────────────────────
  Future<Money> getGeneralSavingsBalance();
  Future<void> updateGeneralSavingsBalance(Money newBalance);
  Future<List<SavingsMovement>> getSavingsMovements();
  Future<void> recordSavingsMovement(SavingsMovement movement);

  // ── صندوق الطوارئ ───────────────────────────────────────────
  Future<Money> getEmergencyFundBalance();
  Future<void> updateEmergencyFundBalance(Money newBalance);
  Future<List<EmergencyMovement>> getEmergencyMovements();
  Future<void> recordEmergencyMovement(EmergencyMovement movement);

  // ── الأهداف المالية ──────────────────────────────────────────
  Future<List<GoalEntity>> getAllGoals();
  Future<GoalEntity?> getGoalById(String id);
  Future<void> saveGoal(GoalEntity goal);
  Future<void> updateGoalSavedAmount(String goalId, Money newAmount);
  Future<void> updateGoalStatus(String goalId, GoalStatus status);
  Future<List<GoalFundingEntry>> getGoalFundingHistory(String goalId);
  Future<void> recordGoalFundingEntry(GoalFundingEntry entry);
}

