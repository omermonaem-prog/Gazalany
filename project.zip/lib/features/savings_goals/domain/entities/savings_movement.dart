import '../../../../core/finance/money.dart';

enum SavingsMovementType {
  deposit,
  withdrawalToLiquidity,
  transferToGoal,
  transferToEmergency;

  String get labelArabic {
    switch (this) {
      case SavingsMovementType.deposit:
        return 'إيداع في الادخار';
      case SavingsMovementType.withdrawalToLiquidity:
        return 'سحب إلى السيولة المتاحة';
      case SavingsMovementType.transferToGoal:
        return 'تخصيص لهدف مالي';
      case SavingsMovementType.transferToEmergency:
        return 'تحويل لصندوق الطوارئ';
    }
  }
}

/// حركة في سجل الادخار العام
class SavingsMovement {
  final String id;
  final SavingsMovementType type;
  final Money amount;
  final DateTime date;
  final String destinationDescription;
  final String? notes;
  final String idempotencyKey;

  const SavingsMovement({
    required this.id,
    required this.type,
    required this.amount,
    required this.date,
    required this.destinationDescription,
    this.notes,
    required this.idempotencyKey,
  });
}

