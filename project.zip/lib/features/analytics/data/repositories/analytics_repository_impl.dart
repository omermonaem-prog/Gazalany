import 'package:drift/drift.dart';
import '../../../../core/database/app_database.dart';
import '../../../../core/finance/money.dart';
import 'package:my_finance/features/analytics/domain/entities/bucket_distribution_report.dart';
import 'package:my_finance/features/analytics/domain/entities/category_expense_breakdown.dart';
import 'package:my_finance/features/analytics/domain/entities/financial_calendar_event.dart';
import 'package:my_finance/features/analytics/domain/entities/financial_forecast_model.dart';
import 'package:my_finance/features/analytics/domain/entities/monthly_financial_summary.dart';
import 'package:my_finance/features/analytics/domain/repositories/analytics_repository.dart';

/// تطبيق مستودع التحليلات والتقارير بالاعتماد على قاعدة البيانات الفعلية فقط
class AnalyticsRepositoryImpl implements AnalyticsRepository {
  final AppDatabase _db;

  AnalyticsRepositoryImpl(this._db);

  @override
  Future<List<MonthlyFinancialSummary>> getMonthlySummaries({
    int limitMonths = 12,
  }) async {
    // 1. استخراج كافة المعاملات غير المحذوفة من قاعدة البيانات الفعلية
    final txns = await (_db.select(_db.transactions)
          ..where((t) => t.isDeleted.equals(false))
          ..orderBy([(t) => OrderingTerm.desc(t.transactionDate)]))
        .get();

    if (txns.isEmpty) {
      return [];
    }

    // 2. تجميع المعاملات حسب الشهر والسنة (YYYY-MM)
    final Map<String, List<TransactionEntry>> grouped = {};
    for (final t in txns) {
      final d = t.transactionDate;
      final ym = '${d.year}-${d.month.toString().padLeft(2, '0')}';
      grouped.putIfAbsent(ym, () => []).add(t);
    }

    final List<MonthlyFinancialSummary> result = [];

    for (final entry in grouped.entries) {
      final ym = entry.key;
      final monthTxns = entry.value;

      int totalIncomeMinor = 0;
      int salaryIncomeMinor = 0;
      int additionalIncomeMinor = 0;
      int totalExpensesMinor = 0;

      for (final t in monthTxns) {
        if (t.type == 'income') {
          totalIncomeMinor += t.amountMinorUnits;
          final isSalary = (t.note?.contains('راتب') == true) ||
              (t.categoryId?.contains('salary') == true);
          if (isSalary) {
            salaryIncomeMinor += t.amountMinorUnits;
          } else {
            additionalIncomeMinor += t.amountMinorUnits;
          }
        } else if (t.type == 'expense') {
          totalExpensesMinor += t.amountMinorUnits;
        }
      }

      final parts = ym.split('-');
      final year = int.parse(parts[0]);
      final month = int.parse(parts[1]);

      result.add(MonthlyFinancialSummary(
        periodYearMonth: ym,
        monthLabel: _formatMonthLabel(month, year),
        totalIncome: Money.fromMinorUnits(totalIncomeMinor),
        salaryIncome: Money.fromMinorUnits(salaryIncomeMinor),
        additionalIncome: Money.fromMinorUnits(additionalIncomeMinor),
        totalExpenses: Money.fromMinorUnits(totalExpensesMinor),
      ));
    }

    result.sort((a, b) => b.periodYearMonth.compareTo(a.periodYearMonth));
    return result.take(limitMonths).toList();
  }

  @override
  Future<List<CategoryExpenseBreakdown>> getCategoryExpenseBreakdown({
    String? periodYearMonth,
  }) async {
    // استخراج المصروفات الفعلية
    final query = _db.select(_db.transactions)
      ..where((t) => t.type.equals('expense') & t.isDeleted.equals(false));

    if (periodYearMonth != null) {
      final parts = periodYearMonth.split('-');
      final year = int.parse(parts[0]);
      final month = int.parse(parts[1]);
      final start = DateTime(year, month, 1);
      final end = DateTime(year, month + 1, 1);
      query.where((t) =>
          t.transactionDate.isBiggerOrEqualValue(start) &
          t.transactionDate.isSmallerThanValue(end));
    }

    final expenseTxns = await query.get();
    if (expenseTxns.isEmpty) {
      return [];
    }

    final int totalExpenseMinor =
        expenseTxns.fold(0, (sum, t) => sum + t.amountMinorUnits);

    // تجميع حسب التصنيف
    final Map<String, List<TransactionEntry>> byCategory = {};
    for (final t in expenseTxns) {
      final catId = t.categoryId ?? 'cat_general';
      byCategory.putIfAbsent(catId, () => []).add(t);
    }

    final List<CategoryExpenseBreakdown> list = [];
    final colors = [
      '#0E3B2E',
      '#C5A059',
      '#1B6B54',
      '#D4AF37',
      '#8C2D19',
      '#4A6B82',
      '#2D4F38'
    ];
    int colorIdx = 0;

    for (final entry in byCategory.entries) {
      final catId = entry.key;
      final txns = entry.value;
      final catTotalMinor =
          txns.fold<int>(0, (sum, t) => sum + t.amountMinorUnits);
      final percentage = totalExpenseMinor > 0
          ? (catTotalMinor / totalExpenseMinor) * 100.0
          : 0.0;

      list.add(CategoryExpenseBreakdown(
        categoryId: catId,
        categoryName: _resolveCategoryName(catId),
        colorHex: colors[colorIdx % colors.length],
        totalAmount: Money.fromMinorUnits(catTotalMinor),
        percentageOfTotal: percentage,
        transactionCount: txns.length,
      ));
      colorIdx++;
    }

    list.sort((a, b) => b.totalAmount.compareTo(a.totalAmount));
    return list;
  }

  @override
  Future<List<BucketDistributionReport>> getBucketDistributionReport({
    String? periodYearMonth,
  }) async {
    final summaries = await getMonthlySummaries();
    MonthlyFinancialSummary? targetSummary;
    if (periodYearMonth != null) {
      targetSummary = summaries
          .where((s) => s.periodYearMonth == periodYearMonth)
          .firstOrNull;
    }
    targetSummary ??= summaries.firstOrNull;

    final income = targetSummary?.totalIncome ?? const Money.zero();
    final parts = Money.apportionByPercentages(income, [40.0, 20.0, 20.0, 10.0, 10.0]);

    return [
      BucketDistributionReport(
        bucketName: 'المسؤوليات والبيت',
        description: 'الفواتير والإيجار والمصاريف الأساسية',
        allocatedAmount: parts[0],
        targetPercentage: 40.0,
        actualPercentage: 40.0,
        colorHex: '#0E3B2E',
      ),
      BucketDistributionReport(
        bucketName: 'الادخار العام',
        description: 'الاستثمار والادخار بعيد المدى',
        allocatedAmount: parts[1],
        targetPercentage: 20.0,
        actualPercentage: 20.0,
        colorHex: '#C5A059',
      ),
      BucketDistributionReport(
        bucketName: 'صندوق الطوارئ',
        description: 'الأمان المالي والظروف القاهرة',
        allocatedAmount: parts[2],
        targetPercentage: 20.0,
        actualPercentage: 20.0,
        colorHex: '#C93B2B',
      ),
      BucketDistributionReport(
        bucketName: 'تطوير المهارات والعمل',
        description: 'الدورات والكتب وأدوات التطوير',
        allocatedAmount: parts[3],
        targetPercentage: 10.0,
        actualPercentage: 10.0,
        colorHex: '#1B6B54',
      ),
      BucketDistributionReport(
        bucketName: 'الترفيه والمصروف الشخصي',
        description: 'المطاعم والرحلات والهوايات',
        allocatedAmount: parts[4],
        targetPercentage: 10.0,
        actualPercentage: 10.0,
        colorHex: '#D4AF37',
      ),
    ];
  }

  @override
  Future<List<FinancialCalendarEvent>> getCalendarEvents({
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final List<FinancialCalendarEvent> events = [];

    // استخراج الالتزامات النشطة
    final obligations = await (_db.select(_db.obligations)
          ..where((o) => o.isActive.equals(true)))
        .get();

    final now = DateTime.now();

    for (final o in obligations) {
      final dueDate = DateTime(now.year, now.month, o.dueDayOfMonth);
      final isOverdue = now.day > o.dueDayOfMonth;

      events.add(FinancialCalendarEvent(
        id: 'ob_${o.id}',
        date: dueDate,
        title: o.title,
        amount: Money.fromMinorUnits(o.amountMinorUnits),
        type: CalendarEventType.obligationDue,
        status: isOverdue
            ? CalendarEventStatus.overdue
            : CalendarEventStatus.pending,
      ));
    }

    // استخراج الديون النشطة
    final debts = await (_db.select(_db.debts)
          ..where((d) => d.status.equals('active')))
        .get();

    for (final d in debts) {
      if (d.dueDate != null) {
        final isOverdue = now.isAfter(d.dueDate!);
        events.add(FinancialCalendarEvent(
          id: 'debt_${d.id}',
          date: d.dueDate!,
          title: 'قسط ${d.title} (${d.counterpartyName})',
          amount: Money.fromMinorUnits(d.monthlyInstallmentMinorUnits ?? d.remainingMinorUnits),
          type: CalendarEventType.debtInstallment,
          status: isOverdue
              ? CalendarEventStatus.overdue
              : CalendarEventStatus.pending,
        ));
      }
    }

    events.sort((a, b) => a.date.compareTo(b.date));
    return events;
  }

  @override
  Future<FinancialForecastModel> getFinancialForecast() async {
    final summaries = await getMonthlySummaries();
    Money avgIncome = const Money.zero();
    Money avgExpenses = const Money.zero();

    if (summaries.isNotEmpty) {
      int totalIncome = 0;
      int totalExpenses = 0;
      for (final s in summaries) {
        totalIncome += s.totalIncome.minorUnits;
        totalExpenses += s.totalExpenses.minorUnits;
      }
      avgIncome = Money.fromMinorUnits(totalIncome ~/ summaries.length);
      avgExpenses = Money.fromMinorUnits(totalExpenses ~/ summaries.length);
    }

    final avgSavings = avgIncome > avgExpenses
        ? avgIncome - avgExpenses
        : const Money.zero();

    final efConfig = await _db.emergencyFundDao.getConfig();
    final efCurrent = Money.fromMinorUnits(efConfig?.currentMinorUnits ?? 0);
    final efTarget = Money.fromMinorUnits(efConfig?.targetMinorUnits ?? 0);

    int monthsToTarget = 0;
    if (avgSavings.isPositive && efTarget > efCurrent) {
      final remaining = efTarget - efCurrent;
      monthsToTarget = (remaining.minorUnits / avgSavings.minorUnits).ceil();
    }

    return FinancialForecastModel(
      averageMonthlyIncome: avgIncome,
      averageMonthlyExpenses: avgExpenses,
      averageMonthlySavings: avgSavings,
      projectedNetWorthIn3Months: avgSavings * 3,
      projectedNetWorthIn6Months: avgSavings * 6,
      projectedNetWorthIn12Months: avgSavings * 12,
      projectedEmergencyFundIn6Months: efCurrent + Money.fromMinorUnits((avgSavings.minorUnits * 12 / 10).round(), avgSavings.currency),
      monthsUntilEmergencyTargetReached: monthsToTarget > 0 ? monthsToTarget : 1,
    );
  }

  String _formatMonthLabel(int month, int year) {
    const arabicMonths = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    final mName = arabicMonths[(month - 1).clamp(0, 11)];
    return '$mName $year';
  }

  String _resolveCategoryName(String catId) {
    switch (catId) {
      case 'cat_housing':
        return 'السكن والفواتير';
      case 'cat_food':
        return 'المعيشة والتموين';
      case 'cat_transport':
        return 'المواصلات والوقود';
      case 'cat_leisure':
        return 'الترفيه والتسوق';
      case 'cat_health':
        return 'الصحة والعلاج';
      case 'cat_education':
        return 'التعليم والمهارات';
      default:
        return 'مصروفات عامة';
    }
  }
}
