import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../domain/entities/category_expense_breakdown.dart';

/// ويدجت توزيع المصروفات حسب التصنيف مع مؤشرات النسب
class CategoryPieChart extends StatelessWidget {
  final List<CategoryExpenseBreakdown> categories;

  const CategoryPieChart({
    super.key,
    required this.categories,
  });

  @override
  Widget build(BuildContext context) {
    if (categories.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            'لا توجد مصروفات مسجلة في هذه الفترة',
            style: AppTypography.bodySecondary,
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Multi-segmented bar
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: SizedBox(
            height: 14,
            child: Row(
              children: categories.map((c) {
                final flex = (c.percentageOfTotal * 10).round().clamp(1, 1000);
                final color = _parseColor(c.colorHex);

                return Flexible(
                  flex: flex,
                  child: Container(
                    color: color,
                  ),
                );
              }).toList(),
            ),
          ),
        ),
        const SizedBox(height: 16),

        // List of categories with amounts and percentages
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: categories.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final c = categories[index];
            final color = _parseColor(c.colorHex);

            return Row(
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    c.categoryName,
                    style: AppTypography.bodyPrimary.copyWith(fontSize: 13),
                  ),
                ),
                Text(
                  '${c.percentageOfTotal.toStringAsFixed(1)}%',
                  style: AppTypography.bodySecondary.copyWith(
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  c.totalAmount.formatArabic(),
                  style: AppTypography.bodyPrimary.copyWith(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
              ],
            );
          },
        ),
      ],
    );
  }

  Color _parseColor(String hex) {
    try {
      final clean = hex.replaceAll('#', '');
      return Color(int.parse('FF$clean', radix: 16));
    } catch (_) {
      return AppColors.forestGreen;
    }
  }
}

