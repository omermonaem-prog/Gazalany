import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import 'package:my_finance/features/analytics/application/analytics_controller.dart';
import '../widgets/forecast_projection_card.dart';

/// شاشة التوقعات والتقديرات المالية المستقبلية
class ForecastsScreen extends ConsumerWidget {
  const ForecastsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(analyticsControllerProvider);
    final forecast = state.forecastModel;

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('التوقعات والتقديرات المستقبلية'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: forecast == null
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Hero Card
                  ForecastProjectionCard(forecast: forecast),
                  const SizedBox(height: 20),

                  Text('متوسطات الأداء التاريخي', style: AppTypography.headingH3),
                  const SizedBox(height: 10),

                  LuxuryCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildRow('متوسط الدخل الشهري', forecast.averageMonthlyIncome.formatArabic(), AppColors.cashIn),
                        const Divider(height: 16),
                        _buildRow('متوسط المصروف الشهري', forecast.averageMonthlyExpenses.formatArabic(), AppColors.cashOut),
                        const Divider(height: 16),
                        _buildRow('متوسط الفائض/الوفر الشهري', forecast.averageMonthlySavings.formatArabic(), AppColors.forestGreen),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  Text('توقعات صناديق الأمان والأهداف', style: AppTypography.headingH3),
                  const SizedBox(height: 10),

                  LuxuryCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'تغطية صندوق الطوارئ التقديرية',
                          style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'بناءً على نمط الادخار الحالي، يُتوقع وصول صندوق الطوارئ إلى هدفه المالي خلال حوالي ${forecast.monthsUntilEmergencyTargetReached} أشهر.',
                          style: AppTypography.bodySecondary,
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('الرصيد التقديري خلال 6 أشهر:', style: AppTypography.bodySecondary),
                            Text(
                              forecast.projectedEmergencyFundIn6Months.formatArabic(),
                              style: AppTypography.bodyPrimary.copyWith(
                                fontWeight: FontWeight.bold,
                                color: AppColors.forestGreen,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Legal & Accounting Disclaimer Banner
                  LuxuryCard(
                    backgroundColor: AppColors.surfaceSubtleLight,
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.gavel_rounded, color: AppColors.slateMuted, size: 20),
                            const SizedBox(width: 8),
                            Text('إخلاء مسؤولية واشتراطات النزاهة المحاسبية', style: AppTypography.headingH3.copyWith(fontSize: 14)),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          forecast.disclaimer,
                          style: AppTypography.bodySecondary.copyWith(fontSize: 11, height: 1.5),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildRow(String label, String value, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: AppTypography.bodyPrimary),
        Text(
          value,
          style: AppTypography.bodyPrimary.copyWith(
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ],
    );
  }
}

