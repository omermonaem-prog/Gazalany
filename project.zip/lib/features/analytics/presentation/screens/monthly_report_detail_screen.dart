import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import 'package:my_finance/features/analytics/application/analytics_controller.dart';

/// شاشة التقرير المالي التفصيلي وتوزيع الدخل على الأقسام الخمسة (40/20/20/10/10)
class MonthlyReportDetailScreen extends ConsumerWidget {
  const MonthlyReportDetailScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(analyticsControllerProvider);
    final controller = ref.read(analyticsControllerProvider.notifier);
    final summary = state.selectedMonthSummary;

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('التقرير المالي وتوزيع الأقسام'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.file_download_outlined, color: AppColors.forestGreen),
            tooltip: 'تصدير التقرير',
            onPressed: () {
              final csv = controller.exportMonthlySummariesCsv();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('تم تصدير التقرير الشهري بنجاح (${csv.length} بايت)'),
                  backgroundColor: AppColors.forestGreen,
                ),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Period selector dropdown
            if (state.monthlySummaries.isNotEmpty) ...[
              DropdownButtonFormField<String>(
                value: state.selectedPeriodYearMonth,
                decoration: InputDecoration(
                  labelText: 'اختر الفترة الزمنية للتقرير *',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  prefixIcon: const Icon(Icons.calendar_month),
                ),
                items: state.monthlySummaries.map((s) {
                  return DropdownMenuItem(
                    value: s.periodYearMonth,
                    child: Text(s.monthLabel),
                  );
                }).toList(),
                onChanged: (val) {
                  if (val != null) controller.selectPeriodYearMonth(val);
                },
              ),
              const SizedBox(height: 16),
            ],

            if (summary != null) ...[
              // Income Breakdown (Salary vs Additional)
              LuxuryCard(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('تفصيل الدخل المالي', style: AppTypography.headingH3),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('الراتب الأساسي', style: AppTypography.bodyPrimary),
                        Text(
                          summary.salaryIncome.formatArabic(),
                          style: AppTypography.bodyPrimary.copyWith(
                            fontWeight: FontWeight.bold,
                            color: AppColors.cashIn,
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 14),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('الدخل الإضافي / الحوافز', style: AppTypography.bodyPrimary),
                        Text(
                          summary.additionalIncome.formatArabic(),
                          style: AppTypography.bodyPrimary.copyWith(
                            fontWeight: FontWeight.bold,
                            color: AppColors.champagneGold,
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 14),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('إجمالي الدخل الشهري', style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold)),
                        Text(
                          summary.totalIncome.formatArabic(),
                          style: AppTypography.bodyPrimary.copyWith(
                            fontWeight: FontWeight.bold,
                            color: AppColors.forestGreen,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],

            // 5 Buckets Distribution Report
            Text('توزيع الدخل على الأقسام (قاعدة 40 / 20 / 20 / 10 / 10)', style: AppTypography.headingH3),
            const SizedBox(height: 12),

            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: state.bucketReports.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final b = state.bucketReports[index];
                return LuxuryCard(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(b.bucketName, style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold)),
                          Text(
                            '${b.actualPercentage.toStringAsFixed(0)}% (المستهدف: ${b.targetPercentage.toStringAsFixed(0)}%)',
                            style: AppTypography.bodySecondary.copyWith(fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(b.description, style: AppTypography.bodySecondary.copyWith(fontSize: 11)),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: (b.actualPercentage / 100.0).clamp(0.0, 1.0),
                          minHeight: 6,
                          backgroundColor: AppColors.surfaceSubtleLight,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            AppColors.forestGreen,
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        b.allocatedAmount.formatArabic(),
                        style: AppTypography.bodyPrimary.copyWith(
                          fontWeight: FontWeight.bold,
                          color: AppColors.forestGreen,
                        ),
                        textAlign: TextAlign.end,
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

