import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../domain/entities/financial_calendar_event.dart';
import 'package:my_finance/features/analytics/application/analytics_controller.dart';

/// شاشة التقويم المالي والأحداث والاستحقاقات
class FinancialCalendarScreen extends ConsumerWidget {
  const FinancialCalendarScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(analyticsControllerProvider);
    final events = state.calendarEvents;

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('التقويم المالي والاستحقاقات'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: events.isEmpty
          ? Center(
              child: Text(
                'لا توجد أحداث أو استحقاقات مسجلة في التقويم',
                style: AppTypography.bodySecondary,
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: events.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final ev = events[index];
                final isIncome = ev.type == CalendarEventType.income;

                return LuxuryCard(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      // Date Box
                      Container(
                        width: 52,
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceSubtleLight,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.borderSubtleLight),
                        ),
                        child: Column(
                          children: [
                            Text(
                              '${ev.date.day}',
                              style: AppTypography.headingH2.copyWith(
                                color: AppColors.forestGreen,
                                height: 1.0,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '${ev.date.month}',
                              style: AppTypography.bodySecondary.copyWith(fontSize: 10),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 14),

                      // Event Details
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              ev.title,
                              style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              ev.type.labelArabic,
                              style: AppTypography.bodySecondary.copyWith(fontSize: 12),
                            ),
                          ],
                        ),
                      ),

                      // Amount & Status
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            '${isIncome ? "+" : "-"}${ev.amount.formatArabic()}',
                            style: AppTypography.bodyPrimary.copyWith(
                              fontWeight: FontWeight.bold,
                              color: isIncome ? AppColors.cashIn : AppColors.cashOut,
                            ),
                          ),
                          const SizedBox(height: 4),
                          StatusBadge(
                            text: ev.status.labelArabic,
                            color: ev.status == CalendarEventStatus.overdue
                                ? AppColors.criticalRed.withValues(alpha: 0.15)
                                : AppColors.surfaceSubtleLight,
                            textColor: ev.status == CalendarEventStatus.overdue
                                ? AppColors.criticalRed
                                : AppColors.forestGreen,
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

