import '../../../../core/finance/money.dart';

enum CalendarEventType {
  income,
  expense,
  obligationDue,
  debtInstallment,
  goalMilestone;

  String get labelArabic {
    switch (this) {
      case CalendarEventType.income:
        return 'إيداع دخل';
      case CalendarEventType.expense:
        return 'مصروف فعلي';
      case CalendarEventType.obligationDue:
        return 'استحقاق فاتورة/التزام';
      case CalendarEventType.debtInstallment:
        return 'قسط دين';
      case CalendarEventType.goalMilestone:
        return 'محطة هدف مالي';
    }
  }
}

enum CalendarEventStatus {
  completed,
  pending,
  overdue;

  String get labelArabic {
    switch (this) {
      case CalendarEventStatus.completed:
        return 'مكتمل';
      case CalendarEventStatus.pending:
        return 'قادم';
      case CalendarEventStatus.overdue:
        return 'متأخر';
    }
  }
}

/// حدث مالي في التقويم (Financial Calendar Event)
class FinancialCalendarEvent {
  final String id;
  final DateTime date;
  final String title;
  final Money amount;
  final CalendarEventType type;
  final CalendarEventStatus status;
  final String? subtitle;

  const FinancialCalendarEvent({
    required this.id,
    required this.date,
    required this.title,
    required this.amount,
    required this.type,
    this.status = CalendarEventStatus.completed,
    this.subtitle,
  });
}

