import '../../../../core/finance/money.dart';

/// ملخص مالي شهري (Monthly Financial Summary)
class MonthlyFinancialSummary {
  final String periodYearMonth; // مثال: "2026-10"
  final String monthLabel; // مثال: "أكتوبر 2026"
  final Money totalIncome;
  final Money salaryIncome;
  final Money additionalIncome;
  final Money totalExpenses;

  const MonthlyFinancialSummary({
    required this.periodYearMonth,
    required this.monthLabel,
    required this.totalIncome,
    required this.salaryIncome,
    required this.additionalIncome,
    required this.totalExpenses,
  });

  /// الفائض أو العجز الشهري: الدخل - المصروف
  Money get netSavings => totalIncome - totalExpenses;

  /// هل الشهر حقق وفراً إيجابياً
  bool get hasSurplus => totalIncome >= totalExpenses;

  /// نسبة الادخار والوفر من إجمالي الدخل (%)
  double get savingsRatePercentage {
    if (totalIncome.minorUnits <= 0) return 0.0;
    if (netSavings.isNegative) return 0.0;
    final r = (netSavings.minorUnits / totalIncome.minorUnits) * 100.0;
    return r.clamp(0.0, 100.0);
  }
}

