import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_finance/core/database/providers/database_providers.dart';
import 'package:my_finance/core/finance/financial_exceptions.dart';
import 'package:my_finance/core/finance/money.dart';
import '../../financial_engine/application/central_financial_engine.dart';
import '../../financial_engine/presentation/providers/financial_engine_providers.dart';
import '../data/repositories/liabilities_debts_assets_repository_impl.dart';
import '../domain/entities/asset_entity.dart';
import '../domain/entities/asset_valuation_history.dart';
import '../domain/entities/debt_entity.dart';
import '../domain/entities/debt_payment_entry_entity.dart';
import '../domain/entities/net_worth_snapshot.dart';
import '../domain/entities/obligation_entity.dart';
import '../domain/entities/obligation_payment_entity.dart';
import '../domain/repositories/liabilities_debts_assets_repository.dart';
import 'liabilities_debts_assets_state.dart';

/// موفر مستودع الالتزامات والديون والأصول
final liabilitiesDebtsAssetsRepositoryProvider =
    Provider<LiabilitiesDebtsAssetsRepository>((ref) {
  final db = ref.watch(databaseProvider);
  return LiabilitiesDebtsAssetsRepositoryImpl(db);
});

/// موفر متحكم الالتزامات والديون والأصول وصافي الثروة
final liabilitiesDebtsAssetsControllerProvider = StateNotifierProvider<
    LiabilitiesDebtsAssetsController, LiabilitiesDebtsAssetsState>((ref) {
  final repo = ref.watch(liabilitiesDebtsAssetsRepositoryProvider);
  final engine = ref.watch(centralFinancialEngineProvider);
  return LiabilitiesDebtsAssetsController(repository: repo, engine: engine);
});

/// متحكم إدارة الالتزامات، الديون والأقساط، الأصول الرأسمالية، وصافي الثروة
class LiabilitiesDebtsAssetsController
    extends StateNotifier<LiabilitiesDebtsAssetsState> {
  final LiabilitiesDebtsAssetsRepository _repository;
  final CentralFinancialEngine? _engine;

  LiabilitiesDebtsAssetsController({
    required LiabilitiesDebtsAssetsRepository repository,
    CentralFinancialEngine? engine,
  })  : _repository = repository,
        _engine = engine,
        super(const LiabilitiesDebtsAssetsState()) {
    loadAll();
  }

  /// تحميل كافة بيانات الالتزامات والديون والأصول وصافي الثروة
  Future<void> loadAll() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final obligations = await _repository.getAllObligations();
      final obligationPayments = await _repository.getAllObligationPayments();
      final debts = await _repository.getAllDebts();
      final assets = await _repository.getAllAssets();
      final netWorthHistory = await _repository.getNetWorthHistory();

      Money liquid = const Money.zero();
      if (_engine != null) {
        liquid = await _engine.getTotalFunds();
      }

      state = state.copyWith(
        isLoading: false,
        obligations: obligations,
        obligationPayments: obligationPayments,
        debts: debts,
        assets: assets,
        netWorthHistory: netWorthHistory,
        liquidFunds: liquid,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تحميل البيانات المالية: $e',
      );
    }
  }

  // ══════════════════════════════════════════════════════════════════
  // ── الالتزامات والاشتراكات (Obligations) ──────────────────────────
  // ══════════════════════════════════════════════════════════════════

  /// إنشاء التزام مالي جديد
  Future<bool> createObligation({
    required String title,
    String? billerName,
    required Money amount,
    ObligationRecurrence recurrenceType = ObligationRecurrence.monthly,
    int dueDayOfMonth = 1,
    DateTime? dueDate,
    String? linkedAccountId,
    bool isLockedFromSalary = true,
  }) async {
    if (title.trim().isEmpty) {
      state = state.copyWith(errorMessage: 'يرجى إدخال اسم الالتزام');
      return false;
    }
    if (!amount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ الالتزام يجب أن يكون موجباً');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final obligation = ObligationEntity(
        id: 'ob_${DateTime.now().millisecondsSinceEpoch}',
        title: title.trim(),
        billerName: billerName?.trim().isEmpty == true ? null : billerName?.trim(),
        amount: amount,
        recurrenceType: recurrenceType,
        dueDayOfMonth: dueDayOfMonth,
        dueDate: dueDate,
        linkedAccountId: linkedAccountId,
        isLockedFromSalary: isLockedFromSalary,
        isActive: true,
        createdAt: DateTime.now(),
      );

      await _repository.saveObligation(obligation);
      await loadAll();
      state = state.copyWith(successMessage: 'تمت إضافة الالتزام بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل حفظ الالتزام: $e',
      );
      return false;
    }
  }

  /// تسجيل سداد التزام مالي (يخصم من الحساب المحدد كـ مصروف)
  Future<bool> payObligation({
    required String obligationId,
    required String accountId,
    String? accountName,
    required Money amount,
    required DateTime paymentDate,
    String? notes,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ السداد يجب أن يكون موجباً');
      return false;
    }

    final obligation = await _repository.getObligationById(obligationId);
    if (obligation == null) {
      state = state.copyWith(errorMessage: 'الالتزام غير موجود');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      if (_engine != null) {
        await _engine.recordExpense(
          transactionId: 'txn_ob_${DateTime.now().millisecondsSinceEpoch}',
          accountId: accountId,
          categoryId: null,
          amount: amount,
          date: paymentDate,
          note: 'سداد التزام: ${obligation.title} - ${notes ?? ""}',
          idempotencyKey: idempotencyKey,
        );
      }

      final payment = ObligationPaymentEntity(
        id: 'ob_pay_${DateTime.now().millisecondsSinceEpoch}',
        obligationId: obligationId,
        obligationTitle: obligation.title,
        amount: amount,
        paymentDate: paymentDate,
        accountId: accountId,
        accountName: accountName,
        notes: notes,
        idempotencyKey: idempotencyKey,
      );
      await _repository.recordObligationPayment(payment);

      await loadAll();
      state = state.copyWith(successMessage: 'تم تسجيل سداد الالتزام بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تسجيل سداد الالتزام: $e',
      );
      return false;
    }
  }

  /// تعطيل التزام مالي
  Future<void> deactivateObligation(String id) async {
    try {
      await _repository.deactivateObligation(id);
      await loadAll();
    } catch (e) {
      state = state.copyWith(errorMessage: 'فشل تعطيل الالتزام: $e');
    }
  }

  // ══════════════════════════════════════════════════════════════════
  // ── الديون والأقساط (Debts & Installments) ────────────────────────
  // ══════════════════════════════════════════════════════════════════

  /// تسجيل دين جديد (دين عليّ أو دين لي)
  Future<bool> createDebt({
    required String title,
    required String counterpartyName,
    required DebtType type,
    required Money totalAmount,
    Money? monthlyInstallmentAmount,
    required DateTime startDate,
    DateTime? dueDate,
  }) async {
    if (title.trim().isEmpty) {
      state = state.copyWith(errorMessage: 'عنوان الدين مطلوب');
      return false;
    }
    if (counterpartyName.trim().isEmpty) {
      state = state.copyWith(errorMessage: 'اسم الطرف المعني مطلوب');
      return false;
    }
    if (!totalAmount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ الدين يجب أن يكون موجباً');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final debt = DebtEntity(
        id: 'debt_${DateTime.now().millisecondsSinceEpoch}',
        title: title.trim(),
        counterpartyName: counterpartyName.trim(),
        type: type,
        totalAmount: totalAmount,
        remainingAmount: totalAmount,
        monthlyInstallmentAmount: monthlyInstallmentAmount,
        startDate: startDate,
        dueDate: dueDate,
        status: DebtStatus.active,
      );

      await _repository.saveDebt(debt);
      await loadAll();
      state = state.copyWith(successMessage: 'تم تسجيل الدين بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تسجيل الدين: $e',
      );
      return false;
    }
  }

  /// سداد دفعة من الدين (دين عليّ يخصم من الحساب، دين لي يودع في الحساب)
  Future<bool> payDebtInstallment({
    required String debtId,
    required String accountId,
    String? accountName,
    required Money amount,
    required DateTime paymentDate,
    String? note,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ الدفعة يجب أن يكون موجباً');
      return false;
    }

    final debt = await _repository.getDebtById(debtId);
    if (debt == null) {
      state = state.copyWith(errorMessage: 'الدين غير موجود');
      return false;
    }
    if (debt.status == DebtStatus.settled) {
      state = state.copyWith(errorMessage: 'تم سداد هذا الدين بالكامل مسبقاً');
      return false;
    }
    if (amount > debt.remainingAmount) {
      state = state.copyWith(
        errorMessage: 'المبلغ المدفوع يتجاوز المبلغ المتبقي على الدين (${debt.remainingAmount.formatArabic()})',
      );
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      if (_engine != null) {
        if (debt.type == DebtType.payable) {
          // دين عليّ: دفع نقدي يخرج من حساب المستخدم
          await _engine.recordExpense(
            transactionId: 'txn_debt_pay_${DateTime.now().millisecondsSinceEpoch}',
            accountId: accountId,
            categoryId: null,
            amount: amount,
            date: paymentDate,
            note: 'سداد قسط دين: ${debt.title} - ${debt.counterpartyName}',
            idempotencyKey: idempotencyKey,
          );
        } else {
          // دين لي: تحصيل نقدي يدخل لحساب المستخدم
          await _engine.recordIncome(
            transactionId: 'txn_debt_rec_${DateTime.now().millisecondsSinceEpoch}',
            accountId: accountId,
            categoryId: null,
            amount: amount,
            date: paymentDate,
            note: 'تحصيل دفعة دين مستحق: ${debt.title} - من ${debt.counterpartyName}',
            idempotencyKey: idempotencyKey,
          );
        }
      }

      final payment = DebtPaymentEntryEntity(
        id: 'dp_${DateTime.now().millisecondsSinceEpoch}',
        debtId: debtId,
        accountId: accountId,
        accountName: accountName,
        amount: amount,
        paymentDate: paymentDate,
        note: note,
        idempotencyKey: idempotencyKey,
      );
      await _repository.recordDebtPayment(payment);

      await loadAll();
      state = state.copyWith(successMessage: 'تم تسجيل دفعة الدين وتحديث المتبقي بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تسجيل دفعة الدين: $e',
      );
      return false;
    }
  }

  // ══════════════════════════════════════════════════════════════════
  // ── الأصول الرأسمالية (Capital Assets) ────────────────────────────
  // ══════════════════════════════════════════════════════════════════

  /// تسجيل أصل جديد
  Future<bool> createAsset({
    required String title,
    required AssetCategory category,
    required Money purchaseCost,
    required Money currentMarketValue,
    required DateTime purchaseDate,
    String? notes,
  }) async {
    if (title.trim().isEmpty) {
      state = state.copyWith(errorMessage: 'اسم الأصل مطلوب');
      return false;
    }
    if (!purchaseCost.isPositive || !currentMarketValue.isPositive) {
      state = state.copyWith(errorMessage: 'قيمة الأصل وتكلفة الشراء يجب أن تكون موجبة');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final assetId = 'asset_${DateTime.now().millisecondsSinceEpoch}';
      final asset = AssetEntity(
        id: assetId,
        title: title.trim(),
        category: category,
        purchaseCost: purchaseCost,
        currentMarketValue: currentMarketValue,
        purchaseDate: purchaseDate,
        lastValuationDate: DateTime.now(),
        notes: notes?.trim().isEmpty == true ? null : notes?.trim(),
      );

      await _repository.saveAsset(asset);

      // تسجيل التقييم الافتتاحي
      await _repository.recordValuationHistory(
        AssetValuationHistory(
          id: 'val_${DateTime.now().millisecondsSinceEpoch}',
          assetId: assetId,
          valuationDate: DateTime.now(),
          marketValue: currentMarketValue,
          previousMarketValue: purchaseCost,
          reason: 'تقييم افتتاحي عند الإضافة',
        ),
      );

      await recordNetWorthSnapshot();
      await loadAll();
      state = state.copyWith(successMessage: 'تمت إضافة الأصل وحساب القيمة بنجاح');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل حفظ الأصل: $e',
      );
      return false;
    }
  }

  /// إعادة تقييم أصل وتحديث قيمته مع الاحتفاظ بتاريخ التقييم السابق
  Future<bool> revaluateAsset({
    required String assetId,
    required Money newMarketValue,
    String? reason,
  }) async {
    if (!newMarketValue.isPositive) {
      state = state.copyWith(errorMessage: 'القيمة السوقية الجديدة يجب أن تكون موجبة');
      return false;
    }

    final asset = await _repository.getAssetById(assetId);
    if (asset == null) {
      state = state.copyWith(errorMessage: 'الأصل غير موجود');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final oldVal = asset.currentMarketValue;
      final updated = asset.copyWith(
        currentMarketValue: newMarketValue,
        lastValuationDate: DateTime.now(),
      );

      await _repository.updateAsset(updated);

      await _repository.recordValuationHistory(
        AssetValuationHistory(
          id: 'val_${DateTime.now().millisecondsSinceEpoch}',
          assetId: assetId,
          valuationDate: DateTime.now(),
          marketValue: newMarketValue,
          previousMarketValue: oldVal,
          reason: reason ?? 'إعادة تقييم دورية',
        ),
      );

      await recordNetWorthSnapshot();
      await loadAll();
      state = state.copyWith(successMessage: 'تم تحديث تقييم الأصل وتوثيقه في التاريخ');
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل إعادة تقييم الأصل: $e',
      );
      return false;
    }
  }

  // ══════════════════════════════════════════════════════════════════
  // ── صافي الثروة (Net Worth Snapshots) ────────────────────────────
  // ══════════════════════════════════════════════════════════════════

  /// تسجيل لقطة فورية لصافي الثروة
  Future<void> recordNetWorthSnapshot() async {
    try {
      final snapshot = NetWorthSnapshot(
        date: DateTime.now(),
        liquidFunds: state.liquidFunds,
        capitalAssets: state.totalCapitalAssets,
        receivableDebts: state.totalReceivableDebtsRemaining,
        payableDebts: state.totalPayableDebtsRemaining,
        dueObligations: state.totalDueObligations,
      );
      await _repository.saveNetWorthSnapshot(snapshot);
    } catch (_) {}
  }
}

