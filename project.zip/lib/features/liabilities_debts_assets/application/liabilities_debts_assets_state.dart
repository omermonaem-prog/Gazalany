import 'package:my_finance/core/finance/money.dart';
import '../domain/entities/asset_entity.dart';
import '../domain/entities/asset_valuation_history.dart';
import '../domain/entities/debt_entity.dart';
import '../domain/entities/debt_payment_entry_entity.dart';
import '../domain/entities/net_worth_snapshot.dart';
import '../domain/entities/obligation_entity.dart';
import '../domain/entities/obligation_payment_entity.dart';

/// حالة واجهة الالتزامات والديون والأصول وصافي الثروة
class LiabilitiesDebtsAssetsState {
  final bool isLoading;
  final List<ObligationEntity> obligations;
  final List<ObligationPaymentEntity> obligationPayments;
  final List<DebtEntity> debts;
  final List<DebtPaymentEntryEntity> debtPayments;
  final List<AssetEntity> assets;
  final List<AssetValuationHistory> assetValuations;
  final List<NetWorthSnapshot> netWorthHistory;
  final Money liquidFunds; // السيولة الإجمالية بالحسابات
  final String? errorMessage;
  final String? successMessage;

  const LiabilitiesDebtsAssetsState({
    this.isLoading = false,
    this.obligations = const [],
    this.obligationPayments = const [],
    this.debts = const [],
    this.debtPayments = const [],
    this.assets = const [],
    this.assetValuations = const [],
    this.netWorthHistory = const [],
    this.liquidFunds = const Money.zero(),
    this.errorMessage,
    this.successMessage,
  });

  // ── الحسابات والمؤشرات المالية المشتقة ─────────────────────────

  /// إجمالي القيمة السوقية للأصول الرأسمالية
  Money get totalCapitalAssets => assets.fold<Money>(
        const Money.zero(),
        (sum, a) => sum + a.currentMarketValue,
      );

  /// إجمالي الديون المستحقة على المستخدم (Payable Debts)
  Money get totalPayableDebtsRemaining => debts
      .where((d) => d.type == DebtType.payable && d.status == DebtStatus.active)
      .fold<Money>(
        const Money.zero(),
        (sum, d) => sum + d.remainingAmount,
      );

  /// إجمالي الديون المستحقة للمستخدم (Receivable Debts)
  Money get totalReceivableDebtsRemaining => debts
      .where((d) => d.type == DebtType.receivable && d.status == DebtStatus.active)
      .fold<Money>(
        const Money.zero(),
        (sum, d) => sum + d.remainingAmount,
      );

  /// إجمالي الالتزامات الشهرية المحجوزة
  Money get totalMonthlyObligations => obligations
      .where((o) => o.isActive && o.recurrenceType == ObligationRecurrence.monthly)
      .fold<Money>(
        const Money.zero(),
        (sum, o) => sum + o.amount,
      );

  /// الالتزامات المتأخرة عن السداد حالياً
  List<ObligationEntity> get overdueObligations =>
      obligations.where((o) => o.isActive && o.isOverdue).toList();

  /// إجمالي المبالغ المتأخرة فورياً
  Money get totalDueObligations => overdueObligations.fold<Money>(
        const Money.zero(),
        (sum, o) => sum + o.amount,
      );

  /// إجمالي الأصول الكلي: السيولة + الأصول الرأسمالية + الديون المستحقة للمستخدم
  Money get totalOverallAssets =>
      liquidFunds + totalCapitalAssets + totalReceivableDebtsRemaining;

  /// إجمالي الخصوم والالتزامات الكلي: الديون المستحقة على المستخدم + الفواتير المتأخرة
  Money get totalOverallLiabilities =>
      totalPayableDebtsRemaining + totalDueObligations;

  /// صافي الثروة اللحظي الدقيق (Instant Net Worth)
  Money get currentNetWorth => totalOverallAssets - totalOverallLiabilities;

  LiabilitiesDebtsAssetsState copyWith({
    bool? isLoading,
    List<ObligationEntity>? obligations,
    List<ObligationPaymentEntity>? obligationPayments,
    List<DebtEntity>? debts,
    List<DebtPaymentEntryEntity>? debtPayments,
    List<AssetEntity>? assets,
    List<AssetValuationHistory>? assetValuations,
    List<NetWorthSnapshot>? netWorthHistory,
    Money? liquidFunds,
    String? errorMessage,
    bool clearError = false,
    String? successMessage,
    bool clearSuccess = false,
  }) {
    return LiabilitiesDebtsAssetsState(
      isLoading: isLoading ?? this.isLoading,
      obligations: obligations ?? this.obligations,
      obligationPayments: obligationPayments ?? this.obligationPayments,
      debts: debts ?? this.debts,
      debtPayments: debtPayments ?? this.debtPayments,
      assets: assets ?? this.assets,
      assetValuations: assetValuations ?? this.assetValuations,
      netWorthHistory: netWorthHistory ?? this.netWorthHistory,
      liquidFunds: liquidFunds ?? this.liquidFunds,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      successMessage: clearSuccess ? null : (successMessage ?? this.successMessage),
    );
  }
}

