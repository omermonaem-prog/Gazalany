import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../domain/entities/asset_entity.dart';
import 'package:my_finance/features/liabilities_debts_assets/application/liabilities_debts_assets_controller.dart';

/// شاشة إضافة أصل مالي جديد
class AddAssetScreen extends ConsumerStatefulWidget {
  const AddAssetScreen({super.key});

  @override
  ConsumerState<AddAssetScreen> createState() => _AddAssetScreenState();
}

class _AddAssetScreenState extends ConsumerState<AddAssetScreen> {
  final _titleController = TextEditingController();
  final _costController = TextEditingController();
  final _marketValueController = TextEditingController();
  final _notesController = TextEditingController();
  AssetCategory _category = AssetCategory.realEstate;
  String? _error;

  @override
  void dispose() {
    _titleController.dispose();
    _costController.dispose();
    _marketValueController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _error = null);

    final title = _titleController.text.trim();
    if (title.isEmpty) {
      setState(() => _error = 'اسم الأصل مطلوب');
      return;
    }

    Money cost;
    Money marketValue;
    try {
      cost = Money.parse(_costController.text.trim());
      marketValue = Money.parse(_marketValueController.text.trim());
      if (!cost.isPositive || !marketValue.isPositive) {
        setState(() => _error = 'المبالغ يجب أن تكون موجبة وأكبر من صفر');
        return;
      }
    } catch (_) {
      setState(() => _error = 'يرجى إدخال مبالغ صحيحة');
      return;
    }

    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);
    final success = await controller.createAsset(
      title: title,
      category: _category,
      purchaseCost: cost,
      currentMarketValue: marketValue,
      purchaseDate: DateTime.now(),
      notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
    );

    if (success && mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('تسجيل أصل رأسمالي جديد'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(
                labelText: 'اسم الأصل *',
                hintText: 'مثال: شقة سكنية بالرياض، سيارة كامري، سبائك ذهب...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.home_work_outlined),
              ),
            ),
            const SizedBox(height: 16),

            DropdownButtonFormField<AssetCategory>(
              value: _category,
              decoration: InputDecoration(
                labelText: 'تصنيف الأصل *',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.category_outlined),
              ),
              items: AssetCategory.values.map((c) {
                return DropdownMenuItem(value: c, child: Text(c.labelArabic));
              }).toList(),
              onChanged: (val) {
                if (val != null) setState(() => _category = val);
              },
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _costController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'تكلفة الشراء الأصلية (ر.س) *',
                hintText: '0.00',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.money_off_csred_outlined),
              ),
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _marketValueController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'القيمة السوقية التقديرية الحالية (ر.س) *',
                hintText: '0.00',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _notesController,
              maxLines: 2,
              decoration: InputDecoration(
                labelText: 'ملاحظات (اختياري)',
                hintText: 'تفاصيل الصك، رقم الهيكل، معلومات إضافية...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.note_alt_outlined),
              ),
            ),
            const SizedBox(height: 24),

            if (_error != null) ...[
              Text(
                _error!,
                style: AppTypography.bodySecondary.copyWith(
                  color: AppColors.criticalRed,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
            ],

            LuxuryButton(
              label: 'حفظ الأصل المالي',
              icon: Icons.check_circle_outline,
              onPressed: _submit,
            ),
          ],
        ),
      ),
    );
  }
}

