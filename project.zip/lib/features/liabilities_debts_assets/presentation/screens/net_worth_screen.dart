import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import 'package:my_finance/features/liabilities_debts_assets/application/liabilities_debts_assets_controller.dart';
import '../widgets/net_worth_summary_card.dart';

/// شاشة تفاصيل وتحليل صافي الثروة وسجل التغيرات
class NetWorthScreen extends ConsumerWidget {
  const NetWorthScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(liabilitiesDebtsAssetsControllerProvider);
    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('تحليل صافي الثروة'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadAll(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. Hero Card
              NetWorthSummaryCard(state: state),
              const SizedBox(height: 20),

              // 2. تحليل الأصول (+ Assets)
              Row(
                children: [
                  const Icon(Icons.arrow_upward_rounded, color: AppColors.cashIn, size: 20),
                  const SizedBox(width: 8),
                  Text('مكونات إجمالي الأصول (+)', style: AppTypography.headingH3),
                ],
              ),
              const SizedBox(height: 10),
              LuxuryCard(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _buildBreakdownRow(
                      title: 'السيولة الإجمالية بالحسابات',
                      subtitle: 'أرصدة البنوك والنقد والادخار',
                      amount: state.liquidFunds.formatArabic(),
                      color: AppColors.forestGreen,
                    ),
                    const Divider(height: 16),
                    _buildBreakdownRow(
                      title: 'الأصول والممتلكات الرأسمالية',
                      subtitle: 'عقارات، مركبات، ذهب، واستثمارات',
                      amount: state.totalCapitalAssets.formatArabic(),
                      color: AppColors.champagneGold,
                    ),
                    const Divider(height: 16),
                    _buildBreakdownRow(
                      title: 'ديون مستحقة لك عند الغير',
                      subtitle: 'أموال مقرضة متوقع تحصيلها',
                      amount: state.totalReceivableDebtsRemaining.formatArabic(),
                      color: AppColors.cashIn,
                    ),
                    const Divider(height: 20, thickness: 1.5),
                    _buildBreakdownRow(
                      title: 'إجمالي الأصول الشاملة',
                      subtitle: 'مجموع كل ما تملك',
                      amount: state.totalOverallAssets.formatArabic(),
                      color: AppColors.forestGreen,
                      isBold: true,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // 3. تحليل الخصوم والالتزامات (- Liabilities)
              Row(
                children: [
                  const Icon(Icons.arrow_downward_rounded, color: AppColors.criticalRed, size: 20),
                  const SizedBox(width: 8),
                  Text('مكونات إجمالي الخصوم والالتزامات (-)', style: AppTypography.headingH3),
                ],
              ),
              const SizedBox(height: 10),
              LuxuryCard(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _buildBreakdownRow(
                      title: 'الديون والقروض المستحقة عليك',
                      subtitle: 'المتبقي غير المسدد من القروض والأقساط',
                      amount: state.totalPayableDebtsRemaining.formatArabic(),
                      color: AppColors.cashOut,
                    ),
                    const Divider(height: 16),
                    _buildBreakdownRow(
                      title: 'الالتزامات والفواتير المتأخرة',
                      subtitle: 'فواتير واشتراكات حان موعد سدادها',
                      amount: state.totalDueObligations.formatArabic(),
                      color: AppColors.criticalRed,
                    ),
                    const Divider(height: 20, thickness: 1.5),
                    _buildBreakdownRow(
                      title: 'إجمالي الخصوم والالتزامات',
                      subtitle: 'مجموع كل ما هو مستحق عليك',
                      amount: state.totalOverallLiabilities.formatArabic(),
                      color: AppColors.criticalRed,
                      isBold: true,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // 4. سجل تاريخ صافي الثروة
              if (state.netWorthHistory.isNotEmpty) ...[
                Text('سجل التغيرات عبر الزمن', style: AppTypography.headingH3),
                const SizedBox(height: 10),
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: state.netWorthHistory.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final item = state.netWorthHistory[index];
                    return LuxuryCard(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${item.date.year}/${item.date.month.toString().padLeft(2, '0')}/${item.date.day.toString().padLeft(2, '0')}',
                                style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold),
                              ),
                              Text(
                                'أصول: ${item.totalAssets.formatArabic()} | خصوم: ${item.totalLiabilities.formatArabic()}',
                                style: AppTypography.bodySecondary.copyWith(fontSize: 11),
                              ),
                            ],
                          ),
                          Text(
                            item.netWorth.formatArabic(),
                            style: AppTypography.bodyPrimary.copyWith(
                              fontWeight: FontWeight.bold,
                              color: item.netWorth.isNegative ? AppColors.criticalRed : AppColors.forestGreen,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBreakdownRow({
    required String title,
    required String subtitle,
    required String amount,
    required Color color,
    bool isBold = false,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: isBold
                  ? AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold)
                  : AppTypography.bodyPrimary,
            ),
            Text(
              subtitle,
              style: AppTypography.bodySecondary.copyWith(fontSize: 11),
            ),
          ],
        ),
        Text(
          amount,
          style: AppTypography.bodyPrimary.copyWith(
            fontWeight: FontWeight.bold,
            color: color,
            fontSize: isBold ? 16 : 14,
          ),
        ),
      ],
    );
  }
}

