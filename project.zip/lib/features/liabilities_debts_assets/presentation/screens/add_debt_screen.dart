import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../domain/entities/debt_entity.dart';
import 'package:my_finance/features/liabilities_debts_assets/application/liabilities_debts_assets_controller.dart';

/// شاشة تسجيل دين جديد (عليّ أو لي)
class AddDebtScreen extends ConsumerStatefulWidget {
  const AddDebtScreen({super.key});

  @override
  ConsumerState<AddDebtScreen> createState() => _AddDebtScreenState();
}

class _AddDebtScreenState extends ConsumerState<AddDebtScreen> {
  final _titleController = TextEditingController();
  final _counterpartyController = TextEditingController();
  final _totalAmountController = TextEditingController();
  final _installmentController = TextEditingController();
  DebtType _debtType = DebtType.payable;
  DateTime? _dueDate;
  String? _error;

  @override
  void dispose() {
    _titleController.dispose();
    _counterpartyController.dispose();
    _totalAmountController.dispose();
    _installmentController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _error = null);

    final title = _titleController.text.trim();
    if (title.isEmpty) {
      setState(() => _error = 'عنوان الدين مطلوب');
      return;
    }

    final counterparty = _counterpartyController.text.trim();
    if (counterparty.isEmpty) {
      setState(() => _error = 'اسم الطرف المعني مطلوب');
      return;
    }

    Money totalAmount;
    try {
      totalAmount = Money.parse(_totalAmountController.text.trim());
      if (!totalAmount.isPositive) {
        setState(() => _error = 'مبلغ الدين يجب أن يكون موجباً');
        return;
      }
    } catch (_) {
      setState(() => _error = 'يرجى إدخال مبلغ صحيح');
      return;
    }

    Money? monthlyInstallment;
    if (_installmentController.text.trim().isNotEmpty) {
      try {
        monthlyInstallment = Money.parse(_installmentController.text.trim());
      } catch (_) {}
    }

    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);
    final success = await controller.createDebt(
      title: title,
      counterpartyName: counterparty,
      type: _debtType,
      totalAmount: totalAmount,
      monthlyInstallmentAmount: monthlyInstallment,
      startDate: DateTime.now(),
      dueDate: _dueDate,
    );

    if (success && mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('تسجيل دين أو تمويل'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Debt Type selector
            Text('نوع الدين *', style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: ChoiceChip(
                    label: const Text('دين عليّ (التزام/قرض)'),
                    selected: _debtType == DebtType.payable,
                    selectedColor: AppColors.cashOut.withValues(alpha: 0.15),
                    labelStyle: TextStyle(
                      color: _debtType == DebtType.payable ? AppColors.cashOut : AppColors.textMain,
                      fontWeight: FontWeight.bold,
                    ),
                    onSelected: (_) => setState(() => _debtType = DebtType.payable),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ChoiceChip(
                    label: const Text('دين لي (مستحق عند الغير)'),
                    selected: _debtType == DebtType.receivable,
                    selectedColor: AppColors.cashIn.withValues(alpha: 0.15),
                    labelStyle: TextStyle(
                      color: _debtType == DebtType.receivable ? AppColors.cashIn : AppColors.textMain,
                      fontWeight: FontWeight.bold,
                    ),
                    onSelected: (_) => setState(() => _debtType = DebtType.receivable),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _titleController,
              decoration: InputDecoration(
                labelText: 'عنوان الدين / القسط *',
                hintText: 'مثال: تمويل شخصي، قرض سيارة، سلفة لصديق...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.title_rounded),
              ),
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _counterpartyController,
              decoration: InputDecoration(
                labelText: _debtType == DebtType.payable ? 'اسم الدائن (البنك أو الشخص) *' : 'اسم المدين (المستلف) *',
                hintText: 'مثال: بنك الراجحي، فلان الفلاني...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.person_outline_rounded),
              ),
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _totalAmountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'إجمالي مبلغ الدين (ر.س) *',
                hintText: '0.00',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _installmentController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'قيمة القسط الشهري (اختياري)',
                hintText: '0.00',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.calendar_month_outlined),
              ),
            ),
            const SizedBox(height: 24),

            if (_error != null) ...[
              Text(
                _error!,
                style: AppTypography.bodySecondary.copyWith(
                  color: AppColors.criticalRed,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
            ],

            LuxuryButton(
              label: 'حفظ الدين',
              icon: Icons.check_circle_outline,
              onPressed: _submit,
            ),
          ],
        ),
      ),
    );
  }
}

