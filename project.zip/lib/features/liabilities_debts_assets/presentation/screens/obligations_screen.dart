import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/obligation_entity.dart';
import 'package:my_finance/features/liabilities_debts_assets/application/liabilities_debts_assets_controller.dart';
import '../widgets/obligation_card.dart';
import 'add_obligation_screen.dart';

/// شاشة إدارة الالتزامات والفواتير والاشتراكات المتكررة
class ObligationsScreen extends ConsumerStatefulWidget {
  const ObligationsScreen({super.key});

  @override
  ConsumerState<ObligationsScreen> createState() => _ObligationsScreenState();
}

class _ObligationsScreenState extends ConsumerState<ObligationsScreen> {
  void _showPaymentDialog(BuildContext context, ObligationEntity obligation) {
    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);
    final amountController = TextEditingController(text: obligation.amount.toMajorUnits().toStringAsFixed(2));
    final notesController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('تسجيل سداد الالتزام', style: AppTypography.headingH3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('الالتزام: ${obligation.title}', style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
              controller: amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'المبلغ المدفوع (ر.س) *',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: notesController,
              decoration: InputDecoration(
                labelText: 'ملاحظات (اختياري)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.forestGreen,
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              try {
                final amt = Money.parse(amountController.text.trim());
                final idpKey = 'pay_ob_${DateTime.now().millisecondsSinceEpoch}';
                await controller.payObligation(
                  obligationId: obligation.id,
                  accountId: obligation.linkedAccountId ?? 'acc_main',
                  amount: amt,
                  paymentDate: DateTime.now(),
                  notes: notesController.text.trim().isEmpty ? null : notesController.text.trim(),
                  idempotencyKey: idpKey,
                );
                if (context.mounted) Navigator.pop(ctx);
              } catch (_) {}
            },
            child: const Text('تأكيد السداد'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(liabilitiesDebtsAssetsControllerProvider);
    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('الالتزامات والاشتراكات'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddObligationScreen()),
          );
        },
        backgroundColor: AppColors.forestGreen,
        icon: const Icon(Icons.add, color: Colors.white),
        label: Text(
          'التزام جديد',
          style: AppTypography.bodyPrimary.copyWith(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadAll(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Summary card
              LuxuryCard(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('المجموع الشهري المحجوز', style: AppTypography.bodySecondary),
                        const SizedBox(height: 2),
                        Text(
                          state.totalMonthlyObligations.formatArabic(),
                          style: AppTypography.headingH2.copyWith(
                            color: AppColors.forestGreen,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('المتأخرات فورياً', style: AppTypography.bodySecondary),
                        const SizedBox(height: 2),
                        Text(
                          state.totalDueObligations.formatArabic(),
                          style: AppTypography.headingH2.copyWith(
                            color: state.totalDueObligations.isZero ? AppColors.forestGreen : AppColors.criticalRed,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              if (state.obligations.isEmpty)
                LuxuryCard(
                  padding: const EdgeInsets.all(32),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(
                          Icons.receipt_long_outlined,
                          size: 40,
                          color: AppColors.slateMuted.withValues(alpha: 0.5),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'لا توجد التزامات أو فواتير مسجلة حالياً',
                          style: AppTypography.bodySecondary,
                        ),
                      ],
                    ),
                  ),
                )
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: state.obligations.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final item = state.obligations[index];
                    return ObligationCard(
                      obligation: item,
                      onPay: () => _showPaymentDialog(context, item),
                      onDeactivate: () => controller.deactivateObligation(item.id),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

