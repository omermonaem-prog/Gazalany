import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import 'package:my_finance/features/liabilities_debts_assets/application/liabilities_debts_assets_controller.dart';
import '../widgets/net_worth_summary_card.dart';
import 'assets_screen.dart';
import 'debts_screen.dart';
import 'net_worth_screen.dart';
import 'obligations_screen.dart';

/// الشاشة الرئيسية الموحدة للالتزامات، الديون، الأصول، وصافي الثروة
class LiabilitiesDebtsOverviewScreen extends ConsumerWidget {
  const LiabilitiesDebtsOverviewScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(liabilitiesDebtsAssetsControllerProvider);
    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('الالتزامات والديون والأصول'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadAll(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. بطاقة صافي الثروة الشاملة (Hero Card)
              NetWorthSummaryCard(
                state: state,
                onTapDetails: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const NetWorthScreen()),
                  );
                },
              ),
              const SizedBox(height: 20),

              // 2. شبكة الأقسام المالية الثلاثة
              Text('الأقسام المالية', style: AppTypography.headingH3),
              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: _buildSectionCard(
                      context: context,
                      title: 'الالتزامات والفواتير',
                      subtitle: '${state.obligations.length} التزام',
                      amount: state.totalMonthlyObligations.formatArabic(),
                      icon: Icons.receipt_long_rounded,
                      color: AppColors.forestGreen,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const ObligationsScreen()),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildSectionCard(
                      context: context,
                      title: 'الديون والأقساط',
                      subtitle: '${state.debts.length} قسط ودين',
                      amount: state.totalPayableDebtsRemaining.formatArabic(),
                      icon: Icons.handshake_outlined,
                      color: AppColors.cashOut,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const DebtsScreen()),
                        );
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: _buildSectionCard(
                      context: context,
                      title: 'الأصول الرأسمالية',
                      subtitle: '${state.assets.length} أصل مالي',
                      amount: state.totalCapitalAssets.formatArabic(),
                      icon: Icons.account_balance_rounded,
                      color: AppColors.champagneGold,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const AssetsScreen()),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildSectionCard(
                      context: context,
                      title: 'تفاصيل صافي الثروة',
                      subtitle: 'تحليل الأصول والخصوم',
                      amount: state.currentNetWorth.formatArabic(),
                      icon: Icons.analytics_outlined,
                      color: AppColors.forestGreen,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const NetWorthScreen()),
                        );
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // 3. قسم التنبيهات: الالتزامات المتأخرة
              if (state.overdueObligations.isNotEmpty) ...[
                Row(
                  children: [
                    const Icon(Icons.warning_amber_rounded, color: AppColors.criticalRed, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      'التزامات متأخرة عن السداد (${state.overdueObligations.length})',
                      style: AppTypography.headingH3.copyWith(color: AppColors.criticalRed),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                LuxuryCard(
                  borderColor: AppColors.criticalRed.withValues(alpha: 0.3),
                  child: Column(
                    children: state.overdueObligations.map((o) {
                      return ListTile(
                        leading: const Icon(Icons.error_outline, color: AppColors.criticalRed),
                        title: Text(o.title, style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold)),
                        subtitle: Text('يوم ${o.dueDayOfMonth} من الشهر', style: AppTypography.bodySecondary),
                        trailing: Text(
                          o.amount.formatArabic(),
                          style: AppTypography.bodyPrimary.copyWith(
                            fontWeight: FontWeight.bold,
                            color: AppColors.criticalRed,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionCard({
    required BuildContext context,
    required String title,
    required String subtitle,
    required String amount,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return LuxuryCard(
      onTap: onTap,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(height: 12),
          Text(title, style: AppTypography.headingH3.copyWith(fontSize: 14)),
          const SizedBox(height: 2),
          Text(subtitle, style: AppTypography.bodySecondary.copyWith(fontSize: 11)),
          const SizedBox(height: 8),
          Text(
            amount,
            style: AppTypography.bodyPrimary.copyWith(
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

