import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../domain/entities/debt_entity.dart';

/// بطاقة عرض الدين أو القسط
class DebtCard extends StatelessWidget {
  final DebtEntity debt;
  final VoidCallback? onTap;
  final VoidCallback? onPayInstallment;

  const DebtCard({
    super.key,
    required this.debt,
    this.onTap,
    this.onPayInstallment,
  });

  @override
  Widget build(BuildContext context) {
    final isPayable = debt.type == DebtType.payable;
    final progress = debt.progressPercentage / 100.0;
    final isSettled = debt.status == DebtStatus.settled;

    return LuxuryCard(
      onTap: onTap,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: isPayable
                      ? AppColors.cashOut.withValues(alpha: 0.12)
                      : AppColors.cashIn.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  isPayable ? Icons.call_made_rounded : Icons.call_received_rounded,
                  color: isPayable ? AppColors.cashOut : AppColors.cashIn,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      debt.title,
                      style: AppTypography.headingH3,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'الطرف: ${debt.counterpartyName}',
                      style: AppTypography.bodySecondary,
                    ),
                  ],
                ),
              ),
              StatusBadge(
                text: isSettled ? 'تم السداد' : debt.type.labelArabic,
                color: isSettled
                    ? AppColors.surfaceSubtleLight
                    : (isPayable
                        ? AppColors.cashOut.withValues(alpha: 0.12)
                        : AppColors.cashIn.withValues(alpha: 0.12)),
                textColor: isSettled
                    ? AppColors.slateMuted
                    : (isPayable ? AppColors.cashOut : AppColors.cashIn),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Amounts row: Original, Paid, Remaining
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('المبلغ الأصلي', style: AppTypography.bodySecondary),
                  const SizedBox(height: 2),
                  Text(
                    debt.totalAmount.formatArabic(),
                    style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('المسدد', style: AppTypography.bodySecondary),
                  const SizedBox(height: 2),
                  Text(
                    debt.paidAmount.formatArabic(),
                    style: AppTypography.bodyPrimary.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppColors.cashIn,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('المتبقي', style: AppTypography.bodySecondary),
                  const SizedBox(height: 2),
                  Text(
                    debt.remainingAmount.formatArabic(),
                    style: AppTypography.bodyPrimary.copyWith(
                      fontWeight: FontWeight.bold,
                      color: isSettled ? AppColors.slateMuted : AppColors.cashOut,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Progress Bar
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: progress.clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor: AppColors.surfaceSubtleLight,
              valueColor: AlwaysStoppedAnimation<Color>(
                isSettled ? AppColors.forestGreen : AppColors.champagneGold,
              ),
            ),
          ),
          const SizedBox(height: 6),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'تم سداد ${debt.progressPercentage.toStringAsFixed(1)}%',
                style: AppTypography.bodySecondary.copyWith(fontSize: 12),
              ),
              if (debt.monthlyInstallmentAmount != null && !isSettled)
                Text(
                  'القسط: ${debt.monthlyInstallmentAmount!.formatArabic()}/شهر',
                  style: AppTypography.bodySecondary.copyWith(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
            ],
          ),

          if (!isSettled) ...[
            const SizedBox(height: 14),
            ElevatedButton.icon(
              onPressed: onPayInstallment,
              icon: Icon(
                isPayable ? Icons.payment_rounded : Icons.move_to_inbox_rounded,
                size: 18,
              ),
              label: Text(isPayable ? 'سداد دفعة / قسط' : 'تحصيل دفعة'),
              style: ElevatedButton.styleFrom(
                backgroundColor: isPayable ? AppColors.forestGreen : AppColors.cashIn,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 0,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

