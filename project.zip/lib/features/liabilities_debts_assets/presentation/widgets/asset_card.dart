import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../domain/entities/asset_entity.dart';

/// بطاقة عرض الأصل الرأسمالي
class AssetCard extends StatelessWidget {
  final AssetEntity asset;
  final VoidCallback? onRevaluate;

  const AssetCard({
    super.key,
    required this.asset,
    this.onRevaluate,
  });

  @override
  Widget build(BuildContext context) {
    final isGaining = asset.isGaining;
    final gainPercentage = asset.gainLossPercentage;

    return LuxuryCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.champagneGold.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.account_balance_wallet_outlined,
                  color: AppColors.champagneGold,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      asset.title,
                      style: AppTypography.headingH3,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      asset.category.labelArabic,
                      style: AppTypography.bodySecondary,
                    ),
                  ],
                ),
              ),
              StatusBadge(
                text: '${isGaining ? "+" : ""}${gainPercentage.toStringAsFixed(1)}%',
                color: isGaining
                    ? AppColors.cashIn.withValues(alpha: 0.12)
                    : AppColors.criticalRed.withValues(alpha: 0.12),
                textColor: isGaining ? AppColors.cashIn : AppColors.criticalRed,
              ),
            ],
          ),
          const SizedBox(height: 16),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('القيمة السوقية الحالية', style: AppTypography.bodySecondary),
                  const SizedBox(height: 2),
                  Text(
                    asset.currentMarketValue.formatArabic(),
                    style: AppTypography.bodyPrimary.copyWith(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: AppColors.forestGreen,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('تكلفة الشراء الأصلية', style: AppTypography.bodySecondary),
                  const SizedBox(height: 2),
                  Text(
                    asset.purchaseCost.formatArabic(),
                    style: AppTypography.bodyPrimary.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 10),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'آخر تقييم: ${asset.lastValuationDate.year}/${asset.lastValuationDate.month.toString().padLeft(2, '0')}/${asset.lastValuationDate.day.toString().padLeft(2, '0')}',
                style: AppTypography.bodySecondary.copyWith(fontSize: 11),
              ),
              Text(
                'الفرق: ${isGaining ? "+" : ""}${asset.unrealizedGainLoss.formatArabic()}',
                style: AppTypography.bodySecondary.copyWith(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: isGaining ? AppColors.cashIn : AppColors.criticalRed,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          OutlinedButton.icon(
            onPressed: onRevaluate,
            icon: const Icon(Icons.edit_calendar_rounded, size: 16),
            label: const Text('تحديث التقييم السوقي'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.forestGreen,
              side: const BorderSide(color: AppColors.forestGreen),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

