import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import 'package:my_finance/features/liabilities_debts_assets/application/liabilities_debts_assets_state.dart';

/// بطاقة عرض صافي الثروة الشاملة (Net Worth Summary Card)
class NetWorthSummaryCard extends StatelessWidget {
  final LiabilitiesDebtsAssetsState state;
  final VoidCallback? onTapDetails;

  const NetWorthSummaryCard({
    super.key,
    required this.state,
    this.onTapDetails,
  });

  @override
  Widget build(BuildContext context) {
    final netWorth = state.currentNetWorth;
    final isPositive = !netWorth.isNegative;

    return LuxuryCard(
      onTap: onTapDetails,
      backgroundColor: AppColors.forestGreen,
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppColors.champagneGold.withValues(alpha: 0.2),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.balance_rounded,
                      color: AppColors.champagneGold,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'صافي الثروة المالي (Net Worth)',
                    style: AppTypography.bodySecondary.copyWith(
                      color: Colors.white70,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              if (onTapDetails != null)
                const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.white60),
            ],
          ),
          const SizedBox(height: 14),

          Text(
            netWorth.formatArabic(),
            style: AppTypography.displayLarge.copyWith(
              color: isPositive ? AppColors.champagneGoldBright : AppColors.criticalRed,
              fontWeight: FontWeight.bold,
              fontSize: 32,
            ),
          ),
          const SizedBox(height: 18),

          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    Text(
                      'إجمالي الأصول (+)',
                      style: AppTypography.bodySecondary.copyWith(
                        color: Colors.white70,
                        fontSize: 11,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      state.totalOverallAssets.formatArabic(),
                      style: AppTypography.bodyPrimary.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Container(width: 1, height: 28, color: Colors.white24),
                Column(
                  children: [
                    Text(
                      'إجمالي الخصوم (-)',
                      style: AppTypography.bodySecondary.copyWith(
                        color: Colors.white70,
                        fontSize: 11,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      state.totalOverallLiabilities.formatArabic(),
                      style: AppTypography.bodyPrimary.copyWith(
                        color: const Color(0xFFFF8E8E),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

