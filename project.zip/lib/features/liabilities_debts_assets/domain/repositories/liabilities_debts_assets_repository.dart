import '../entities/asset_entity.dart';
import '../entities/asset_valuation_history.dart';
import '../entities/debt_entity.dart';
import '../entities/debt_payment_entry_entity.dart';
import '../entities/net_worth_snapshot.dart';
import '../entities/obligation_entity.dart';
import '../entities/obligation_payment_entity.dart';

/// العقد التجريدي لمستودع الالتزامات والديون والأصول وصافي الثروة
abstract class LiabilitiesDebtsAssetsRepository {
  // ── الالتزامات والفواتير ──────────────────────────────────────
  Future<List<ObligationEntity>> getAllObligations();
  Future<ObligationEntity?> getObligationById(String id);
  Future<void> saveObligation(ObligationEntity obligation);
  Future<void> updateObligation(ObligationEntity obligation);
  Future<void> deactivateObligation(String id);
  Future<void> recordObligationPayment(ObligationPaymentEntity payment);
  Future<List<ObligationPaymentEntity>> getPaymentsForObligation(String obligationId);
  Future<List<ObligationPaymentEntity>> getAllObligationPayments();

  // ── الديون والأقساط ───────────────────────────────────────────
  Future<List<DebtEntity>> getAllDebts();
  Future<DebtEntity?> getDebtById(String id);
  Future<void> saveDebt(DebtEntity debt);
  Future<void> updateDebt(DebtEntity debt);
  Future<void> recordDebtPayment(DebtPaymentEntryEntity payment);
  Future<List<DebtPaymentEntryEntity>> getPaymentsForDebt(String debtId);

  // ── الأصول الرأسمالية ──────────────────────────────────────────
  Future<List<AssetEntity>> getAllAssets();
  Future<AssetEntity?> getAssetById(String id);
  Future<void> saveAsset(AssetEntity asset);
  Future<void> updateAsset(AssetEntity asset);
  Future<void> recordValuationHistory(AssetValuationHistory history);
  Future<List<AssetValuationHistory>> getValuationHistoryForAsset(String assetId);

  // ── صافي الثروة ───────────────────────────────────────────────
  Future<void> saveNetWorthSnapshot(NetWorthSnapshot snapshot);
  Future<List<NetWorthSnapshot>> getNetWorthHistory();
}

