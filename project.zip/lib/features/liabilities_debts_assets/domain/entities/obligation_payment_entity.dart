import '../../../../core/finance/money.dart';

/// سجل دفعة التزام مالي (Obligation Payment Log)
class ObligationPaymentEntity {
  final String id;
  final String obligationId;
  final String obligationTitle;
  final Money amount;
  final DateTime paymentDate;
  final String accountId;
  final String? accountName;
  final String? notes;
  final String idempotencyKey;

  const ObligationPaymentEntity({
    required this.id,
    required this.obligationId,
    required this.obligationTitle,
    required this.amount,
    required this.paymentDate,
    required this.accountId,
    this.accountName,
    this.notes,
    required this.idempotencyKey,
  });
}

