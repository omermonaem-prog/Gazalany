import '../../../../core/finance/money.dart';

enum AssetCategory {
  realEstate,
  vehicle,
  gold,
  stocks,
  business,
  other;

  String get labelArabic {
    switch (this) {
      case AssetCategory.realEstate:
        return 'عقار وأراضي';
      case AssetCategory.vehicle:
        return 'مركبة وسيارة';
      case AssetCategory.gold:
        return 'ذهب ومعادن ثمينة';
      case AssetCategory.stocks:
        return 'أسهم واستثمارات';
      case AssetCategory.business:
        return 'مشروع تجاري';
      case AssetCategory.other:
        return 'أصول أخرى';
    }
  }

  static AssetCategory fromString(String val) {
    switch (val.toLowerCase()) {
      case 'real_estate':
      case 'realestate':
        return AssetCategory.realEstate;
      case 'vehicle':
        return AssetCategory.vehicle;
      case 'gold':
        return AssetCategory.gold;
      case 'stocks':
        return AssetCategory.stocks;
      case 'business':
        return AssetCategory.business;
      default:
        return AssetCategory.other;
    }
  }
}

/// كيان الأصل الرأسمالي (Capital Asset Entity)
class AssetEntity {
  final String id;
  final String title;
  final AssetCategory category;
  final Money purchaseCost;
  final Money currentMarketValue;
  final DateTime purchaseDate;
  final DateTime lastValuationDate;
  final String? notes;

  const AssetEntity({
    required this.id,
    required this.title,
    required this.category,
    required this.purchaseCost,
    required this.currentMarketValue,
    required this.purchaseDate,
    required this.lastValuationDate,
    this.notes,
  });

  /// العائد / الربح الرأسمالي غير المحقق: Market Value - Purchase Cost
  Money get unrealizedGainLoss => currentMarketValue - purchaseCost;

  /// نسبة الربح أو الخسارة الرأسمالية (%)
  double get gainLossPercentage {
    if (purchaseCost.minorUnits <= 0) return 0.0;
    final diff = currentMarketValue.minorUnits - purchaseCost.minorUnits;
    return (diff / purchaseCost.minorUnits) * 100.0;
  }

  /// هل حقق الأصل نمواً بالقيمة
  bool get isGaining => currentMarketValue > purchaseCost;

  AssetEntity copyWith({
    String? id,
    String? title,
    AssetCategory? category,
    Money? purchaseCost,
    Money? currentMarketValue,
    DateTime? purchaseDate,
    DateTime? lastValuationDate,
    String? notes,
  }) {
    return AssetEntity(
      id: id ?? this.id,
      title: title ?? this.title,
      category: category ?? this.category,
      purchaseCost: purchaseCost ?? this.purchaseCost,
      currentMarketValue: currentMarketValue ?? this.currentMarketValue,
      purchaseDate: purchaseDate ?? this.purchaseDate,
      lastValuationDate: lastValuationDate ?? this.lastValuationDate,
      notes: notes ?? this.notes,
    );
  }
}

