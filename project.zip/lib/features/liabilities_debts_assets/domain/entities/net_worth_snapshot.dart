import '../../../../core/finance/money.dart';

/// لقطة صافي الثروة التاريخية واللحظية (Net Worth Snapshot)
///
/// المعادلة المحاسبية المعتمدة في FINANCIAL_RULES.md:
/// NetWorth = (Total Liquid Funds + Capital Assets Market Value + Receivable Debts)
///          - (Payable Debts Remaining + Due Obligations)
class NetWorthSnapshot {
  final DateTime date;
  final Money liquidFunds; // إجمالي الأرصدة البنكية والسيولة والادخار
  final Money capitalAssets; // القيمة السوقية للأصول
  final Money receivableDebts; // ديون مستحقة للمستخدم (أصول متداولة)
  final Money payableDebts; // ديون مستحقة على المستخدم (التزامات)
  final Money dueObligations; // التزامات وفواتير مستحقة

  const NetWorthSnapshot({
    required this.date,
    required this.liquidFunds,
    required this.capitalAssets,
    required this.receivableDebts,
    required this.payableDebts,
    required this.dueObligations,
  });

  /// إجمالي الأصول الشاملة (Assets)
  Money get totalAssets => liquidFunds + capitalAssets + receivableDebts;

  /// إجمالي الالتزامات والديون (Liabilities)
  Money get totalLiabilities => payableDebts + dueObligations;

  /// صافي الثروة (Net Worth = Total Assets - Total Liabilities)
  Money get netWorth => totalAssets - totalLiabilities;
}

