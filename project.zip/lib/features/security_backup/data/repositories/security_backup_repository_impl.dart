import 'dart:convert';
import '../../../../core/database/app_database.dart';
import 'package:my_finance/features/security_backup/application/services/data_integrity_verifier.dart';
import 'package:my_finance/features/security_backup/domain/entities/app_lock_config.dart';
import 'package:my_finance/features/security_backup/domain/entities/backup_metadata.dart';
import 'package:my_finance/features/security_backup/domain/entities/backup_payload.dart';
import 'package:my_finance/features/security_backup/domain/repositories/security_backup_repository.dart';

/// تطبيق مستودع الأمان والنسخ الاحتياطي بالاعتماد على قاعدة البيانات المحلية
class SecurityBackupRepositoryImpl implements SecurityBackupRepository {
  final AppDatabase _db;
  AppLockConfig _cachedConfig = const AppLockConfig();
  final Map<String, BackupPayload> _cachedBackups = {};

  SecurityBackupRepositoryImpl(this._db);

  @override
  Future<AppLockConfig> getAppLockConfig() async => _cachedConfig;

  @override
  Future<void> saveAppLockConfig(AppLockConfig config) async {
    _cachedConfig = config;
  }

  @override
  Future<List<BackupMetadata>> getAllBackups() async {
    final list = _cachedBackups.values.map((p) => p.metadata).toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  @override
  Future<BackupPayload?> getBackupPayload(String backupId) async =>
      _cachedBackups[backupId];

  @override
  Future<void> saveBackup(BackupPayload payload) async {
    _cachedBackups[payload.metadata.id] = payload;
  }

  @override
  Future<void> deleteBackup(String backupId) async {
    _cachedBackups.remove(backupId);
  }

  @override
  Future<BackupPayload> createBackupPayload({bool isAutomatic = false}) async {
    final now = DateTime.now();
    final id = 'backup_${now.millisecondsSinceEpoch}';
    final dateStr = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    final filename = 'myfinance_backup_$dateStr.json';

    // جمع بيانات الجداول من قاعدة البيانات
    final accounts = await _db.accountsDao.getAllAccounts();
    final txns = await _db.transactionsDao.getRecentTransactions(1000);
    final emergencyConfig = await _db.emergencyFundDao.getConfig();

    final data = {
      'accounts': accounts.map((a) => {
        'id': a.id,
        'name': a.name,
        'type': a.type,
        'currency': a.currency,
        'balanceMinorUnits': a.balanceMinorUnits,
      }).toList(),
      'transactions': txns.map((t) => {
        'id': t.id,
        'accountId': t.accountId,
        'type': t.type,
        'amountMinorUnits': t.amountMinorUnits,
        'transactionDate': t.transactionDate.toIso8601String(),
        'note': t.note,
      }).toList(),
      'emergencyFund': {
        'currentMinorUnits': emergencyConfig?.currentMinorUnits ?? 0,
        'targetMinorUnits': emergencyConfig?.targetMinorUnits ?? 0,
      },
    };

    final dataJson = json.encode(data);
    final checksum = DataIntegrityVerifier.calculateSha256(dataJson);
    final sizeBytes = utf8.encode(dataJson).length;

    final metadata = BackupMetadata(
      id: id,
      filename: filename,
      createdAt: now,
      sizeInBytes: sizeBytes,
      schemaVersion: 1,
      appVersion: '1.0.0',
      checksumSha256: checksum,
      isAutomatic: isAutomatic,
      totalAccounts: accounts.length,
      totalTransactions: txns.length,
    );

    final payload = BackupPayload(
      metadata: metadata,
      data: data,
    );

    _cachedBackups[id] = payload;
    return payload;
  }

  @override
  Future<bool> restoreFromPayload(BackupPayload payload) async {
    // 1. التحقق من سلامة البصمة (SHA-256 Checksum)
    final payloadJson = json.encode(payload.data);
    final isValid = DataIntegrityVerifier.verifyChecksum(
      data: payloadJson,
      expectedChecksum: payload.metadata.checksumSha256,
    );

    if (!isValid) {
      throw ArgumentError('فشل فحص سلامة النسخة الاحتياطية (Checksum Mismatch).');
    }

    if (payload.metadata.schemaVersion > 1) {
      throw ArgumentError('إصدار المخطط غير مدعوم في هذا الإصدار.');
    }

    return true;
  }
}

