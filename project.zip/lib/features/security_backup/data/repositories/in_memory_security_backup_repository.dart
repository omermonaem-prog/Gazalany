import 'dart:convert';
import 'package:my_finance/features/security_backup/application/services/data_integrity_verifier.dart';
import 'package:my_finance/features/security_backup/domain/entities/app_lock_config.dart';
import 'package:my_finance/features/security_backup/domain/entities/backup_metadata.dart';
import 'package:my_finance/features/security_backup/domain/entities/backup_payload.dart';
import 'package:my_finance/features/security_backup/domain/repositories/security_backup_repository.dart';

/// تطبيق محاكي لذاكرة الوصول العشوائي لمستودع الأمان والنسخ الاحتياطي
class InMemorySecurityBackupRepository implements SecurityBackupRepository {
  AppLockConfig lockConfig = const AppLockConfig();
  final Map<String, BackupPayload> backups = {};

  // محاكاة لبيانات التطبيق الأساسية
  Map<String, dynamic> simulatedAppData = {
    'accounts': [
      {'id': 'acc_1', 'name': 'الراجحي', 'balanceMinorUnits': 1000000},
      {'id': 'acc_2', 'name': 'الأهلي ادخار', 'balanceMinorUnits': 500000},
    ],
    'transactions': [
      {'id': 'tx_1', 'amountMinorUnits': 25000, 'type': 'expense'},
      {'id': 'tx_2', 'amountMinorUnits': 1200000, 'type': 'income'},
    ],
    'generalSavingsMinorUnits': 500000,
    'emergencyFundMinorUnits': 1000000,
  };

  @override
  Future<AppLockConfig> getAppLockConfig() async => lockConfig;

  @override
  Future<void> saveAppLockConfig(AppLockConfig config) async {
    lockConfig = config;
  }

  @override
  Future<List<BackupMetadata>> getAllBackups() async {
    final list = backups.values.map((p) => p.metadata).toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  @override
  Future<BackupPayload?> getBackupPayload(String backupId) async =>
      backups[backupId];

  @override
  Future<void> saveBackup(BackupPayload payload) async {
    backups[payload.metadata.id] = payload;
  }

  @override
  Future<void> deleteBackup(String backupId) async {
    backups.remove(backupId);
  }

  @override
  Future<BackupPayload> createBackupPayload({bool isAutomatic = false}) async {
    final now = DateTime.now();
    final id = 'backup_${now.millisecondsSinceEpoch}';
    final dateStr = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    final filename = 'myfinance_backup_$dateStr.json';

    // نسخ البيانات الحالية
    final dataCopy = Map<String, dynamic>.from(simulatedAppData);
    final dataJson = json.encode(dataCopy);
    final checksum = DataIntegrityVerifier.calculateSha256(dataJson);
    final sizeBytes = utf8.encode(dataJson).length;

    final metadata = BackupMetadata(
      id: id,
      filename: filename,
      createdAt: now,
      sizeInBytes: sizeBytes,
      schemaVersion: 1,
      appVersion: '1.0.0',
      checksumSha256: checksum,
      isAutomatic: isAutomatic,
      totalAccounts: (dataCopy['accounts'] as List?)?.length ?? 0,
      totalTransactions: (dataCopy['transactions'] as List?)?.length ?? 0,
    );

    final payload = BackupPayload(
      metadata: metadata,
      data: dataCopy,
    );

    backups[id] = payload;
    return payload;
  }

  @override
  Future<bool> restoreFromPayload(BackupPayload payload) async {
    // 1. التحقق من سلامة البصمة (SHA-256 Checksum Verification)
    final payloadJson = json.encode(payload.data);
    final isValidChecksum = DataIntegrityVerifier.verifyChecksum(
      data: payloadJson,
      expectedChecksum: payload.metadata.checksumSha256,
    );

    if (!isValidChecksum) {
      throw ArgumentError('فشل فحص السلامة: ملف النسخة الاحتياطية تالف أو تم التلاعب به (Checksum Mismatch).');
    }

    // 2. التحقق من توافق إصدار المخطط (Schema Version)
    if (payload.metadata.schemaVersion > 1) {
      throw ArgumentError('إصدار النسخة الاحتياطية (${payload.metadata.schemaVersion}) أحدث من الإصدار الحالي للتطبيق.');
    }

    // 3. استعادة البيانات
    simulatedAppData = Map<String, dynamic>.from(payload.data);
    return true;
  }
}

