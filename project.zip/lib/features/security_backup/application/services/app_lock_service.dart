import 'dart:math';
import 'data_integrity_verifier.dart';

/// خدمة التحقق من رمز PIN وإدارة قفل التطبيق
class AppLockService {
  /// توليد ملح أمني عشوائي (Cryptographic Salt)
  static String generateSalt([int length = 16]) {
    final rand = Random.secure();
    final values = List<int>.generate(length, (i) => rand.nextInt(256));
    return values.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  }

  /// تجزئة رمز PIN بالملح الأمني بتقنية SHA-256
  static String hashPin(String pin, String salt) {
    return DataIntegrityVerifier.calculateSha256('$salt:$pin:$salt');
  }

  /// التحقق من صحة رمز PIN المدخل
  static bool verifyPin({
    required String inputPin,
    required String salt,
    required String expectedHash,
  }) {
    final computed = hashPin(inputPin, salt);
    return computed == expectedHash;
  }
}

