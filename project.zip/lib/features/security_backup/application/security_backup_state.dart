import '../domain/entities/app_lock_config.dart';
import '../domain/entities/backup_metadata.dart';
import '../domain/entities/backup_payload.dart';

/// حالة واجهة الأمان وقفل التطبيق والنسخ الاحتياطي
class SecurityBackupState {
  final bool isLoading;
  final AppLockConfig lockConfig;
  final bool isAppLocked;
  final List<BackupMetadata> backups;
  final BackupPayload? selectedBackupPayload;
  final String? errorMessage;
  final String? successMessage;

  const SecurityBackupState({
    this.isLoading = false,
    this.lockConfig = const AppLockConfig(),
    this.isAppLocked = false,
    this.backups = const [],
    this.selectedBackupPayload,
    this.errorMessage,
    this.successMessage,
  });

  SecurityBackupState copyWith({
    bool? isLoading,
    AppLockConfig? lockConfig,
    bool? isAppLocked,
    List<BackupMetadata>? backups,
    BackupPayload? selectedBackupPayload,
    String? errorMessage,
    bool clearError = false,
    String? successMessage,
    bool clearSuccess = false,
  }) {
    return SecurityBackupState(
      isLoading: isLoading ?? this.isLoading,
      lockConfig: lockConfig ?? this.lockConfig,
      isAppLocked: isAppLocked ?? this.isAppLocked,
      backups: backups ?? this.backups,
      selectedBackupPayload:
          selectedBackupPayload ?? this.selectedBackupPayload,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      successMessage: clearSuccess ? null : (successMessage ?? this.successMessage),
    );
  }
}

