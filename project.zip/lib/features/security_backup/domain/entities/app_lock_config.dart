/// إعدادات قفل التطبيق والحماية (App Lock Configuration)
class AppLockConfig {
  final bool isLockEnabled;
  final String? pinHash; // تشفير تجزئة الـ PIN بتقنية SHA-256 + Salt
  final String? salt;
  final bool useBiometrics;
  final int autoLockTimeoutSeconds; // 0 = فوراً، 60 = دقيقة، 300 = 5 دقائق، 900 = 15 دقيقة، -1 = أبداً
  final DateTime? lastActiveTimestamp;
  final int failedAttempts;
  final DateTime? lockedUntil; // حظر مؤقت بعد تكرار المحاولات الخاطئة

  const AppLockConfig({
    this.isLockEnabled = false,
    this.pinHash,
    this.salt,
    this.useBiometrics = false,
    this.autoLockTimeoutSeconds = 0,
    this.lastActiveTimestamp,
    this.failedAttempts = 0,
    this.lockedUntil,
  });

  /// فحص ما إذا كان التطبيق محظوراً مؤقتاً بسبب تكرار الأخطاء
  bool get isTemporarilyLocked {
    if (lockedUntil == null) return false;
    return DateTime.now().isBefore(lockedUntil!);
  }

  /// فحص ما إذا كان القفل مستحقاً بناءً على مهلة عدم النشاط
  bool shouldLockNow(DateTime now) {
    if (!isLockEnabled || pinHash == null) return false;
    if (autoLockTimeoutSeconds < 0) return false; // أبداً
    if (autoLockTimeoutSeconds == 0) return true; // فوراً
    if (lastActiveTimestamp == null) return true;

    final elapsed = now.difference(lastActiveTimestamp!).inSeconds;
    return elapsed >= autoLockTimeoutSeconds;
  }

  AppLockConfig copyWith({
    bool? isLockEnabled,
    String? pinHash,
    String? salt,
    bool? useBiometrics,
    int? autoLockTimeoutSeconds,
    DateTime? lastActiveTimestamp,
    int? failedAttempts,
    DateTime? lockedUntil,
    bool clearPin = false,
  }) {
    return AppLockConfig(
      isLockEnabled: isLockEnabled ?? this.isLockEnabled,
      pinHash: clearPin ? null : (pinHash ?? this.pinHash),
      salt: clearPin ? null : (salt ?? this.salt),
      useBiometrics: useBiometrics ?? this.useBiometrics,
      autoLockTimeoutSeconds:
          autoLockTimeoutSeconds ?? this.autoLockTimeoutSeconds,
      lastActiveTimestamp: lastActiveTimestamp ?? this.lastActiveTimestamp,
      failedAttempts: failedAttempts ?? this.failedAttempts,
      lockedUntil: lockedUntil ?? this.lockedUntil,
    );
  }
}

