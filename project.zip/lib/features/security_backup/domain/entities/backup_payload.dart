import 'dart:convert';
import 'backup_metadata.dart';

/// حمولة ملف النسخة الاحتياطية المتكاملة
class BackupPayload {
  final BackupMetadata metadata;
  final Map<String, dynamic> data;

  const BackupPayload({
    required this.metadata,
    required this.data,
  });

  /// تحويل النسخة إلى نص JSON مهيكل للتخزين أو التصدير
  String toJsonString() {
    final map = {
      'header': {
        'id': metadata.id,
        'filename': metadata.filename,
        'createdAt': metadata.createdAt.toIso8601String(),
        'sizeInBytes': metadata.sizeInBytes,
        'schemaVersion': metadata.schemaVersion,
        'appVersion': metadata.appVersion,
        'checksumSha256': metadata.checksumSha256,
        'isAutomatic': metadata.isAutomatic,
        'totalAccounts': metadata.totalAccounts,
        'totalTransactions': metadata.totalTransactions,
      },
      'payload': data,
    };
    return const JsonEncoder.withIndent('  ').convert(map);
  }

  /// قراءة حمولة نسخة احتياطية من نص JSON
  factory BackupPayload.fromJsonString(String jsonStr) {
    final map = json.decode(jsonStr) as Map<String, dynamic>;
    final header = map['header'] as Map<String, dynamic>;
    final payload = map['payload'] as Map<String, dynamic>;

    final metadata = BackupMetadata(
      id: header['id'] as String,
      filename: header['filename'] as String,
      createdAt: DateTime.parse(header['createdAt'] as String),
      sizeInBytes: (header['sizeInBytes'] as num).toInt(),
      schemaVersion: (header['schemaVersion'] as num).toInt(),
      appVersion: header['appVersion'] as String? ?? '1.0.0',
      checksumSha256: header['checksumSha256'] as String,
      isAutomatic: header['isAutomatic'] as bool? ?? false,
      totalAccounts: (header['totalAccounts'] as num?)?.toInt() ?? 0,
      totalTransactions: (header['totalTransactions'] as num?)?.toInt() ?? 0,
    );

    return BackupPayload(
      metadata: metadata,
      data: payload,
    );
  }
}

