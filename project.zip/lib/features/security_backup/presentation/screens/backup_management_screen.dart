import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/backup_metadata.dart';
import 'package:my_finance/features/security_backup/application/security_backup_controller.dart';
import '../widgets/backup_card.dart';
import '../widgets/restore_confirmation_dialog.dart';

/// شاشة إدارة النسخ الاحتياطية وسجل الحفظ والاستعادة
class BackupManagementScreen extends ConsumerWidget {
  const BackupManagementScreen({super.key});

  void _showRestoreDialog(BuildContext context, WidgetRef ref, BackupMetadata metadata) {
    final controller = ref.read(securityBackupControllerProvider.notifier);

    showDialog(
      context: context,
      builder: (_) => RestoreConfirmationDialog(
        metadata: metadata,
        onConfirm: () async {
          final success = await controller.restoreBackup(metadata.id);
          if (context.mounted && success) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('تمت استعادة البيانات بنجاح والتحقق من سلامة الأرصدة 🎯'),
                backgroundColor: AppColors.forestGreen,
              ),
            );
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(securityBackupControllerProvider);
    final controller = ref.read(securityBackupControllerProvider.notifier);
    final backups = state.backups;

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('إدارة النسخ الاحتياطية'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final p = await controller.createManualBackup();
          if (p != null && context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('تم حفظ النسخة بنجاح (${p.metadata.formattedSize})'),
                backgroundColor: AppColors.forestGreen,
              ),
            );
          }
        },
        backgroundColor: AppColors.forestGreen,
        icon: const Icon(Icons.add, color: Colors.white),
        label: Text(
          'نسخة جديدة',
          style: AppTypography.bodyPrimary.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadAll(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Info Banner
              LuxuryCard(
                backgroundColor: AppColors.surfaceLight,
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.champagneGold.withValues(alpha: 0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.verified_user_outlined,
                        color: AppColors.champagneGold,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'حماية وتوقيع رقمي SHA-256',
                            style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'يتم فحص بصمة التجزئة قبل أي عملية استعادة لضمان عدم تلف الملف أو التلاعب به.',
                            style: AppTypography.bodySecondary.copyWith(fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              if (backups.isEmpty)
                LuxuryCard(
                  padding: const EdgeInsets.all(32),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(
                          Icons.backup_outlined,
                          size: 40,
                          color: AppColors.slateMuted.withValues(alpha: 0.5),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'لا توجد نسخ احتياطية مسجلة حتى الآن',
                          style: AppTypography.bodySecondary,
                        ),
                      ],
                    ),
                  ),
                )
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: backups.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final item = backups[index];
                    return BackupCard(
                      metadata: item,
                      onRestore: () => _showRestoreDialog(context, ref, item),
                      onDelete: () => controller.deleteBackup(item.id),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

