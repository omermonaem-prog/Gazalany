import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import 'package:my_finance/features/security_backup/application/security_backup_controller.dart';

/// شاشة إدخال رمز PIN لفتح قفل التطبيق (App Lock Screen)
class AppLockScreen extends ConsumerStatefulWidget {
  final VoidCallback? onUnlocked;

  const AppLockScreen({super.key, this.onUnlocked});

  @override
  ConsumerState<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends ConsumerState<AppLockScreen> {
  String _enteredPin = '';

  void _onKeyPress(String digit) {
    if (_enteredPin.length < 6) {
      setState(() => _enteredPin += digit);
      if (_enteredPin.length >= 4) {
        // فحص الرمز
        final controller = ref.read(securityBackupControllerProvider.notifier);
        final success = controller.unlockWithPin(_enteredPin);
        if (success) {
          widget.onUnlocked?.call();
        } else {
          // مسح الرمز عند الخطأ
          Future.delayed(const Duration(milliseconds: 300), () {
            if (mounted) setState(() => _enteredPin = '');
          });
        }
      }
    }
  }

  void _onBackspace() {
    if (_enteredPin.isNotEmpty) {
      setState(() => _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1));
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(securityBackupControllerProvider);

    return Scaffold(
      backgroundColor: AppColors.forestGreen,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Header
              Column(
                children: [
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.lock_rounded,
                      color: AppColors.champagneGold,
                      size: 40,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'جزلاني — MyFinance',
                    style: AppTypography.headingH2.copyWith(color: Colors.white),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'أدخل رمز PIN لفتح التطبيق بأمان',
                    style: AppTypography.bodySecondary.copyWith(color: Colors.white70),
                  ),
                  const SizedBox(height: 24),

                  // PIN Dots
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(4, (i) {
                      final isFilled = i < _enteredPin.length;
                      return Container(
                        margin: const EdgeInsets.symmetric(horizontal: 8),
                        width: 16,
                        height: 16,
                        decoration: BoxDecoration(
                          color: isFilled ? AppColors.champagneGold : Colors.white24,
                          shape: BoxShape.circle,
                        ),
                      );
                    }),
                  ),

                  if (state.errorMessage != null) ...[
                    const SizedBox(height: 16),
                    Text(
                      state.errorMessage!,
                      style: AppTypography.bodySecondary.copyWith(
                        color: const Color(0xFFFF8E8E),
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ],
              ),

              // Numeric Keypad
              Column(
                children: [
                  for (var row = 0; row < 3; row++)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          for (var col = 1; col <= 3; col++)
                            _buildKeyButton('${row * 3 + col}'),
                        ],
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // Clear button
                        IconButton(
                          icon: const Icon(Icons.clear, color: Colors.white70),
                          onPressed: () => setState(() => _enteredPin = ''),
                        ),
                        _buildKeyButton('0'),
                        // Backspace button
                        IconButton(
                          icon: const Icon(Icons.backspace_outlined, color: Colors.white70),
                          onPressed: _onBackspace,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildKeyButton(String label) {
    return InkWell(
      onTap: () => _onKeyPress(label),
      borderRadius: BorderRadius.circular(40),
      child: Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.1),
          shape: BoxShape.circle,
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: AppTypography.headingH2.copyWith(
            color: Colors.white,
            fontSize: 26,
          ),
        ),
      ),
    );
  }
}

