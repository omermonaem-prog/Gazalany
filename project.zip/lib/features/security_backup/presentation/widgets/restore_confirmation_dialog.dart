import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/backup_metadata.dart';

/// حوار تأكيد وتحذير استعادة النسخة الاحتياطية
class RestoreConfirmationDialog extends StatefulWidget {
  final BackupMetadata metadata;
  final VoidCallback onConfirm;

  const RestoreConfirmationDialog({
    super.key,
    required this.metadata,
    required this.onConfirm,
  });

  @override
  State<RestoreConfirmationDialog> createState() =>
      _RestoreConfirmationDialogState();
}

class _RestoreConfirmationDialogState extends State<RestoreConfirmationDialog> {
  bool _isConfirmed = false;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.criticalRed.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.warning_amber_rounded,
              color: AppColors.criticalRed,
              size: 26,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            'تحذير استبدال البيانات',
            style: AppTypography.headingH3.copyWith(color: AppColors.criticalRed),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'استعادة هذه النسخة ستؤدي إلى استبدال كافة البيانات والعمليات المالية الحالية بالبيانات المحفوظة في ملف النسخة.',
              style: AppTypography.bodyPrimary,
            ),
            const SizedBox(height: 14),

            // Metadata Preview Card
            LuxuryCard(
              backgroundColor: AppColors.surfaceSubtleLight,
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('الملف: ${widget.metadata.filename}', style: AppTypography.bodySecondary.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text('تاريخ النسخة: ${widget.metadata.createdAt.year}/${widget.metadata.createdAt.month}/${widget.metadata.createdAt.day}', style: AppTypography.bodySecondary),
                  Text('الحجم: ${widget.metadata.formattedSize}', style: AppTypography.bodySecondary),
                  Text('الحسابات: ${widget.metadata.totalAccounts} | العمليات: ${widget.metadata.totalTransactions}', style: AppTypography.bodySecondary),
                  const SizedBox(height: 6),
                  Text(
                    'بصمة SHA-256: ${widget.metadata.checksumSha256.substring(0, 16)}...',
                    style: AppTypography.bodySecondary.copyWith(
                      fontSize: 10,
                      color: AppColors.slateMuted,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            CheckboxListTile(
              value: _isConfirmed,
              onChanged: (val) => setState(() => _isConfirmed = val ?? false),
              title: Text(
                'أعلم بأن البيانات الحالية سيتم استبدالها وأؤكد المتابعة',
                style: AppTypography.bodySecondary.copyWith(
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
              controlAffinity: ListTileControlAffinity.leading,
              contentPadding: EdgeInsets.zero,
              activeColor: AppColors.criticalRed,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.criticalRed,
            foregroundColor: Colors.white,
          ),
          onPressed: _isConfirmed
              ? () {
                  Navigator.pop(context);
                  widget.onConfirm();
                }
              : null,
          child: const Text('تأكيد الاستعادة الآن'),
        ),
      ],
    );
  }
}

