import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../domain/entities/backup_metadata.dart';

/// بطاقة عرض تفاصيل النسخة الاحتياطية
class BackupCard extends StatelessWidget {
  final BackupMetadata metadata;
  final VoidCallback onRestore;
  final VoidCallback onDelete;

  const BackupCard({
    super.key,
    required this.metadata,
    required this.onRestore,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final d = metadata.createdAt;
    final dateStr = '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')} - ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

    return LuxuryCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.forestGreen.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.save_as_rounded,
                  color: AppColors.forestGreen,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      metadata.filename,
                      style: AppTypography.headingH3.copyWith(fontSize: 14),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      dateStr,
                      style: AppTypography.bodySecondary.copyWith(fontSize: 11),
                    ),
                  ],
                ),
              ),
              StatusBadge(
                text: metadata.isAutomatic ? 'تلقائية' : 'يدوية',
                color: AppColors.surfaceSubtleLight,
                textColor: AppColors.forestGreen,
              ),
            ],
          ),
          const SizedBox(height: 12),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('الحجم: ${metadata.formattedSize}', style: AppTypography.bodySecondary),
              Text(
                '${metadata.totalAccounts} حسابات | ${metadata.totalTransactions} عمليات',
                style: AppTypography.bodySecondary,
              ),
            ],
          ),
          const SizedBox(height: 14),

          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onRestore,
                  icon: const Icon(Icons.settings_backup_restore_rounded, size: 18),
                  label: const Text('استعادة هذه النسخة'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.forestGreen,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: AppColors.slateMuted),
                tooltip: 'حذف النسخة',
                onPressed: onDelete,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

