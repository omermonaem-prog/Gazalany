/// كيان تصنيف المصروفات أو الإيرادات
class CategoryEntity {
  final String id;
  final String? parentId;
  final String name;
  final String iconName;
  final String colorHex;
  final bool isIncome;
  final DateTime createdAt;

  const CategoryEntity({
    required this.id,
    this.parentId,
    required this.name,
    required this.iconName,
    required this.colorHex,
    this.isIncome = false,
    required this.createdAt,
  });

  CategoryEntity copyWith({
    String? id,
    String? parentId,
    String? name,
    String? iconName,
    String? colorHex,
    bool? isIncome,
    DateTime? createdAt,
  }) {
    return CategoryEntity(
      id: id ?? this.id,
      parentId: parentId ?? this.parentId,
      name: name ?? this.name,
      iconName: iconName ?? this.iconName,
      colorHex: colorHex ?? this.colorHex,
      isIncome: isIncome ?? this.isIncome,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is CategoryEntity && other.id == id && other.name == name;
  }

  @override
  int get hashCode => id.hashCode ^ name.hashCode;
}

