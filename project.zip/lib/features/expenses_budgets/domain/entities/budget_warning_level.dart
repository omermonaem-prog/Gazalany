import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';

/// مستويات التنبيه المالي لاستهلاك الميزانية (وفق النظام 05)
enum BudgetWarningLevel {
  /// استهلاك آمن (< 70%)
  safe,

  /// تنبيه وقائي (70% - 89%)
  cautionary,

  /// تحذير حرج (90% - 99%)
  warning,

  /// تجاوز كامل للميزانية (100% فما فوق)
  exceeded;

  static BudgetWarningLevel fromPercentage(double percentage) {
    if (percentage >= 100.0) {
      return BudgetWarningLevel.exceeded;
    } else if (percentage >= 90.0) {
      return BudgetWarningLevel.warning;
    } else if (percentage >= 70.0) {
      return BudgetWarningLevel.cautionary;
    }
    return BudgetWarningLevel.safe;
  }

  String get labelArabic {
    switch (this) {
      case BudgetWarningLevel.safe:
        return 'استهلاك آمن';
      case BudgetWarningLevel.cautionary:
        return 'تنبيه وقائي (70%+)';
      case BudgetWarningLevel.warning:
        return 'تحذير حرج (90%+)';
      case BudgetWarningLevel.exceeded:
        return 'تجاوز الحد (100%+)';
    }
  }

  Color get color {
    switch (this) {
      case BudgetWarningLevel.safe:
        return AppColors.cashIn;
      case BudgetWarningLevel.cautionary:
        return AppColors.warningAmber;
      case BudgetWarningLevel.warning:
        return const Color(0xFFE65100); // برتقالي داكن
      case BudgetWarningLevel.exceeded:
        return AppColors.criticalRed;
    }
  }
}

