import '../../../../core/finance/money.dart';
import 'package:my_finance/features/financial_engine/domain/entities/transaction_entity.dart';

/// قيد مصروف مالي (Expense Entry Domain Entity)
class ExpenseEntry {
  final String id;
  final String accountId;
  final String? accountName;
  final String categoryId;
  final String? categoryName;
  final String? categoryIcon;
  final String? categoryColorHex;
  final Money amount;
  final DateTime date;
  final String description;
  final String? notes;
  final String? receiptImagePath;
  final TransactionStatus status;
  final String idempotencyKey;
  final DateTime createdAt;

  const ExpenseEntry({
    required this.id,
    required this.accountId,
    this.accountName,
    required this.categoryId,
    this.categoryName,
    this.categoryIcon,
    this.categoryColorHex,
    required this.amount,
    required this.date,
    required this.description,
    this.notes,
    this.receiptImagePath,
    this.status = TransactionStatus.completed,
    required this.idempotencyKey,
    required this.createdAt,
  });

  ExpenseEntry copyWith({
    String? id,
    String? accountId,
    String? accountName,
    String? categoryId,
    String? categoryName,
    String? categoryIcon,
    String? categoryColorHex,
    Money? amount,
    DateTime? date,
    String? description,
    String? notes,
    String? receiptImagePath,
    TransactionStatus? status,
    String? idempotencyKey,
    DateTime? createdAt,
  }) {
    return ExpenseEntry(
      id: id ?? this.id,
      accountId: accountId ?? this.accountId,
      accountName: accountName ?? this.accountName,
      categoryId: categoryId ?? this.categoryId,
      categoryName: categoryName ?? this.categoryName,
      categoryIcon: categoryIcon ?? this.categoryIcon,
      categoryColorHex: categoryColorHex ?? this.categoryColorHex,
      amount: amount ?? this.amount,
      date: date ?? this.date,
      description: description ?? this.description,
      notes: notes ?? this.notes,
      receiptImagePath: receiptImagePath ?? this.receiptImagePath,
      status: status ?? this.status,
      idempotencyKey: idempotencyKey ?? this.idempotencyKey,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is ExpenseEntry &&
        other.id == id &&
        other.accountId == accountId &&
        other.categoryId == categoryId &&
        other.amount == amount &&
        other.idempotencyKey == idempotencyKey;
  }

  @override
  int get hashCode =>
      id.hashCode ^
      accountId.hashCode ^
      categoryId.hashCode ^
      amount.hashCode ^
      idempotencyKey.hashCode;
}

