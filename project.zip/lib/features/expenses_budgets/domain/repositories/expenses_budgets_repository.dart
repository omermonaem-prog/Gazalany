import '../../../../core/finance/money.dart';
import 'package:my_finance/features/financial_engine/domain/entities/transaction_entity.dart';
import '../entities/budget_entity.dart';
import '../entities/category_entity.dart';
import '../entities/expense_entry.dart';
import '../entities/transaction_filter.dart';

/// العقد المجرد لمستودع المصروفات والميزانيات والتصنيفات
abstract class ExpensesBudgetsRepository {
  // ── التصنيفات ────────────────────────────────────────────────
  Future<List<CategoryEntity>> getExpenseCategories();
  Future<CategoryEntity?> getCategoryById(String id);
  Future<void> saveCategory(CategoryEntity category);

  // ── الميزانيات الشهرية ─────────────────────────────────────────
  Future<List<BudgetEntity>> getBudgetsByMonth(String periodYearMonth);
  Future<BudgetEntity?> getBudgetByCategoryAndMonth(String categoryId, String periodYearMonth);
  Future<void> saveBudget(BudgetEntity budget);
  Future<void> applyExpenseToBudget({
    required String categoryId,
    required String periodYearMonth,
    required Money amountDelta,
  });
  /// مجموع المبالغ المتبقية في ميزانيات الإنفاق الحالية (السيولة المتاحة)
  Future<Money> getTotalRemainingBudgetLiquidity(String periodYearMonth);

  // ── المصروفات وسجل المعاملات ───────────────────────────────────
  Future<void> saveExpense(ExpenseEntry expense);
  Future<ExpenseEntry?> getExpenseById(String id);
  Future<List<ExpenseEntry>> getFilteredExpenses(TransactionFilter filter);
  Future<void> updateExpenseStatus(String id, TransactionStatus status);
}

