import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_finance/core/database/providers/database_providers.dart';
import 'package:my_finance/core/finance/financial_exceptions.dart';
import 'package:my_finance/core/finance/money.dart';
import '../../financial_engine/application/central_financial_engine.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import '../../financial_engine/presentation/providers/financial_engine_providers.dart';
import '../data/repositories/expenses_budgets_repository_impl.dart';
import '../domain/entities/budget_entity.dart';
import '../domain/entities/budget_warning_level.dart';
import '../domain/entities/category_entity.dart';
import '../domain/entities/expense_entry.dart';
import '../domain/entities/transaction_filter.dart';
import '../domain/repositories/expenses_budgets_repository.dart';
import 'expenses_budgets_state.dart';

/// موفر مستودع المصروفات والميزانيات
final expensesBudgetsRepositoryProvider =
    Provider<ExpensesBudgetsRepository>((ref) {
  final db = ref.watch(databaseProvider);
  return ExpensesBudgetsRepositoryImpl(db);
});

/// موفر متحكم المصروفات والميزانيات
final expensesBudgetsControllerProvider = StateNotifierProvider<
    ExpensesBudgetsController, ExpensesBudgetsState>((ref) {
  final engine = ref.watch(centralFinancialEngineProvider);
  final repo = ref.watch(expensesBudgetsRepositoryProvider);
  return ExpensesBudgetsController(engine: engine, repository: repo);
});

/// المتحكم المسؤول عن المصروفات والميزانيات والتصنيفات وسجل المعاملات
class ExpensesBudgetsController extends StateNotifier<ExpensesBudgetsState> {
  final CentralFinancialEngine _engine;
  final ExpensesBudgetsRepository _repository;

  ExpensesBudgetsController({
    required CentralFinancialEngine engine,
    required ExpensesBudgetsRepository repository,
  })  : _engine = engine,
        _repository = repository,
        super(const ExpensesBudgetsState()) {
    loadData();
  }

  static String _toYearMonth(DateTime dt) =>
      '${dt.year}-${dt.month.toString().padLeft(2, '0')}';

  /// تحميل كافة التصنيفات والميزانيات والمصروفات للشهر المحدد
  Future<void> loadData([String? yearMonth]) async {
    final ym = yearMonth ?? state.selectedYearMonth;
    state = state.copyWith(isLoading: true, clearError: true);

    try {
      final categories = await _repository.getExpenseCategories();
      final budgets = await _repository.getBudgetsByMonth(ym);
      final expenses = await _repository.getFilteredExpenses(state.filter);
      final liquidity = await _repository.getTotalRemainingBudgetLiquidity(ym);

      final totalAllocated = budgets.fold<Money>(
        const Money.zero(),
        (sum, b) => sum + b.allocatedAmount,
      );
      final totalSpent = budgets.fold<Money>(
        const Money.zero(),
        (sum, b) => sum + b.spentAmount,
      );

      state = state.copyWith(
        isLoading: false,
        selectedYearMonth: ym,
        categories: categories,
        budgets: budgets,
        expenses: expenses,
        totalAllocatedBudget: totalAllocated,
        totalSpentBudget: totalSpent,
        availableBudgetLiquidity: liquidity,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'تعذر تحميل بيانات المصروفات والميزانيات: $e',
      );
    }
  }

  /// ── المرحلة 1: إضافة وحفظ المصروف المالي مع التحقق الصارم ──
  ///
  /// القواعد:
  /// 1. يخصم من الميزانية المحددة فقط.
  /// 2. تحديث المتبقي والسيولة المتاحة فورياً.
  /// 3. إطلاق تنبيه عند تجاوز الحد أو الاقتراب منه (70%، 90%، 100%+).
  /// 4. الاستدعاء الذري للمحرك المالي لمنع التكرار واحتساب الأثر.
  Future<bool> recordExpense({
    required String accountId,
    required String categoryId,
    required Money amount,
    required DateTime date,
    required String description,
    String? notes,
    String? receiptImagePath,
    required String idempotencyKey,
    bool allowExceeding = false,
  }) async {
    if (!amount.isPositive) {
      state = state.copyWith(errorMessage: 'مبلغ المصروف يجب أن يكون موجباً');
      return false;
    }

    final ym = _toYearMonth(date);
    final category = await _repository.getCategoryById(categoryId);
    if (category == null) {
      state = state.copyWith(errorMessage: 'تصنيف المصروف غير موجود');
      return false;
    }

    // فحص الميزانية المخصصة لهذا التصنيف
    final budget = await _repository.getBudgetByCategoryAndMonth(categoryId, ym);
    if (budget != null) {
      final projectedSpent = budget.spentAmount + amount;
      if (projectedSpent > budget.allocatedAmount && !allowExceeding) {
        state = state.copyWith(
          errorMessage:
              'الميزانية غير كافية: المتبقي (${budget.remainingAmount.formatArabic()}) أقل من المبلغ المطلوب (${amount.formatArabic()})',
        );
        return false;
      }
    }

    state = state.copyWith(isLoading: true, clearError: true);

    try {
      final expenseId = 'exp_${DateTime.now().millisecondsSinceEpoch}';

      // 1. الخصم الذري من الحساب عبر المحرك المالي المركزي
      await _engine.recordExpense(
        transactionId: expenseId,
        accountId: accountId,
        categoryId: categoryId,
        amount: amount,
        date: date,
        note: '$description (${category.name})',
        receiptImagePath: receiptImagePath,
        idempotencyKey: idempotencyKey,
      );

      // 2. خصم المصروف من الميزانية المحددة فقط
      await _repository.applyExpenseToBudget(
        categoryId: categoryId,
        periodYearMonth: ym,
        amountDelta: amount,
      );

      // 3. حفظ قيد المصروف في السجل
      final expenseEntry = ExpenseEntry(
        id: expenseId,
        accountId: accountId,
        categoryId: categoryId,
        categoryName: category.name,
        categoryIcon: category.iconName,
        categoryColorHex: category.colorHex,
        amount: amount,
        date: date,
        description: description,
        notes: notes,
        receiptImagePath: receiptImagePath,
        status: TransactionStatus.completed,
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      await _repository.saveExpense(expenseEntry);

      // 4. إعادة تحميل البيانات وحساب السيولة المتاحة المتبقية
      await loadData(ym);

      // فحص إطلاق التنبيهات
      String? warningMsg;
      final updatedBudget =
          await _repository.getBudgetByCategoryAndMonth(categoryId, ym);
      if (updatedBudget != null) {
        switch (updatedBudget.warningLevel) {
          case BudgetWarningLevel.exceeded:
            warningMsg =
                'إنذار حرج: تم تجاوز ميزانية (${category.name}) بنسبة ${updatedBudget.usagePercentage.toStringAsFixed(1)}%!';
            break;
          case BudgetWarningLevel.warning:
            warningMsg =
                'تحذير: بلغت ميزانية (${category.name}) نسبة ${updatedBudget.usagePercentage.toStringAsFixed(1)}% (المتبقي: ${updatedBudget.remainingAmount.formatArabic()})';
            break;
          case BudgetWarningLevel.cautionary:
            warningMsg =
                'تنبيه وقائي: استهلكت 70%+ من ميزانية (${category.name})';
            break;
          case BudgetWarningLevel.safe:
            break;
        }
      }

      state = state.copyWith(
        isLoading: false,
        successMessage:
            warningMsg ?? 'تم تسجيل المصروف وخصمه من ميزانية ${category.name}',
      );

      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تسجيل المصروف: $e',
      );
      return false;
    }
  }

  /// ── المرحلة 2: إنشاء أو تعديل ميزانية إنفاق لتصنيف محدد ──
  Future<bool> createOrUpdateBudget({
    required String categoryId,
    required Money allocatedAmount,
    String? periodYearMonth,
    int warningThresholdPercent = 80,
  }) async {
    final ym = periodYearMonth ?? state.selectedYearMonth;
    final category = await _repository.getCategoryById(categoryId);
    if (category == null) {
      state = state.copyWith(errorMessage: 'التصنيف غير موجود');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final existing =
          await _repository.getBudgetByCategoryAndMonth(categoryId, ym);
      final budget = BudgetEntity(
        id: existing?.id ?? 'bud_${categoryId}_$ym',
        categoryId: categoryId,
        categoryName: category.name,
        categoryIcon: category.iconName,
        categoryColorHex: category.colorHex,
        periodYearMonth: ym,
        allocatedAmount: allocatedAmount,
        spentAmount: existing?.spentAmount ?? const Money.zero(),
        warningThresholdPercent: warningThresholdPercent,
        createdAt: existing?.createdAt ?? DateTime.now(),
      );

      await _repository.saveBudget(budget);
      await loadData(ym);

      state = state.copyWith(
        isLoading: false,
        successMessage: 'تم ضبط ميزانية ${category.name} بمبلغ ${allocatedAmount.formatArabic()}',
      );
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل حفظ الميزانية: $e',
      );
      return false;
    }
  }

  /// ── المرحلة 3: تصفية والبحث في سجل المعاملات ──
  void applyFilter(TransactionFilter filter) {
    state = state.copyWith(filter: filter);
    loadData();
  }

  void resetFilter() {
    state = state.copyWith(filter: const TransactionFilter());
    loadData();
  }

  /// ── المرحلة 4: تصحيح أو عكس مصروف مالي وفق سياسة التصحيح ──
  Future<bool> correctExpense({
    required String originalExpenseId,
    required Money newAmount,
    required String newCategoryId,
    required String newDescription,
    required String reason,
    required String idempotencyKey,
  }) async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final original = await _repository.getExpenseById(originalExpenseId);
      if (original == null) {
        throw ArgumentError('المصروف الأصلي غير موجود');
      }

      final ym = _toYearMonth(original.date);
      final newCategory = await _repository.getCategoryById(newCategoryId);
      if (newCategory == null) throw ArgumentError('التصنيف الجديد غير موجود');

      final correctedTxnId = 'exp_corr_${DateTime.now().millisecondsSinceEpoch}';
      final correctedTxn = TransactionEntity(
        id: correctedTxnId,
        accountId: original.accountId,
        categoryId: newCategoryId,
        type: TransactionType.expense,
        amount: newAmount,
        transactionDate: original.date,
        note: '$newDescription ($reason)',
        createdAt: DateTime.now(),
      );

      // 1. استدعاء المحرك المالي لعكس المصروف القديم وإثبات المصحح ذرياً
      await _engine.correctTransaction(
        originalTransactionId: originalExpenseId,
        reversalTransactionId: 'rev_$originalExpenseId',
        correctedTransaction: correctedTxn,
        reason: reason,
        idempotencyKey: idempotencyKey,
      );

      // 2. تسوية ميزانية التصنيف القديم (استرداد المبلغ القديم)
      await _repository.applyExpenseToBudget(
        categoryId: original.categoryId,
        periodYearMonth: ym,
        amountDelta: -original.amount,
      );

      // 3. خصم المبلغ المصحح من ميزانية التصنيف الجديد
      await _repository.applyExpenseToBudget(
        categoryId: newCategoryId,
        periodYearMonth: ym,
        amountDelta: newAmount,
      );

      // 4. تحديث حالة المصروف القديم
      await _repository.updateExpenseStatus(
        originalExpenseId,
        TransactionStatus.reversed,
      );

      // 5. حفظ قيد المصروف المصحح
      final correctedEntry = ExpenseEntry(
        id: correctedTxnId,
        accountId: original.accountId,
        categoryId: newCategoryId,
        categoryName: newCategory.name,
        categoryIcon: newCategory.iconName,
        categoryColorHex: newCategory.colorHex,
        amount: newAmount,
        date: original.date,
        description: newDescription,
        status: TransactionStatus.corrected,
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      await _repository.saveExpense(correctedEntry);
      await loadData(ym);

      state = state.copyWith(
        isLoading: false,
        successMessage: 'تم تصحيح المصروف وتحديث أرصدة الميزانية بنجاح',
      );
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تصحيح المصروف: $e',
      );
      return false;
    }
  }

  void clearMessages() {
    state = state.copyWith(clearError: true, clearSuccess: true);
  }
}

