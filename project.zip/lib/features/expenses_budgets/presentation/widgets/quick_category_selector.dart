import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import 'package:my_finance/features/expenses_budgets/domain/entities/budget_entity.dart';
import 'package:my_finance/features/expenses_budgets/domain/entities/category_entity.dart';

/// شريط اختيار التصنيف السريع بنقرة واحدة (Quick Category Selector)
class QuickCategorySelector extends StatelessWidget {
  final List<CategoryEntity> categories;
  final List<BudgetEntity> budgets;
  final String? selectedCategoryId;
  final ValueChanged<String> onCategorySelected;

  const QuickCategorySelector({
    super.key,
    required this.categories,
    required this.budgets,
    required this.selectedCategoryId,
    required this.onCategorySelected,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 90,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (context, index) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final cat = categories[index];
          final isSelected = cat.id == selectedCategoryId;

          // البحث عن ميزانية هذا التصنيف لعرض المتبقي
          BudgetEntity? catBudget;
          try {
            catBudget = budgets.firstWhere((b) => b.categoryId == cat.id);
          } catch (_) {
            catBudget = null;
          }

          final remainingStr = catBudget != null
              ? 'متبقي: ${catBudget.remainingAmount.formatArabic()}'
              : 'بلا ميزانية';

          return GestureDetector(
            onTap: () => onCategorySelected(cat.id),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 130,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: isSelected ? AppColors.forestGreen : AppColors.surfaceLight,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isSelected ? AppColors.champagneGold : AppColors.borderSubtleLight,
                  width: isSelected ? 1.5 : 1,
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: AppColors.forestGreen.withValues(alpha: 0.15),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ]
                    : null,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.circle,
                        size: 10,
                        color: isSelected
                            ? AppColors.champagneGoldBright
                            : AppColors.forestGreen,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          cat.name,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: isSelected ? Colors.white : AppColors.textMain,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    remainingStr,
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      color: isSelected
                          ? Colors.white.withValues(alpha: 0.8)
                          : (catBudget?.isExceeded == true
                              ? AppColors.criticalRed
                              : AppColors.slateMuted),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

