import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import 'package:my_finance/features/financial_engine/domain/entities/transaction_entity.dart';
import 'package:my_finance/features/expenses_budgets/domain/entities/expense_entry.dart';

/// عنصر عرض قيد المصروف في سجل المعاملات
class ExpenseTile extends StatelessWidget {
  final ExpenseEntry expense;
  final VoidCallback? onCorrect;

  const ExpenseTile({
    super.key,
    required this.expense,
    this.onCorrect,
  });

  @override
  Widget build(BuildContext context) {
    final dateStr =
        '${expense.date.year}/${expense.date.month.toString().padLeft(2, '0')}/${expense.date.day.toString().padLeft(2, '0')}';

    return LuxuryCard(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          // أيقونة التصنيف
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.cashOut.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.shopping_bag_outlined,
              color: AppColors.cashOut,
              size: 22,
            ),
          ),
          const SizedBox(width: 14),

          // الوصف والتصنيف والتاريخ
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  expense.description,
                  style: AppTypography.headingH3.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '${expense.categoryName ?? 'تصنيف عام'} • $dateStr',
                  style: AppTypography.bodySecondary,
                ),
              ],
            ),
          ),

          // المبلغ والحالة
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '-${expense.amount.formatArabic()}',
                style: AppTypography.headingH3.copyWith(
                  color: expense.status == TransactionStatus.reversed
                      ? AppColors.slateMuted
                      : AppColors.cashOut,
                  fontWeight: FontWeight.w700,
                  decoration: expense.status == TransactionStatus.reversed
                      ? TextDecoration.lineThrough
                      : null,
                ),
              ),
              const SizedBox(height: 4),
              _buildBadge(),
            ],
          ),

          if (onCorrect != null && expense.status == TransactionStatus.completed) ...[
            IconButton(
              icon: const Icon(Icons.more_vert, size: 20, color: AppColors.slateMuted),
              onPressed: onCorrect,
              tooltip: 'تصحيح المصروف',
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildBadge() {
    switch (expense.status) {
      case TransactionStatus.completed:
        return const StatusBadge(label: 'مصروف', type: StatusBadgeType.neutral);
      case TransactionStatus.reversed:
        return const StatusBadge(label: 'معكوس', type: StatusBadgeType.danger);
      case TransactionStatus.corrected:
        return const StatusBadge(label: 'مصحّح', type: StatusBadgeType.warning);
    }
  }
}

