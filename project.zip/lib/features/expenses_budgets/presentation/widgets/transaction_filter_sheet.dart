import 'package:flutter/material.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import 'package:my_finance/features/expenses_budgets/domain/entities/category_entity.dart';
import 'package:my_finance/features/expenses_budgets/domain/entities/transaction_filter.dart';

/// صفيحة تصفية وبحث متقدم في سجل المعاملات (Transaction Filter Sheet)
class TransactionFilterSheet extends StatefulWidget {
  final TransactionFilter initialFilter;
  final List<CategoryEntity> categories;
  final ValueChanged<TransactionFilter> onApply;
  final VoidCallback onReset;

  const TransactionFilterSheet({
    super.key,
    required this.initialFilter,
    required this.categories,
    required this.onApply,
    required this.onReset,
  });

  @override
  State<TransactionFilterSheet> createState() => _TransactionFilterSheetState();
}

class _TransactionFilterSheetState extends State<TransactionFilterSheet> {
  late final TextEditingController _searchController;
  late final TextEditingController _minAmountController;
  late final TextEditingController _maxAmountController;

  String? _selectedCategoryId;
  DateTime? _startDate;
  DateTime? _endDate;

  @override
  void initState() {
    super.initState();
    _searchController =
        TextEditingController(text: widget.initialFilter.searchQuery);
    _minAmountController = TextEditingController(
        text: widget.initialFilter.minAmount?.toMajorUnits().toString());
    _maxAmountController = TextEditingController(
        text: widget.initialFilter.maxAmount?.toMajorUnits().toString());
    _selectedCategoryId = widget.initialFilter.categoryId;
    _startDate = widget.initialFilter.startDate;
    _endDate = widget.initialFilter.endDate;
  }

  @override
  void dispose() {
    _searchController.dispose();
    _minAmountController.dispose();
    _maxAmountController.dispose();
    super.dispose();
  }

  void _apply() {
    Money? minAmt;
    if (_minAmountController.text.trim().isNotEmpty) {
      try {
        minAmt = Money.parse(_minAmountController.text.trim());
      } catch (_) {}
    }

    Money? maxAmt;
    if (_maxAmountController.text.trim().isNotEmpty) {
      try {
        maxAmt = Money.parse(_maxAmountController.text.trim());
      } catch (_) {}
    }

    final newFilter = TransactionFilter(
      searchQuery: _searchController.text.trim().isEmpty
          ? null
          : _searchController.text.trim(),
      categoryId: _selectedCategoryId,
      startDate: _startDate,
      endDate: _endDate,
      minAmount: minAmt,
      maxAmount: maxAmt,
    );

    widget.onApply(newFilter);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.canvasLight,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: EdgeInsets.only(
        top: 20,
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 5,
                decoration: BoxDecoration(
                  color: AppColors.borderSubtleLight,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 16),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('تصفية وبحث المعاملات', style: AppTypography.headingH2),
                TextButton(
                  onPressed: () {
                    widget.onReset();
                    Navigator.pop(context);
                  },
                  child: const Text('إعادة ضبط'),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // البحث النصي
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'ابحث بالوصف أو الملاحظات...',
                prefixIcon: const Icon(Icons.search, color: AppColors.forestGreen),
                filled: true,
                fillColor: AppColors.surfaceLight,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: AppColors.borderSubtleLight),
                ),
              ),
            ),
            const SizedBox(height: 14),

            // اختيار التصنيف
            DropdownButtonFormField<String?>(
              value: _selectedCategoryId,
              decoration: InputDecoration(
                labelText: 'التصنيف / القسم',
                filled: true,
                fillColor: AppColors.surfaceLight,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              items: [
                const DropdownMenuItem(value: null, child: Text('كافة التصنيفات')),
                ...widget.categories.map((c) => DropdownMenuItem(
                      value: c.id,
                      child: Text(c.name),
                    )),
              ],
              onChanged: (val) => setState(() => _selectedCategoryId = val),
            ),
            const SizedBox(height: 14),

            // نطاق المبالغ (من - إلى)
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _minAmountController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                      labelText: 'الحد الأدنى (ر.س)',
                      filled: true,
                      fillColor: AppColors.surfaceLight,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _maxAmountController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                      labelText: 'الحد الأعلى (ر.س)',
                      filled: true,
                      fillColor: AppColors.surfaceLight,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            LuxuryButton(
              label: 'تطبيق التصفية',
              onPressed: _apply,
              type: LuxuryButtonType.primary,
            ),
          ],
        ),
      ),
    );
  }
}

