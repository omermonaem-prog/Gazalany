import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import 'package:my_finance/features/expenses_budgets/application/expenses_budgets_controller.dart';
import 'package:my_finance/features/expenses_budgets/domain/entities/budget_entity.dart';
import 'package:my_finance/features/expenses_budgets/presentation/widgets/quick_category_selector.dart';

/// شاشة إضافة مصروف سريع (Quick Expense Add Screen)
class AddExpenseScreen extends ConsumerStatefulWidget {
  const AddExpenseScreen({super.key});

  @override
  ConsumerState<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends ConsumerState<AddExpenseScreen> {
  final _amountController = TextEditingController();
  final _descController = TextEditingController();
  final _notesController = TextEditingController();

  DateTime _selectedDate = DateTime.now();
  String _selectedAccountId = 'acc_primary';
  final String _selectedAccountName = 'الحساب البنكي الرئيسي';
  String? _selectedCategoryId;

  @override
  void initState() {
    super.initState();
    // اختيار أول تصنيف تلقائياً
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final state = ref.read(expensesBudgetsControllerProvider);
      if (state.categories.isNotEmpty && _selectedCategoryId == null) {
        setState(() => _selectedCategoryId = state.categories.first.id);
      }
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _descController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  BudgetEntity? _getCurrentCategoryBudget() {
    if (_selectedCategoryId == null) return null;
    final state = ref.read(expensesBudgetsControllerProvider);
    try {
      return state.budgets.firstWhere((b) => b.categoryId == _selectedCategoryId);
    } catch (_) {
      return null;
    }
  }

  Future<void> _submitExpense() async {
    final text = _amountController.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى إدخال مبلغ المصروف أولاً')),
      );
      return;
    }

    if (_selectedCategoryId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى اختيار تصنيف المصروف')),
      );
      return;
    }

    try {
      final amount = Money.parse(text);
      if (!amount.isPositive) {
        throw ArgumentError('مبلغ المصروف يجب أن يكون موجباً');
      }

      final desc = _descController.text.trim().isEmpty
          ? 'مصروف'
          : _descController.text.trim();

      final key = 'exp_${DateTime.now().millisecondsSinceEpoch}';

      final success = await ref
          .read(expensesBudgetsControllerProvider.notifier)
          .recordExpense(
            accountId: _selectedAccountId,
            categoryId: _selectedCategoryId!,
            amount: amount,
            date: _selectedDate,
            description: desc,
            notes: _notesController.text.trim().isEmpty
                ? null
                : _notesController.text.trim(),
            idempotencyKey: key,
            allowExceeding: true, // يسمح بتسجيله مع إطلاق تنبيه
          );

      if (mounted && success) {
        final state = ref.read(expensesBudgetsControllerProvider);
        if (state.successMessage != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.successMessage!),
              backgroundColor: state.successMessage!.contains('إنذار') ||
                      state.successMessage!.contains('تحذير')
                  ? AppColors.warningAmber
                  : AppColors.forestGreen,
            ),
          );
        }
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ في إدخال المصروف: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(expensesBudgetsControllerProvider);
    final currentBudget = _getCurrentCategoryBudget();

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('إضافة مصروف'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 1. بطاقة إدخال المبلغ بخط أحمر مالي فاخر
            LuxuryCard(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'مبلغ المصروف (ر.س)',
                    style: AppTypography.bodySecondary.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _amountController,
                    autofocus: true,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    style: AppTypography.financialNumberLarge.copyWith(
                      color: AppColors.cashOut,
                      fontSize: 34,
                    ),
                    decoration: const InputDecoration(
                      hintText: '0.00',
                      border: InputBorder.none,
                      suffixText: 'ر.س',
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 2. اختيار التصنيف السريع (Quick Selector)
            Text('اختر التصنيف / القسم', style: AppTypography.headingH3),
            const SizedBox(height: 8),
            QuickCategorySelector(
              categories: state.categories,
              budgets: state.budgets,
              selectedCategoryId: _selectedCategoryId,
              onCategorySelected: (id) => setState(() => _selectedCategoryId = id),
            ),
            const SizedBox(height: 14),

            // 3. مؤشر أثر المعاملة اللحظي على الميزانية المتبقية
            if (currentBudget != null) _buildProjectedImpact(currentBudget),
            const SizedBox(height: 14),

            // 4. بطاقة التفاصيل (الوصف، الحساب، التاريخ، الملاحظات)
            LuxuryCard(
              child: Column(
                children: [
                  TextField(
                    controller: _descController,
                    decoration: const InputDecoration(
                      labelText: 'وصف المصروف (مثال: قهوة، تسوق)',
                      prefixIcon: Icon(Icons.edit_outlined, color: AppColors.forestGreen),
                      border: UnderlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.account_balance, color: AppColors.forestGreen),
                    title: Text('المحفظة / الحساب المخصوم منه', style: AppTypography.bodySecondary),
                    subtitle: Text(_selectedAccountName, style: AppTypography.bodyPrimary),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 14),
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.calendar_today, color: AppColors.forestGreen),
                    title: Text('تاريخ الصرف', style: AppTypography.bodySecondary),
                    subtitle: Text(
                      '${_selectedDate.year}/${_selectedDate.month}/${_selectedDate.day}',
                      style: AppTypography.bodyPrimary,
                    ),
                    trailing: const Icon(Icons.edit_calendar, size: 18),
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _selectedDate,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2030),
                      );
                      if (picked != null) {
                        setState(() => _selectedDate = picked);
                      }
                    },
                  ),
                  TextField(
                    controller: _notesController,
                    decoration: const InputDecoration(
                      labelText: 'ملاحظات إضافية (اختياري)',
                      prefixIcon: Icon(Icons.notes, color: AppColors.slateMuted),
                      border: InputBorder.none,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // زر الحفظ السريع
            LuxuryButton(
              label: 'حفظ وخصم المصروف',
              icon: Icons.check,
              isLoading: state.isLoading,
              onPressed: _submitExpense,
              type: LuxuryButtonType.primary,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProjectedImpact(BudgetEntity budget) {
    Money inputAmount = const Money.zero();
    try {
      if (_amountController.text.trim().isNotEmpty) {
        inputAmount = Money.parse(_amountController.text.trim());
      }
    } catch (_) {}

    final projectedRemaining = budget.remainingAmount - inputAmount;
    final isNegative = projectedRemaining.isNegative;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: isNegative
            ? AppColors.criticalRed.withValues(alpha: 0.08)
            : AppColors.surfaceSubtleLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isNegative ? AppColors.criticalRed : AppColors.borderSubtleLight,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(
                isNegative ? Icons.warning_amber_rounded : Icons.info_outline,
                size: 16,
                color: isNegative ? AppColors.criticalRed : AppColors.slateMuted,
              ),
              const SizedBox(width: 6),
              Text(
                'المتبقي بعد هذا المصروف:',
                style: AppTypography.bodySecondary.copyWith(
                  color: isNegative ? AppColors.criticalRed : AppColors.slateMuted,
                ),
              ),
            ],
          ),
          Text(
            projectedRemaining.formatArabic(),
            style: AppTypography.bodyPrimary.copyWith(
              fontWeight: FontWeight.w700,
              color: isNegative ? AppColors.criticalRed : AppColors.cashIn,
            ),
          ),
        ],
      ),
    );
  }
}

