import '../domain/entities/net_worth_summary.dart';

/// الحالات العامة للوحة التحكم (Dashboard State)
abstract class DashboardState {
  const DashboardState();
}

class DashboardInitial extends DashboardState {
  const DashboardInitial();
}

class DashboardLoading extends DashboardState {
  const DashboardLoading();
}

class DashboardLoaded extends DashboardState {
  final NetWorthSummary summary;
  const DashboardLoaded(this.summary);
}

class DashboardError extends DashboardState {
  final String message;
  const DashboardError(this.message);
}

