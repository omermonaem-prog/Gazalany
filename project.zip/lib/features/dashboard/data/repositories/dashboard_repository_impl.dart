import '../../domain/entities/net_worth_summary.dart';
import '../../domain/repositories/dashboard_repository.dart';

/// تطبيق مستودع لوحة التحكم الأساسي لاختبار البنية التحتية فقط
class DashboardRepositoryImpl implements DashboardRepository {
  @override
  Future<NetWorthSummary> getNetWorthSummary() async {
    // محاكاة استدعاء غير متزامن بدون منطق مالي نهائي
    await Future.delayed(const Duration(milliseconds: 150));
    return const NetWorthSummary(
      netWorth: 0.0,
      totalAssets: 0.0,
      totalDebts: 0.0,
      availableToSpend: 0.0,
      lockedObligations: 0.0,
      monthlyChangePercentage: 0.0,
    );
  }
}

