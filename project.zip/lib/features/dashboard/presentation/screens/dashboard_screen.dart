import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/router/app_routes.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/net_worth_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../application/dashboard_state.dart';
import '../controllers/dashboard_controller.dart';

/// الشاشة الرئيسية ولوحة التحكم الشاملة لتطبيق MyFinance
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(dashboardControllerProvider);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.forestGreen, AppColors.forestGreenLight],
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.champagneGold, width: 1),
              ),
              child: const Center(
                child: Text(
                  'MF',
                  style: TextStyle(
                    color: AppColors.champagneGoldBright,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppConstants.appNameArabic,
                  style: AppTypography.headingH3.copyWith(
                    fontWeight: FontWeight.w700,
                    color: AppColors.forestGreen,
                  ),
                ),
                Text(
                  'الإصدار النهائي المعتمد v1.0',
                  style: AppTypography.bodySecondary.copyWith(fontSize: 11),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.analytics_outlined, color: AppColors.forestGreen),
            tooltip: 'التحليلات والتقارير',
            onPressed: () => context.push(AppRoutes.analytics),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined, color: AppColors.forestGreen),
            tooltip: 'الإعدادات والأمان',
            onPressed: () => context.push(AppRoutes.settings),
          ),
        ],
      ),
      body: SafeArea(
        child: switch (state) {
          DashboardInitial() || DashboardLoading() => const Center(
              child: CircularProgressIndicator(color: AppColors.forestGreen),
            ),
          DashboardError(:final message) => Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: LuxuryCard(
                  borderColor: AppColors.criticalRed,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.error_outline, size: 40, color: AppColors.criticalRed),
                      const SizedBox(height: 12),
                      Text(message, style: AppTypography.bodyPrimary, textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => ref.read(dashboardControllerProvider.notifier).loadDashboard(),
                        child: const Text('إعادة المحاولة'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          DashboardLoaded(:final summary) => SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // بطاقة صافي الثروة التراكمية
                  NetWorthCard(
                    netWorth: summary.netWorth,
                    monthlyChangePercentage: summary.monthlyChangePercentage,
                  ),
                  const SizedBox(height: 20),

                  // عنوان شبكة الأقسام المالية
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('الأنظمة المالية المتكاملة', style: AppTypography.headingH3),
                      const StatusBadge(
                        text: '12 نظاماً نشطاً',
                        color: AppColors.surfaceLight,
                        textColor: AppColors.forestGreen,
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // شبكة الأقسام المالية الرئيسية (8 أقسام)
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.25,
                    children: [
                      _buildNavTile(
                        context: context,
                        icon: Icons.account_balance_rounded,
                        title: 'الخزينة الموحدة',
                        subtitle: 'الأرصدة والتحويلات',
                        color: AppColors.forestGreen,
                        route: AppRoutes.treasury,
                      ),
                      _buildNavTile(
                        context: context,
                        icon: Icons.attach_money_rounded,
                        title: 'الدخل والراتب',
                        subtitle: 'توزيع 40/20/20/10/10',
                        color: AppColors.cashIn,
                        route: AppRoutes.income,
                      ),
                      _buildNavTile(
                        context: context,
                        icon: Icons.receipt_long_rounded,
                        title: 'المصروفات والسجل',
                        subtitle: 'المعاملات والتصنيفات',
                        color: AppColors.cashOut,
                        route: AppRoutes.expenses,
                      ),
                      _buildNavTile(
                        context: context,
                        icon: Icons.pie_chart_outline_rounded,
                        title: 'الميزانيات الشهرية',
                        subtitle: 'الحدود والتنبيهات',
                        color: AppColors.champagneGold,
                        route: AppRoutes.budgets,
                      ),
                      _buildNavTile(
                        context: context,
                        icon: Icons.savings_rounded,
                        title: 'الادخار العام',
                        subtitle: 'النمو والحركات اليدوية',
                        color: AppColors.forestGreen,
                        route: AppRoutes.savings,
                      ),
                      _buildNavTile(
                        context: context,
                        icon: Icons.shield_rounded,
                        title: 'صندوق الطوارئ',
                        subtitle: 'السحب المشروط بالسبب',
                        color: AppColors.criticalRed,
                        route: AppRoutes.emergencyFund,
                      ),
                      _buildNavTile(
                        context: context,
                        icon: Icons.flag_rounded,
                        title: 'الأهداف والمشتريات',
                        subtitle: 'التخصيص والتنفيذ',
                        color: AppColors.champagneGold,
                        route: AppRoutes.goals,
                      ),
                      _buildNavTile(
                        context: context,
                        icon: Icons.handshake_outlined,
                        title: 'الالتزامات والديون',
                        subtitle: 'الأقساط وصافي الثروة',
                        color: AppColors.cashOut,
                        route: AppRoutes.liabilitiesOverview,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // بطاقة الوصول السريع للتقارير والإعدادات
                  LuxuryCard(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        TextButton.icon(
                          onPressed: () => context.push(AppRoutes.analytics),
                          icon: const Icon(Icons.bar_chart_rounded, color: AppColors.forestGreen),
                          label: const Text('التقارير والتوقعات'),
                        ),
                        Container(width: 1, height: 24, color: AppColors.borderSubtleLight),
                        TextButton.icon(
                          onPressed: () => context.push(AppRoutes.settings),
                          icon: const Icon(Icons.security_rounded, color: AppColors.champagneGold),
                          label: const Text('الأمان والنسخ'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          _ => const SizedBox.shrink(),
        },
      ),
    );
  }

  Widget _buildNavTile({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required String route,
  }) {
    return LuxuryCard(
      onTap: () => context.push(route),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: AppTypography.headingH3.copyWith(fontSize: 14),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: AppTypography.bodySecondary.copyWith(fontSize: 10),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
