import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../application/dashboard_state.dart';
import '../../data/repositories/dashboard_repository_impl.dart';
import '../../domain/repositories/dashboard_repository.dart';

/// مزود مستودع لوحة التحكم
final dashboardRepositoryProvider = Provider<DashboardRepository>((ref) {
  return DashboardRepositoryImpl();
});

/// متحكم لوحة التحكم بإدارة حالة Riverpod
final dashboardControllerProvider =
    StateNotifierProvider<DashboardController, DashboardState>((ref) {
  final repository = ref.watch(dashboardRepositoryProvider);
  return DashboardController(repository)..loadDashboard();
});

class DashboardController extends StateNotifier<DashboardState> {
  final DashboardRepository _repository;

  DashboardController(this._repository) : super(const DashboardInitial());

  Future<void> loadDashboard() async {
    state = const DashboardLoading();
    try {
      final summary = await _repository.getNetWorthSummary();
      state = DashboardLoaded(summary);
    } catch (e) {
      state = DashboardError('تعذر تحميل بيانات اللوحة: ${e.toString()}');
    }
  }
}

