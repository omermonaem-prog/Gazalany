import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import 'package:my_finance/features/income/application/income_controller.dart';
import 'package:my_finance/features/income/application/income_state.dart';
import 'package:my_finance/features/income/domain/entities/income_entry.dart';
import '../widgets/income_card.dart';
import 'record_additional_income_screen.dart';
import 'record_salary_screen.dart';

/// شاشة لوحة تحكم وسجل الدخل المالي (Income Dashboard & History Screen)
class IncomeDashboardScreen extends ConsumerWidget {
  const IncomeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(incomeControllerProvider);
    final controller = ref.read(incomeControllerProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('إدارة وتوزيع التدفقات'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadIncomes(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. بطاقة إجماليات الدخل المالي المفصولة
              _buildIncomeSummaryCards(state),
              const SizedBox(height: 20),

              // 2. أزرار الإجراءات السريعة
              Row(
                children: [
                  Expanded(
                    child: LuxuryButton(
                      label: '+ راتب أساسي',
                      icon: Icons.account_balance_wallet,
                      type: LuxuryButtonType.primary,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const RecordSalaryScreen(),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: LuxuryButton(
                      label: '+ دخل إضافي',
                      icon: Icons.trending_up,
                      type: LuxuryButtonType.secondary,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const RecordAdditionalIncomeScreen(),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // 3. شريط الفلترة بين الأنواع
              _buildFilterTabs(state, controller),
              const SizedBox(height: 16),

              // 4. قائمة السجلات
              if (state.isLoading)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(40.0),
                    child: CircularProgressIndicator(color: AppColors.forestGreen),
                  ),
                )
              else if (state.filteredIncomes.isEmpty)
                _buildEmptyState()
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: state.filteredIncomes.length,
                  separatorBuilder: (context, index) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final income = state.filteredIncomes[index];
                    return IncomeCard(
                      entry: income,
                      onCorrect: () => _showCorrectionDialog(context, ref, income),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIncomeSummaryCards(IncomeState state) {
    return LuxuryCard(
      backgroundColor: AppColors.forestGreen,
      borderColor: AppColors.champagneGold,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'إجمالي التدفقات الواردة المعتمدة',
            style: AppTypography.bodySecondary.copyWith(
              color: AppColors.canvasLight.withValues(alpha: 0.8),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            state.totalAll.formatArabic(),
            style: AppTypography.displayLarge.copyWith(
              color: AppColors.champagneGoldBright,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          const Divider(color: AppColors.champagneGold, height: 1),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'الراتب الأساسي',
                      style: AppTypography.bodySecondary.copyWith(
                        color: AppColors.canvasLight.withValues(alpha: 0.7),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      state.totalSalary.formatArabic(),
                      style: AppTypography.headingH3.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Container(width: 1, height: 36, color: Colors.white24),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'الدخل الإضافي',
                      style: AppTypography.bodySecondary.copyWith(
                        color: AppColors.canvasLight.withValues(alpha: 0.7),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      state.totalAdditional.formatArabic(),
                      style: AppTypography.headingH3.copyWith(
                        color: AppColors.champagneGoldBright,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFilterTabs(IncomeState state, IncomeController controller) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppColors.surfaceSubtleLight,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: IncomeFilter.values.map((filter) {
          final isSelected = state.filter == filter;
          return Expanded(
            child: GestureDetector(
              onTap: () => controller.setFilter(filter),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.surfaceLight : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.05),
                            blurRadius: 4,
                          ),
                        ]
                      : null,
                ),
                child: Center(
                  child: Text(
                    filter.labelArabic,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                      color: isSelected ? AppColors.forestGreen : AppColors.slateMuted,
                    ),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildEmptyState() {
    return LuxuryCard(
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
      child: Center(
        child: Column(
          children: [
            Icon(Icons.inbox_outlined, size: 48, color: AppColors.slateMuted.withValues(alpha: 0.5)),
            const SizedBox(height: 12),
            Text(
              'لا توجد سجلات دخل حتى الآن',
              style: AppTypography.headingH3.copyWith(color: AppColors.slateMuted),
            ),
            const SizedBox(height: 4),
            Text(
              'سجّل راتبك أو دخلك الإضافي لمعاينة وتوزيع التدفقات الذكية',
              style: AppTypography.bodySecondary,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _showCorrectionDialog(BuildContext context, WidgetRef ref, IncomeEntry income) {
    final amountController = TextEditingController(text: income.amount.toMajorUnits().toString());
    final descController = TextEditingController(text: income.description);
    final reasonController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('تصحيح قيد الدخل', style: AppTypography.headingH3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'سيتم عكس القيد السابق (${income.amount.formatArabic()}) وإثبات القيد المصحح مع حفظ كامل الأثر في سجل التدقيق.',
              style: AppTypography.bodySecondary,
            ),
            const SizedBox(height: 14),
            TextField(
              controller: amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'المبلغ المصحح (ر.س)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: descController,
              decoration: const InputDecoration(
                labelText: 'الوصف الجديد',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: reasonController,
              decoration: const InputDecoration(
                labelText: 'سبب التصحيح (إلزامي)',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.forestGreen,
            ),
            onPressed: () async {
              final reason = reasonController.text.trim();
              if (reason.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('يجب توثيق سبب التصحيح محاسبياً')),
                );
                return;
              }
              final newAmount = Money.parse(amountController.text.trim());
              final key = 'corr_${DateTime.now().millisecondsSinceEpoch}';

              final success = await ref.read(incomeControllerProvider.notifier).correctIncome(
                    originalIncomeId: income.id,
                    newAmount: newAmount,
                    newDate: income.date,
                    newSource: income.source,
                    newDescription: descController.text.trim(),
                    reason: reason,
                    idempotencyKey: key,
                  );

              if (context.mounted && success) {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('تم تصحيح القيد المالي وربطه بالأصل بنجاح')),
                );
              }
            },
            child: const Text('اعتماد التصحيح'),
          ),
        ],
      ),
    );
  }
}

