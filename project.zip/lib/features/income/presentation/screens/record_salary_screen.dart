import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import 'package:my_finance/features/income/application/income_controller.dart';
import 'package:my_finance/features/income/domain/entities/income_distribution_spec.dart';
import 'package:my_finance/features/income/domain/entities/income_type.dart';
import '../widgets/income_distribution_preview_sheet.dart';

/// شاشة تسجيل الراتب الأساسي (Record Salary Screen)
class RecordSalaryScreen extends ConsumerStatefulWidget {
  const RecordSalaryScreen({super.key});

  @override
  ConsumerState<RecordSalaryScreen> createState() => _RecordSalaryScreenState();
}

class _RecordSalaryScreenState extends ConsumerState<RecordSalaryScreen> {
  final _amountController = TextEditingController();
  final _sourceController = TextEditingController(text: 'جهة العمل الرئيسية');
  final _descController = TextEditingController(text: 'راتب شهري');
  final _notesController = TextEditingController();

  DateTime _selectedDate = DateTime.now();
  String _selectedAccountId = 'acc_primary';
  final String _selectedAccountName = 'الحساب البنكي الرئيسي';

  @override
  void dispose() {
    _amountController.dispose();
    _sourceController.dispose();
    _descController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _onPreviewPressed() {
    final text = _amountController.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى إدخال مبلغ الراتب أولاً')),
      );
      return;
    }

    try {
      final amount = Money.parse(text);
      if (!amount.isPositive) {
        throw ArgumentError('المبلغ يجب أن يكون موجباً');
      }

      ref.read(incomeControllerProvider.notifier).generateDistributionPreview(amount);

      final state = ref.read(incomeControllerProvider);
      final preview = state.activePreview;

      if (preview != null) {
        _showPreviewModal(preview, amount);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ في إدخال المبلغ: $e')),
      );
    }
  }

  void _showPreviewModal(IncomeDistributionPreview preview, Money amount) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return Consumer(
          builder: (context, ref, child) {
            final incomeState = ref.watch(incomeControllerProvider);

            return IncomeDistributionPreviewSheet(
              preview: preview,
              incomeType: IncomeType.salary,
              accountName: _selectedAccountName,
              isExecuting: incomeState.isExecutingDistribution,
              onCancel: () {
                ref.read(incomeControllerProvider.notifier).cancelDistributionPreview();
                Navigator.pop(ctx);
              },
              onConfirm: () async {
                final key = 'salary_${DateTime.now().millisecondsSinceEpoch}';
                final success = await ref
                    .read(incomeControllerProvider.notifier)
                    .confirmAndExecuteDistribution(
                      accountId: _selectedAccountId,
                      type: IncomeType.salary,
                      amount: amount,
                      date: _selectedDate,
                      source: _sourceController.text.trim(),
                      description: _descController.text.trim(),
                      notes: _notesController.text.trim().isEmpty
                          ? null
                          : _notesController.text.trim(),
                      idempotencyKey: key,
                    );

                if (mounted && success) {
                  Navigator.pop(ctx); // إغلاق الصفيحة
                  _showSuccessDialog(preview);
                }
              },
            );
          },
        );
      },
    );
  }

  void _showSuccessDialog(IncomeDistributionPreview preview) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: AppColors.surfaceLight,
        title: Row(
          children: [
            const Icon(Icons.check_circle, color: AppColors.cashIn, size: 28),
            const SizedBox(width: 10),
            Text('تم التوزيع بنجاح', style: AppTypography.headingH2),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'تم إيداع واعتماد توزيع الراتب بمبلغ ${preview.originalIncome.formatArabic()} وتحديث الخزينة وصندوق الطوارئ وكافة الأرصدة ذرياً.',
              style: AppTypography.bodyPrimary,
            ),
            const SizedBox(height: 14),
            Text(
              'حصص التوزيع المنفذة:',
              style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            ...preview.items.map((item) => Text(
                  '• ${item.category.title} (${item.category.percentage.toInt()}%): ${item.amount.formatArabic()}',
                  style: AppTypography.bodySecondary,
                )),
          ],
        ),
        actions: [
          LuxuryButton(
            label: 'تم، العودة لسجل الدخل',
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('تسجيل الراتب الأساسي'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // بطاقة إدخال المبلغ
            LuxuryCard(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'مبلغ الراتب الصافي (ر.س)',
                    style: AppTypography.bodySecondary.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _amountController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    style: AppTypography.financialNumberLarge.copyWith(
                      color: AppColors.forestGreen,
                      fontSize: 34,
                    ),
                    decoration: const InputDecoration(
                      hintText: '0.00',
                      border: InputBorder.none,
                      suffixText: 'ر.س',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // بطاقة الحساب وتفاصيل الدخل
            LuxuryCard(
              child: Column(
                children: [
                  // جهة العمل / المصدر
                  TextField(
                    controller: _sourceController,
                    decoration: const InputDecoration(
                      labelText: 'جهة العمل / مصدر الراتب',
                      prefixIcon: Icon(Icons.apartment, color: AppColors.forestGreen),
                      border: UnderlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // الوصف
                  TextField(
                    controller: _descController,
                    decoration: const InputDecoration(
                      labelText: 'وصف الدخل',
                      prefixIcon: Icon(Icons.description_outlined, color: AppColors.forestGreen),
                      border: UnderlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // الحساب المستلم
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.account_balance, color: AppColors.forestGreen),
                    title: Text('الحساب المستلم', style: AppTypography.bodySecondary),
                    subtitle: Text(_selectedAccountName, style: AppTypography.bodyPrimary),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 14),
                    onTap: () {
                      // اختيار الحساب
                    },
                  ),
                  const Divider(),

                  // تاريخ الاستلام
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.calendar_today, color: AppColors.forestGreen),
                    title: Text('تاريخ الاستلام', style: AppTypography.bodySecondary),
                    subtitle: Text(
                      '${_selectedDate.year}/${_selectedDate.month}/${_selectedDate.day}',
                      style: AppTypography.bodyPrimary,
                    ),
                    trailing: const Icon(Icons.edit_calendar, size: 18),
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _selectedDate,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2030),
                      );
                      if (picked != null) {
                        setState(() => _selectedDate = picked);
                      }
                    },
                  ),

                  // ملاحظات إضافية
                  TextField(
                    controller: _notesController,
                    maxLines: 2,
                    decoration: const InputDecoration(
                      labelText: 'ملاحظات (اختياري)',
                      prefixIcon: Icon(Icons.notes, color: AppColors.slateMuted),
                      border: InputBorder.none,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // زر المعاينة قبل التأكيد
            LuxuryButton(
              label: 'معاينة خطة توزيع الراتب (40/20/20/10/10)',
              icon: Icons.pie_chart_outline,
              onPressed: _onPreviewPressed,
              type: LuxuryButtonType.primary,
            ),
          ],
        ),
      ),
    );
  }
}

