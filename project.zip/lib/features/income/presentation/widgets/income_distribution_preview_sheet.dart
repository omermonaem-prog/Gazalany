import 'package:flutter/material.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../domain/entities/income_distribution_spec.dart';
import '../../domain/entities/income_type.dart';
import 'distribution_breakdown_widget.dart';

/// صفيحة معاينة وتأكيد التوزيع المالي (Income Distribution Preview Sheet)
class IncomeDistributionPreviewSheet extends StatelessWidget {
  final IncomeDistributionPreview preview;
  final IncomeType incomeType;
  final String accountName;
  final bool isExecuting;
  final VoidCallback onConfirm;
  final VoidCallback onCancel;

  const IncomeDistributionPreviewSheet({
    super.key,
    required this.preview,
    required this.incomeType,
    required this.accountName,
    required this.isExecuting,
    required this.onConfirm,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.canvasLight,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: EdgeInsets.only(
        top: 20,
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // مقبض السحب العلوي
            Center(
              child: Container(
                width: 44,
                height: 5,
                decoration: BoxDecoration(
                  color: AppColors.borderSubtleLight,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 18),

            // عنوان المعاينة
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.forestGreen.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.auto_awesome,
                    color: AppColors.forestGreen,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'معاينة توزيع ${incomeType.arabicLabel}',
                        style: AppTypography.headingH2,
                      ),
                      Text(
                        'حساب الاستقبال: $accountName',
                        style: AppTypography.bodySecondary,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // تفاصيل الأقسام الخمسة والقيد الصفري
            DistributionBreakdownWidget(preview: preview),

            const SizedBox(height: 24),

            // أزرار التأكيد والإلغاء الصريحة
            Row(
              children: [
                // زر الإلغاء دون أي تغيير
                Expanded(
                  child: OutlinedButton(
                    onPressed: isExecuting ? null : onCancel,
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.borderSubtleLight, width: 1.5),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text(
                      'إلغاء دون تغيير',
                      style: AppTypography.bodyPrimary.copyWith(
                        color: AppColors.slateMuted,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                // زر التأكيد والاعتماد الذري
                Expanded(
                  flex: 2,
                  child: LuxuryButton(
                    label: 'تأكيد واعتماد التوزيع',
                    icon: Icons.lock_outline,
                    isLoading: isExecuting,
                    onPressed: isExecuting ? null : onConfirm,
                    type: LuxuryButtonType.primary,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

