import 'package:flutter/material.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/income_distribution_spec.dart';

/// ويدجت عرض تفاصيل توزيع النسب الخمس المعتمدة
class DistributionBreakdownWidget extends StatelessWidget {
  final IncomeDistributionPreview preview;

  const DistributionBreakdownWidget({
    super.key,
    required this.preview,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // بطاقة إجمالي الدخل الموزع
        LuxuryCard(
          backgroundColor: AppColors.surfaceSubtleLight,
          borderColor: AppColors.champagneGold,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'إجمالي الدخل المراد توزيعه:',
                style: AppTypography.headingH3,
              ),
              Text(
                preview.originalIncome.formatArabic(),
                style: AppTypography.headingH2.copyWith(
                  color: AppColors.forestGreen,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // قائمة الأقسام الخمسة
        ...preview.items.map((item) {
          final cat = item.category;
          final color = Color(int.parse(cat.colorHex.replaceFirst('#', '0xFF')));

          return Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.surfaceLight,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.borderSubtleLight),
              ),
              child: Row(
                children: [
                  // شارة ملونة للأيقونة
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Text(
                        '${cat.percentage.toInt()}%',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: color,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  // عنوان القسم والنسبة
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          cat.title,
                          style: AppTypography.bodyPrimary.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          'حصة ثابتة ${cat.percentage.toInt()}% من الدخل',
                          style: AppTypography.bodySecondary,
                        ),
                      ],
                    ),
                  ),
                  // المبلغ المحسوب بالريال والهللات
                  Text(
                    item.amount.formatArabic(),
                    style: AppTypography.headingH3.copyWith(
                      color: AppColors.forestGreen,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          );
        }),

        const SizedBox(height: 10),

        // شريط التحقق من القيد الصفري (Zero-Sum Invariant Badge)
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: preview.isZeroSumValid
                ? AppColors.cashIn.withValues(alpha: 0.08)
                : AppColors.criticalRed.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: preview.isZeroSumValid ? AppColors.cashIn : AppColors.criticalRed,
              width: 1,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(
                    preview.isZeroSumValid ? Icons.check_circle : Icons.error_outline,
                    size: 18,
                    color: preview.isZeroSumValid ? AppColors.cashIn : AppColors.criticalRed,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    preview.isZeroSumValid ? 'مجموع التوزيع يطابق الدخل 100%' : 'تنبيه: فرق في التوزيع',
                    style: AppTypography.bodySecondary.copyWith(
                      fontWeight: FontWeight.w600,
                      color: preview.isZeroSumValid ? AppColors.cashIn : AppColors.criticalRed,
                    ),
                  ),
                ],
              ),
              Text(
                'الإجمالي: ${preview.totalDistributed.formatArabic()}',
                style: AppTypography.bodyPrimary.copyWith(
                  fontWeight: FontWeight.w700,
                  color: preview.isZeroSumValid ? AppColors.cashIn : AppColors.criticalRed,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

