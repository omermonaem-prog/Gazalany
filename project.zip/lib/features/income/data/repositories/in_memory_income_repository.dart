import '../../../../core/finance/money.dart';
import 'package:my_finance/features/financial_engine/domain/entities/transaction_entity.dart';
import '../../domain/entities/income_entry.dart';
import '../../domain/entities/income_type.dart';
import '../../domain/repositories/income_repository.dart';

/// تطبيق محاكي لذاكرة الوصول العشوائي لمستودع الدخل
class InMemoryIncomeRepository implements IncomeRepository {
  final Map<String, IncomeEntry> _store = {};

  @override
  Future<void> saveIncome(IncomeEntry entry) async {
    _store[entry.id] = entry;
  }

  @override
  Future<List<IncomeEntry>> getAllIncomes() async {
    final list = _store.values.toList();
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<List<IncomeEntry>> getIncomesByType(IncomeType type) async {
    final list = _store.values.where((i) => i.type == type).toList();
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<IncomeEntry?> getIncomeById(String id) async => _store[id];

  @override
  Future<void> updateIncomeStatus(String id, TransactionStatus status) async {
    final item = _store[id];
    if (item != null) {
      _store[id] = item.copyWith(status: status);
    }
  }

  @override
  Future<Money> getTotalIncomeByType(IncomeType type) async {
    final items = _store.values
        .where((i) => i.type == type && i.status != TransactionStatus.reversed);
    return items.fold<Money>(
      const Money.zero(),
      (sum, item) => sum + item.amount,
    );
  }

  @override
  Future<Money> getTotalIncomeAll() async {
    final items = _store.values
        .where((i) => i.status != TransactionStatus.reversed);
    return items.fold<Money>(
      const Money.zero(),
      (sum, item) => sum + item.amount,
    );
  }
}

