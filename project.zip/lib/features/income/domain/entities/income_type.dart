/// نوع التدفق المالي الوارد
enum IncomeType {
  /// راتب شهري أساسي دوري
  salary,

  /// دخل إضافي، عمل حر، مكافأة، أو استثمار
  additional;

  String get arabicLabel {
    switch (this) {
      case IncomeType.salary:
        return 'راتب أساسي';
      case IncomeType.additional:
        return 'دخل إضافي';
    }
  }

  String toDbString() {
    switch (this) {
      case IncomeType.salary:
        return 'salary';
      case IncomeType.additional:
        return 'additional';
    }
  }

  static IncomeType fromString(String val) {
    switch (val.toLowerCase()) {
      case 'salary':
      case 'basic_salary':
        return IncomeType.salary;
      case 'additional':
      case 'extra':
      case 'freelance':
        return IncomeType.additional;
      default:
        return IncomeType.salary;
    }
  }
}

