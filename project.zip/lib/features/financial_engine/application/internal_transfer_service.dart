import 'package:my_finance/core/finance/financial_exceptions.dart';
import 'package:my_finance/core/finance/money.dart';
import '../domain/entities/audit_trail_entry.dart';
import '../domain/entities/transaction_entity.dart';
import '../domain/repositories/financial_engine_repository.dart';
import 'balance_calculation_service.dart';
import 'idempotency_service.dart';

/// خدمة التحويلات الداخلية بين الحسابات والخزائن (Internal Transfer Service)
///
/// القواعد المحاسبية الصارمة:
/// 1. التحويل الداخلي لا يغير إجمالي الأموال نهائياً:
///    Δ Balance_Source + Δ Balance_Destination = 0
/// 2. منع التحويل الذاتي (من نفس الحساب وإليه).
/// 3. التحقق الذري من كفاية رصيد الحساب المصدر.
/// 4. توثيق أثر الخصم والإيداع في سجل التدقيق المحاسبي.
class InternalTransferService {
  final FinancialEngineRepository _repository;
  final BalanceCalculationService _balanceService;
  final IdempotencyService _idempotencyService;

  InternalTransferService({
    required FinancialEngineRepository repository,
    required BalanceCalculationService balanceService,
    required IdempotencyService idempotencyService,
  })  : _repository = repository,
        _balanceService = balanceService,
        _idempotencyService = idempotencyService;

  /// تنفيذ تحويل داخلي ذري بين محفظتين
  Future<TransactionEntity> executeTransfer({
    required String transactionId,
    required String fromAccountId,
    required String toAccountId,
    required Money amount,
    required DateTime date,
    String? note,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      throw ArgumentError('مبلغ التحويل يجب أن يكون موجباً قطعاً');
    }
    if (fromAccountId == toAccountId) {
      throw ArgumentError('قيد محاسبي: لا يمكن إجراء تحويل داخلي من الحساب وإلى نفسه');
    }

    // 1. حراسة منع التكرار
    await _idempotencyService.assertNotProcessed(idempotencyKey);

    return await _repository.runInTransaction(() async {
      // 2. التحقق من الحساب المصدر والوجهة
      final source = await _repository.getAccountById(fromAccountId);
      if (source == null) {
        throw EntityNotFoundException(entityType: 'حساب المصدر', entityId: fromAccountId);
      }
      final destination = await _repository.getAccountById(toAccountId);
      if (destination == null) {
        throw EntityNotFoundException(entityType: 'حساب الوجهة', entityId: toAccountId);
      }

      // فحص الأرشفة
      if (source.isArchived) throw AccountArchivedException(fromAccountId);
      if (destination.isArchived) throw AccountArchivedException(toAccountId);

      // فحص كفاية الرصيد
      _balanceService.assertSufficientBalance(
        account: source,
        amountToDeduct: amount,
      );

      final sourceBefore = source.balance;
      final sourceAfter = sourceBefore - amount;

      final destBefore = destination.balance;
      final destAfter = destBefore + amount;

      // 3. إنشاء قيد المعاملة الموحد للتحويل
      final transaction = TransactionEntity(
        id: transactionId,
        accountId: fromAccountId,
        destinationAccountId: toAccountId,
        type: TransactionType.internalTransfer,
        amount: amount,
        transactionDate: date,
        note: note,
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      // 4. حفظ المعاملة وتحديث أرصدة الحسابين ذرياً
      await _repository.saveTransaction(transaction);
      await _repository.updateAccountBalance(fromAccountId, sourceAfter);
      await _repository.updateAccountBalance(toAccountId, destAfter);

      // 5. تسجيل قيدي الرقابة والتدقيق (قيد المصدر وقيد الوجهة)
      await _repository.recordAuditEntry(AuditTrailEntry(
        id: '${transactionId}_src_audit',
        transactionId: transactionId,
        operationType: 'internal_transfer_out',
        entityType: 'account',
        entityId: fromAccountId,
        balanceBefore: sourceBefore,
        delta: -amount,
        balanceAfter: sourceAfter,
        idempotencyKey: idempotencyKey,
        note: 'تحويل صادر إلى ${destination.name}',
        timestamp: DateTime.now(),
      ));

      await _repository.recordAuditEntry(AuditTrailEntry(
        id: '${transactionId}_dst_audit',
        transactionId: transactionId,
        operationType: 'internal_transfer_in',
        entityType: 'account',
        entityId: toAccountId,
        balanceBefore: destBefore,
        delta: amount,
        balanceAfter: destAfter,
        idempotencyKey: idempotencyKey,
        note: 'تحويل وارد من ${source.name}',
        timestamp: DateTime.now(),
      ));

      // 6. تسجيل إنجاز العملية بمفتاح منع التكرار
      await _idempotencyService.markOperationCompleted(
        idempotencyKey: idempotencyKey,
        transactionId: transactionId,
        operationType: 'transfer',
        responseSummary: 'تحويل ${amount.formatArabic()} من $fromAccountId إلى $toAccountId',
      );

      return transaction;
    });
  }
}

