import 'package:my_finance/core/finance/financial_exceptions.dart';
import '../domain/entities/audit_trail_entry.dart';
import '../domain/entities/transaction_entity.dart';
import '../domain/repositories/financial_engine_repository.dart';
import 'idempotency_service.dart';

/// خدمة عكس وتصحيح المعاملات المالية (Reversal & Correction Service)
///
/// القواعد المحاسبية الصارمة:
/// 1. لا حذف فيزيائي للبيانات أو المعاملات السابقة إطلاقاً (No physical deletion).
/// 2. الحفاظ الكامل على أثر وتاريخ وسياق العملية الأصلية.
/// 3. عملية العكس تُنشئ قيداً محاسبياً مقابلاً ومعاكساً تماماً للأثر المالي.
/// 4. لا يجوز عكس المعاملة المعكوسة مسبقاً (No double reversals).
/// 5. تصحيح المعاملة يتم عبر عكس الأصلية أولاً ثم إثبات المصححة مع ربطهما تسلسلياً.
class ReversalCorrectionService {
  final FinancialEngineRepository _repository;
  final IdempotencyService _idempotencyService;

  ReversalCorrectionService({
    required FinancialEngineRepository repository,
    required IdempotencyService idempotencyService,
  })  : _repository = repository,
        _idempotencyService = idempotencyService;

  /// عكس معاملة مالية سابقة وإلغاء أثرها المحاسبي بأمان
  Future<TransactionEntity> reverseTransaction({
    required String originalTransactionId,
    required String reversalTransactionId,
    required String reason,
    required String idempotencyKey,
  }) async {
    await _idempotencyService.assertNotProcessed(idempotencyKey);

    return await _repository.runInTransaction(() async {
      // 1. استرجاع المعاملة الأصلية والتحقق منها
      final original = await _repository.getTransactionById(originalTransactionId);
      if (original == null) {
        throw EntityNotFoundException(
          entityType: 'معاملة مالية',
          entityId: originalTransactionId,
        );
      }

      if (original.status == TransactionStatus.reversed) {
        throw TransactionAlreadyReversedException(originalTransactionId);
      }

      final amount = original.amount;

      // 2. معالجة عكس الأثر المحاسبي بحسب نوع المعاملة
      switch (original.type) {
        case TransactionType.expense:
          // إعادة المبلغ المخصوم إلى رصيد الحساب
          final account = await _repository.getAccountById(original.accountId);
          if (account == null) {
            throw EntityNotFoundException(entityType: 'حساب', entityId: original.accountId);
          }
          final before = account.balance;
          final after = before + amount;
          await _repository.updateAccountBalance(original.accountId, after);

          await _repository.recordAuditEntry(AuditTrailEntry(
            id: '${reversalTransactionId}_audit',
            transactionId: reversalTransactionId,
            operationType: 'reversal_expense',
            entityType: 'account',
            entityId: original.accountId,
            balanceBefore: before,
            delta: amount,
            balanceAfter: after,
            idempotencyKey: idempotencyKey,
            note: 'عكس المصروف $originalTransactionId بسبب: $reason',
            timestamp: DateTime.now(),
          ));
          break;

        case TransactionType.income:
          // خصم الدخل الذي تم إيداعه سابقاً
          final account = await _repository.getAccountById(original.accountId);
          if (account == null) {
            throw EntityNotFoundException(entityType: 'حساب', entityId: original.accountId);
          }
          final before = account.balance;
          final after = before - amount;
          if (after.isNegative) {
            throw NegativeBalanceForbiddenException(
              accountId: original.accountId,
              projectedBalanceMinorUnits: after.minorUnits,
            );
          }
          await _repository.updateAccountBalance(original.accountId, after);

          await _repository.recordAuditEntry(AuditTrailEntry(
            id: '${reversalTransactionId}_audit',
            transactionId: reversalTransactionId,
            operationType: 'reversal_income',
            entityType: 'account',
            entityId: original.accountId,
            balanceBefore: before,
            delta: -amount,
            balanceAfter: after,
            idempotencyKey: idempotencyKey,
            note: 'عكس الدخل $originalTransactionId بسبب: $reason',
            timestamp: DateTime.now(),
          ));
          break;

        case TransactionType.internalTransfer:
          // إعادة المبلغ من الوجهة إلى المصدر
          final srcAccount = await _repository.getAccountById(original.accountId);
          final dstAccount = await _repository.getAccountById(original.destinationAccountId ?? '');
          if (srcAccount == null || dstAccount == null) {
            throw const EntityNotFoundException(entityType: 'أحد حسابي التحويل', entityId: '');
          }
          // التأكد من أن حساب الوجهة يملك الرصيد الكافي للاسترجاع
          if (dstAccount.balance < amount) {
            throw InsufficientFundsException(
              availableMinorUnits: dstAccount.balance.minorUnits,
              requiredMinorUnits: amount.minorUnits,
              customMessage: 'لا يمكن عكس التحويل: رصيد حساب الوجهة غير كافٍ للاسترداد',
            );
          }

          final srcBefore = srcAccount.balance;
          final srcAfter = srcBefore + amount;
          final dstBefore = dstAccount.balance;
          final dstAfter = dstBefore - amount;

          await _repository.updateAccountBalance(srcAccount.id, srcAfter);
          await _repository.updateAccountBalance(dstAccount.id, dstAfter);

          await _repository.recordAuditEntry(AuditTrailEntry(
            id: '${reversalTransactionId}_src_audit',
            transactionId: reversalTransactionId,
            operationType: 'reversal_transfer_credit',
            entityType: 'account',
            entityId: srcAccount.id,
            balanceBefore: srcBefore,
            delta: amount,
            balanceAfter: srcAfter,
            idempotencyKey: idempotencyKey,
            note: 'استعادة مبلغ التحويل المعكوس من ${dstAccount.name}',
            timestamp: DateTime.now(),
          ));

          await _repository.recordAuditEntry(AuditTrailEntry(
            id: '${reversalTransactionId}_dst_audit',
            transactionId: reversalTransactionId,
            operationType: 'reversal_transfer_debit',
            entityType: 'account',
            entityId: dstAccount.id,
            balanceBefore: dstBefore,
            delta: -amount,
            balanceAfter: dstAfter,
            idempotencyKey: idempotencyKey,
            note: 'رد مبلغ التحويل المعكوس إلى ${srcAccount.name}',
            timestamp: DateTime.now(),
          ));
          break;

        case TransactionType.goalAllocation:
          // إعادة مبلغ تخصيص الهدف إلى رصيد الحساب
          final account = await _repository.getAccountById(original.accountId);
          if (account != null) {
            final before = account.balance;
            final after = before + amount;
            await _repository.updateAccountBalance(original.accountId, after);
          }
          break;

        default:
          throw UnsupportedError('نوع المعاملة (${original.type.name}) لا يدعم العكس المباشر');
      }

      // 3. إنشاء قيد المعاملة العكسية المخصصة
      final reversalTransaction = TransactionEntity(
        id: reversalTransactionId,
        accountId: original.accountId,
        destinationAccountId: original.destinationAccountId,
        type: TransactionType.reversal,
        amount: amount,
        transactionDate: DateTime.now(),
        note: 'عكس المعاملة [${original.id}]: $reason',
        relatedTransactionId: original.id,
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      await _repository.saveTransaction(reversalTransaction);

      // 4. تحديث حالة المعاملة الأصلية إلى Reversed دون حذف أي حرف من سجلها
      await _repository.updateTransactionStatus(
        original.id,
        TransactionStatus.reversed,
      );

      // 5. تسجيل منع التكرار
      await _idempotencyService.markOperationCompleted(
        idempotencyKey: idempotencyKey,
        transactionId: reversalTransactionId,
        operationType: 'reversal',
        responseSummary: 'تم عكس المعاملة ${original.id}',
      );

      return reversalTransaction;
    });
  }

  /// تصحيح معاملة مالية (عكس القديمة ثم إثبات الجديدة وتطبيق أثرها المحاسبي بدقة)
  Future<TransactionEntity> correctTransaction({
    required String originalTransactionId,
    required String reversalTransactionId,
    required TransactionEntity correctedTransaction,
    required String reason,
    required String idempotencyKey,
  }) async {
    return await _repository.runInTransaction(() async {
      // 1. عكس المعاملة الخاطئة أولاً لاستعادة الرصيد السابق
      await reverseTransaction(
        originalTransactionId: originalTransactionId,
        reversalTransactionId: reversalTransactionId,
        reason: 'إلغاء بغرض التصحيح: $reason',
        idempotencyKey: '${idempotencyKey}_rev',
      );

      // 2. تطبيق الأثر المحاسبي للمعاملة المصححة الجديدة
      switch (correctedTransaction.type) {
        case TransactionType.expense:
          final acc = await _repository.getAccountById(correctedTransaction.accountId);
          if (acc != null) {
            final before = acc.balance;
            final after = before - correctedTransaction.amount;
            await _repository.updateAccountBalance(acc.id, after);
            await _repository.recordAuditEntry(AuditTrailEntry(
              id: '${correctedTransaction.id}_audit',
              transactionId: correctedTransaction.id,
              operationType: 'correction_expense',
              entityType: 'account',
              entityId: acc.id,
              balanceBefore: before,
              delta: -correctedTransaction.amount,
              balanceAfter: after,
              idempotencyKey: idempotencyKey,
              note: 'قيد المصروف المصحح',
              timestamp: DateTime.now(),
            ));
          }
          break;

        case TransactionType.income:
          final acc = await _repository.getAccountById(correctedTransaction.accountId);
          if (acc != null) {
            final before = acc.balance;
            final after = before + correctedTransaction.amount;
            await _repository.updateAccountBalance(acc.id, after);
            await _repository.recordAuditEntry(AuditTrailEntry(
              id: '${correctedTransaction.id}_audit',
              transactionId: correctedTransaction.id,
              operationType: 'correction_income',
              entityType: 'account',
              entityId: acc.id,
              balanceBefore: before,
              delta: correctedTransaction.amount,
              balanceAfter: after,
              idempotencyKey: idempotencyKey,
              note: 'قيد الدخل المصحح',
              timestamp: DateTime.now(),
            ));
          }
          break;

        default:
          break;
      }

      // 3. ربط المعاملة المصححة بالمعاملة الأصلية
      final finalCorrected = correctedTransaction.copyWith(
        relatedTransactionId: originalTransactionId,
        status: TransactionStatus.corrected,
        note: '${correctedTransaction.note ?? ''} (تصحيح للمعاملة $originalTransactionId: $reason)',
      );

      // 4. حفظ المعاملة المصححة
      await _repository.saveTransaction(finalCorrected);

      return finalCorrected;
    });
  }
}
