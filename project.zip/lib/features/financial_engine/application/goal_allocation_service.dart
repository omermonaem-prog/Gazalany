import 'package:my_finance/core/finance/financial_exceptions.dart';
import 'package:my_finance/core/finance/money.dart';
import '../domain/entities/audit_trail_entry.dart';
import '../domain/entities/transaction_entity.dart';
import '../domain/repositories/financial_engine_repository.dart';
import 'balance_calculation_service.dart';
import 'idempotency_service.dart';

/// خدمة تخصيص الأموال للأهداف المالية (Goal Allocation Service)
///
/// القواعد المحاسبية الصارمة:
/// 1. تخصيص المال للهدف لا يُسجل كمصروف أبداً (NOT an expense).
/// 2. تخصيص المال يقتطع من السيولة المتاحة للإنفاق ويعزز رصيد الهدف المحجوز.
/// 3. إجمالي أموال المستخدم يظل ثابتاً، ولكن السيولة المتاحة تتناقص بمقدار الحجز.
/// 4. عند إلغاء التخصيص أو التراجع عنه، تعود الأموال فورياً للسيولة المتاحة.
class GoalAllocationService {
  final FinancialEngineRepository _repository;
  final BalanceCalculationService _balanceService;
  final IdempotencyService _idempotencyService;

  GoalAllocationService({
    required FinancialEngineRepository repository,
    required BalanceCalculationService balanceService,
    required IdempotencyService idempotencyService,
  })  : _repository = repository,
        _balanceService = balanceService,
        _idempotencyService = idempotencyService;

  /// تخصيص مبلغ من الحساب لحساب الهدف المالي (حجز استثماري/ادخاري)
  Future<TransactionEntity> allocateToGoal({
    required String transactionId,
    required String fromAccountId,
    required String goalId,
    required Money amount,
    required DateTime date,
    String? note,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      throw ArgumentError('مبلغ التخصيص للهدف يجب أن يكون موجباً');
    }

    await _idempotencyService.assertNotProcessed(idempotencyKey);

    return await _repository.runInTransaction(() async {
      // 1. التحقق من الحساب
      final account = await _repository.getAccountById(fromAccountId);
      if (account == null) {
        throw EntityNotFoundException(entityType: 'حساب', entityId: fromAccountId);
      }
      _balanceService.assertSufficientBalance(
        account: account,
        amountToDeduct: amount,
      );

      // 2. التحقق من رصيد الهدف الحالي
      final goalCurrentSaved = await _repository.getGoalSavedAmount(goalId);
      final accountBefore = account.balance;
      final accountAfter = accountBefore - amount;
      final goalAfter = goalCurrentSaved + amount;

      // 3. إنشاء المعاملة بنوع goalAllocation الصريح (وليس expense)
      final transaction = TransactionEntity(
        id: transactionId,
        accountId: fromAccountId,
        type: TransactionType.goalAllocation,
        amount: amount,
        transactionDate: date,
        note: note ?? 'تخصيص مدخرات للهدف $goalId',
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      // 4. الحفظ وتحديث الأرصدة
      await _repository.saveTransaction(transaction);
      await _repository.updateAccountBalance(fromAccountId, accountAfter);
      await _repository.updateGoalSavedAmount(goalId, goalAfter);

      // 5. تسجيل قيود التدقيق المحاسبي
      await _repository.recordAuditEntry(AuditTrailEntry(
        id: '${transactionId}_acc_audit',
        transactionId: transactionId,
        operationType: 'goal_allocation_deduct',
        entityType: 'account',
        entityId: fromAccountId,
        balanceBefore: accountBefore,
        delta: -amount,
        balanceAfter: accountAfter,
        idempotencyKey: idempotencyKey,
        note: 'خصم لتخصيص هدف (ليس مصروفاً)',
        timestamp: DateTime.now(),
      ));

      await _repository.recordAuditEntry(AuditTrailEntry(
        id: '${transactionId}_goal_audit',
        transactionId: transactionId,
        operationType: 'goal_allocation_credit',
        entityType: 'goal',
        entityId: goalId,
        balanceBefore: goalCurrentSaved,
        delta: amount,
        balanceAfter: goalAfter,
        idempotencyKey: idempotencyKey,
        note: 'إيداع مدخرات للهدف',
        timestamp: DateTime.now(),
      ));

      await _idempotencyService.markOperationCompleted(
        idempotencyKey: idempotencyKey,
        transactionId: transactionId,
        operationType: 'goal_allocation',
        responseSummary: 'تخصيص ${amount.formatArabic()} للهدف $goalId',
      );

      return transaction;
    });
  }

  /// إلغاء تخصيص أو سحب من مدخرات الهدف وإعادتها للحساب الجاري والسيولة المتاحة
  Future<TransactionEntity> deallocateFromGoal({
    required String transactionId,
    required String toAccountId,
    required String goalId,
    required Money amount,
    required DateTime date,
    String? note,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      throw ArgumentError('مبلغ سحب التخصيص يجب أن يكون موجباً');
    }

    await _idempotencyService.assertNotProcessed(idempotencyKey);

    return await _repository.runInTransaction(() async {
      final account = await _repository.getAccountById(toAccountId);
      if (account == null) {
        throw EntityNotFoundException(entityType: 'حساب', entityId: toAccountId);
      }
      if (account.isArchived) throw AccountArchivedException(toAccountId);

      final goalCurrentSaved = await _repository.getGoalSavedAmount(goalId);
      if (goalCurrentSaved < amount) {
        throw InsufficientFundsException(
          availableMinorUnits: goalCurrentSaved.minorUnits,
          requiredMinorUnits: amount.minorUnits,
          customMessage: 'الرصيد المدخر في الهدف لا يكفي للسحب منه',
        );
      }

      final accountBefore = account.balance;
      final accountAfter = accountBefore + amount;
      final goalAfter = goalCurrentSaved - amount;

      final transaction = TransactionEntity(
        id: transactionId,
        accountId: toAccountId,
        type: TransactionType.goalDeallocation,
        amount: amount,
        transactionDate: date,
        note: note ?? 'استرداد مدخرات من الهدف $goalId',
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      await _repository.saveTransaction(transaction);
      await _repository.updateAccountBalance(toAccountId, accountAfter);
      await _repository.updateGoalSavedAmount(goalId, goalAfter);

      await _repository.recordAuditEntry(AuditTrailEntry(
        id: '${transactionId}_goal_dealloc_audit',
        transactionId: transactionId,
        operationType: 'goal_deallocation',
        entityType: 'goal',
        entityId: goalId,
        balanceBefore: goalCurrentSaved,
        delta: -amount,
        balanceAfter: goalAfter,
        idempotencyKey: idempotencyKey,
        note: 'سحب مدخرات من الهدف وإعادتها للسيولة',
        timestamp: DateTime.now(),
      ));

      await _idempotencyService.markOperationCompleted(
        idempotencyKey: idempotencyKey,
        transactionId: transactionId,
        operationType: 'goal_deallocation',
        responseSummary: 'استرداد ${amount.formatArabic()} من الهدف $goalId',
      );

      return transaction;
    });
  }
}

