import '../../../../core/finance/money.dart';
import 'allocation_plan.dart';

/// نتيجة تخصيص بند محدد بعد الحساب والتقريب الصفري
class AllocationResultItem {
  final AllocationPlanItem planItem;
  final Money allocatedAmount;
  final String destinationNote;

  const AllocationResultItem({
    required this.planItem,
    required this.allocatedAmount,
    required this.destinationNote,
  });
}

/// نتيجة توزيع الدخل الكاملة المعتمدة
class AllocationResult {
  final String planId;
  final Money totalIncome;
  final List<AllocationResultItem> items;
  final Money flexibleBudgetRemainder;
  final DateTime executedAt;
  final String depositAccountId;

  const AllocationResult({
    required this.planId,
    required this.totalIncome,
    required this.items,
    required this.flexibleBudgetRemainder,
    required this.executedAt,
    required this.depositAccountId,
  });

  /// إجمالي المبالغ المخصصة للالتزامات والأهداف والطوارئ
  Money get totalDedicatedAllocations {
    return items.fold<Money>(
      const Money.zero(),
      (sum, item) => sum + item.allocatedAmount,
    );
  }

  /// التحقق من القيد المحاسبي الصارم:
  /// Total Income == Total Dedicated + Flexible Budget Remainder
  bool get isZeroSumValid {
    return (totalDedicatedAllocations + flexibleBudgetRemainder) == totalIncome;
  }
}

