import '../../../../core/finance/money.dart';
import '../entities/account_entity.dart';
import '../entities/audit_trail_entry.dart';
import '../entities/idempotency_record.dart';
import '../entities/transaction_entity.dart';

/// العقد المجرد لمستودع المحرك المالي (Financial Engine Repository Interface)
abstract class FinancialEngineRepository {
  // ── عمليات الحسابات ─────────────────────────────────────────
  Future<AccountEntity?> getAccountById(String id);
  Future<List<AccountEntity>> getAllActiveAccounts();
  Future<void> updateAccountBalance(String id, Money newBalance);

  // ── عمليات المعاملات ─────────────────────────────────────────
  Future<void> saveTransaction(TransactionEntity transaction);
  Future<TransactionEntity?> getTransactionById(String id);
  Future<void> updateTransactionStatus(String id, TransactionStatus status);

  // ── منع تكرار العمليات (Idempotency) ─────────────────────────
  Future<bool> hasIdempotencyKey(String key);
  Future<IdempotencyRecord?> getIdempotencyRecord(String key);
  Future<void> saveIdempotencyRecord(IdempotencyRecord record);

  // ── السجل والرقابة المحاسبية (Audit Trail) ───────────────────
  Future<void> recordAuditEntry(AuditTrailEntry entry);
  Future<List<AuditTrailEntry>> getAuditTrailForTransaction(String transactionId);
  Future<List<AuditTrailEntry>> getAuditTrailForEntity(String entityType, String entityId);

  // ── صندوق الطوارئ ───────────────────────────────────────────
  Future<Money> getEmergencyFundBalance();
  Future<void> updateEmergencyFundBalance(Money newBalance);

  // ── الأهداف المالية ──────────────────────────────────────────
  Future<Money> getGoalSavedAmount(String goalId);
  Future<void> updateGoalSavedAmount(String goalId, Money newAmount);
  Future<Money> getTotalActiveGoalsSaved();

  // ── الالتزامات والاشتراكات ────────────────────────────────────
  Future<Money> getTotalLockedObligations();
  Future<Money> getDueObligationsAmount();

  // ── الديون والأصول ───────────────────────────────────────────
  Future<Money> getTotalRemainingDebts();
  Future<void> applyDebtPayment(String debtId, Money amount);
  Future<Money> getTotalAssetsMarketValue();

  // ── الميزانيات والتصنيفات ────────────────────────────────────
  Future<void> recordExpenseAgainstBudget({
    required String? categoryId,
    required Money amount,
    required DateTime date,
  });

  // ── المعاملات الذرية ─────────────────────────────────────────
  Future<T> runInTransaction<T>(Future<T> Function() action);
}

