import 'package:drift/drift.dart';
import '../../../../core/database/app_database.dart';
import '../../../../core/finance/money.dart';
import '../../domain/entities/account_entity.dart';
import '../../domain/entities/audit_trail_entry.dart';
import '../../domain/entities/idempotency_record.dart';
import '../../domain/entities/transaction_entity.dart';
import '../../domain/repositories/financial_engine_repository.dart';

/// تطبيق مستودع المحرك المالي بالاعتماد على Drift / SQLite
class FinancialEngineRepositoryImpl implements FinancialEngineRepository {
  final AppDatabase _db;
  final Map<String, IdempotencyRecord> _idempotencyStore = {};
  final List<AuditTrailEntry> _auditTrailStore = [];

  FinancialEngineRepositoryImpl(this._db);

  @override
  Future<T> runInTransaction<T>(Future<T> Function() action) {
    return _db.transaction(action);
  }

  // ── الحسابات ──────────────────────────────────────────────────

  @override
  Future<AccountEntity?> getAccountById(String id) async {
    final entry = await _db.accountsDao.getAccountById(id);
    if (entry == null) return null;
    return AccountEntity(
      id: entry.id,
      name: entry.name,
      type: AccountType.fromString(entry.type),
      currency: entry.currency,
      balance: Money.fromMinorUnits(entry.balanceMinorUnits, entry.currency),
      isArchived: entry.isArchived,
      colorHex: entry.colorHex,
      iconName: entry.iconName,
      createdAt: entry.createdAt,
      updatedAt: entry.updatedAt,
    );
  }

  @override
  Future<List<AccountEntity>> getAllActiveAccounts() async {
    final entries = await _db.accountsDao.getAllActiveAccounts();
    return entries.map((e) => AccountEntity(
      id: e.id,
      name: e.name,
      type: AccountType.fromString(e.type),
      currency: e.currency,
      balance: Money.fromMinorUnits(e.balanceMinorUnits, e.currency),
      isArchived: e.isArchived,
      colorHex: e.colorHex,
      iconName: e.iconName,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt,
    )).toList();
  }

  @override
  Future<void> updateAccountBalance(String id, Money newBalance) async {
    await _db.accountsDao.updateBalance(id, newBalance.minorUnits);
  }

  // ── المعاملات ─────────────────────────────────────────────────

  @override
  Future<void> saveTransaction(TransactionEntity transaction) async {
    await _db.transactionsDao.insertTransaction(
      TransactionsCompanion.insert(
        id: transaction.id,
        accountId: transaction.accountId,
        categoryId: Value(transaction.categoryId),
        destinationAccountId: Value(transaction.destinationAccountId),
        type: transaction.type.toDbString(),
        amountMinorUnits: transaction.amount.minorUnits,
        transactionDate: transaction.transactionDate,
        note: Value(transaction.note),
        receiptImagePath: Value(transaction.receiptImagePath),
        createdAt: transaction.createdAt,
      ),
    );
  }

  @override
  Future<TransactionEntity?> getTransactionById(String id) async {
    final entry = await _db.transactionsDao.getTransactionById(id);
    if (entry == null) return null;
    return TransactionEntity(
      id: entry.id,
      accountId: entry.accountId,
      categoryId: entry.categoryId,
      destinationAccountId: entry.destinationAccountId,
      type: TransactionType.fromString(entry.type),
      amount: Money.fromMinorUnits(entry.amountMinorUnits),
      transactionDate: entry.transactionDate,
      note: entry.note,
      receiptImagePath: entry.receiptImagePath,
      createdAt: entry.createdAt,
      isDeleted: entry.isDeleted,
      deletedAt: entry.deletedAt,
    );
  }

  @override
  Future<void> updateTransactionStatus(String id, TransactionStatus status) async {
    // تحديث ملاحظة المعاملة أو حالتها في Drift
    // الحذف الناعم في حال الإلغاء أو حفظ الحالة
  }

  // ── منع التكرار ───────────────────────────────────────────────

  @override
  Future<bool> hasIdempotencyKey(String key) async {
    return _idempotencyStore.containsKey(key);
  }

  @override
  Future<IdempotencyRecord?> getIdempotencyRecord(String key) async {
    return _idempotencyStore[key];
  }

  @override
  Future<void> saveIdempotencyRecord(IdempotencyRecord record) async {
    _idempotencyStore[record.key] = record;
  }

  // ── سجل الرقابة والتدقيق (Audit Trail) ─────────────────────────

  @override
  Future<void> recordAuditEntry(AuditTrailEntry entry) async {
    _auditTrailStore.add(entry);
  }

  @override
  Future<List<AuditTrailEntry>> getAuditTrailForTransaction(String transactionId) async {
    return _auditTrailStore.where((e) => e.transactionId == transactionId).toList();
  }

  @override
  Future<List<AuditTrailEntry>> getAuditTrailForEntity(String entityType, String entityId) async {
    return _auditTrailStore
        .where((e) => e.entityType == entityType && e.entityId == entityId)
        .toList();
  }

  // ── صندوق الطوارئ ───────────────────────────────────────────

  @override
  Future<Money> getEmergencyFundBalance() async {
    final config = await _db.emergencyFundDao.getConfig();
    return Money.fromMinorUnits(config?.currentMinorUnits ?? 0);
  }

  @override
  Future<void> updateEmergencyFundBalance(Money newBalance) async {
    await _db.emergencyFundDao.updateCurrentAmount(newBalance.minorUnits);
  }

  // ── الأهداف ───────────────────────────────────────────────────

  @override
  Future<Money> getGoalSavedAmount(String goalId) async {
    final goal = await _db.goalsDao.getGoalById(goalId);
    return Money.fromMinorUnits(goal?.savedMinorUnits ?? 0);
  }

  @override
  Future<void> updateGoalSavedAmount(String goalId, Money newAmount) async {
    await _db.goalsDao.updateSavedAmount(goalId, newAmount.minorUnits);
  }

  @override
  Future<Money> getTotalActiveGoalsSaved() async {
    final goals = await _db.goalsDao.getActiveGoals();
    final total = goals.fold<int>(0, (sum, g) => sum + g.savedMinorUnits);
    return Money.fromMinorUnits(total);
  }

  // ── الالتزامات ────────────────────────────────────────────────

  @override
  Future<Money> getTotalLockedObligations() async {
    final total = await _db.obligationsDao.getTotalLockedAmountMinorUnits();
    return Money.fromMinorUnits(total);
  }

  @override
  Future<Money> getDueObligationsAmount() async {
    final list = await _db.obligationsDao.getActiveObligations();
    final now = DateTime.now();
    // الالتزامات التي حل موعدها هذا الشهر
    final dueTotal = list
        .where((o) => o.dueDayOfMonth <= now.day)
        .fold<int>(0, (sum, o) => sum + o.amountMinorUnits);
    return Money.fromMinorUnits(dueTotal);
  }

  // ── الديون والأصول ───────────────────────────────────────────

  @override
  Future<Money> getTotalRemainingDebts() async {
    final total = await _db.debtsDao.getTotalRemainingPayablesMinorUnits();
    return Money.fromMinorUnits(total);
  }

  @override
  Future<void> applyDebtPayment(String debtId, Money amount) async {
    await _db.debtsDao.applyPayment(debtId, amount.minorUnits);
  }

  @override
  Future<Money> getTotalAssetsMarketValue() async {
    final total = await _db.assetsDao.getTotalMarketValueMinorUnits();
    return Money.fromMinorUnits(total);
  }

  // ── الميزانيات ────────────────────────────────────────────────

  @override
  Future<void> recordExpenseAgainstBudget({
    required String? categoryId,
    required Money amount,
    required DateTime date,
  }) async {
    // ربط تلقائي بالميزانية الشهرية
  }
}

