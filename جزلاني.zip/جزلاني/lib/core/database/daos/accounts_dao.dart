import 'package:drift/drift.dart';
import '../app_database.dart';

part 'accounts_dao.g.dart';

/// DAO الحسابات والمحافظ — عمليات CRUD الآمنة
@DriftAccessor(tables: [Accounts])
class AccountsDao extends DatabaseAccessor<AppDatabase>
    with _$AccountsDaoMixin {
  AccountsDao(super.db);

  // ── قراءة ────────────────────────────────
  /// جميع الحسابات النشطة غير المؤرشفة
  Stream<List<AccountEntry>> watchActiveAccounts() =>
      (select(accounts)..where((a) => a.isArchived.equals(false)))
          .watch();

  /// جميع الحسابات النشطة (غير المؤرشفة) كقائمة
  Future<List<AccountEntry>> getAllActiveAccounts() =>
      (select(accounts)..where((a) => a.isArchived.equals(false))).get();

  /// جميع الحسابات بما فيها المؤرشفة (للنسخ الاحتياطي)
  Future<List<AccountEntry>> getAllAccounts() => select(accounts).get();

  /// حساب واحد بالمعرّف
  Future<AccountEntry?> getAccountById(String id) =>
      (select(accounts)..where((a) => a.id.equals(id))).getSingleOrNull();

  /// مجموع الأرصدة الكلي (بوحدة Minor Units)
  Future<int> getTotalBalanceMinorUnits() async {
    final query = selectOnly(accounts)
      ..addColumns([accounts.balanceMinorUnits.sum()])
      ..where(accounts.isArchived.equals(false));
    final result = await query.getSingle();
    return result.read(accounts.balanceMinorUnits.sum()) ?? 0;
  }

  // ── كتابة ────────────────────────────────
  Future<void> insertAccount(AccountsCompanion entry) =>
      into(accounts).insert(entry);

  Future<bool> updateAccount(AccountsCompanion entry) =>
      update(accounts).replace(entry);

  /// أرشفة الحساب بدلاً من حذفه (Soft Archive)
  Future<void> archiveAccount(String id) =>
      (update(accounts)..where((a) => a.id.equals(id))).write(
        AccountsCompanion(
          isArchived: const Value(true),
          updatedAt: Value(DateTime.now()),
        ),
      );

  /// تحديث الرصيد بشكل مباشر (يُستخدم فقط داخل المعاملات الذرية)
  Future<void> updateBalance(String id, int newBalanceMinorUnits) =>
      (update(accounts)..where((a) => a.id.equals(id))).write(
        AccountsCompanion(
          balanceMinorUnits: Value(newBalanceMinorUnits),
          updatedAt: Value(DateTime.now()),
        ),
      );
}

