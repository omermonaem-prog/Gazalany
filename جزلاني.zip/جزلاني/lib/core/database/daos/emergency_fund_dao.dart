import 'package:drift/drift.dart';
import '../app_database.dart';

part 'emergency_fund_dao.g.dart';

/// DAO صندوق الطوارئ — معزول عن الإنفاق العادي بالكامل
@DriftAccessor(tables: [EmergencyFundConfig, EmergencyWithdrawals])
class EmergencyFundDao extends DatabaseAccessor<AppDatabase>
    with _$EmergencyFundDaoMixin {
  EmergencyFundDao(super.db);

  // ── الإعدادات ─────────────────────────────
  Future<EmergencyFundConfigEntry?> getConfig() =>
      (select(emergencyFundConfig)
            ..where((c) => c.id.equals('primary_fund')))
          .getSingleOrNull();

  Stream<EmergencyFundConfigEntry?> watchConfig() =>
      (select(emergencyFundConfig)
            ..where((c) => c.id.equals('primary_fund')))
          .watchSingleOrNull();

  Future<void> upsertConfig(EmergencyFundConfigCompanion entry) =>
      into(emergencyFundConfig).insertOnConflictUpdate(entry);

  /// ضبط رصيد الصندوق بقيمة مطلقة
  Future<void> updateCurrentAmount(int currentMinorUnits) =>
      (update(emergencyFundConfig)
            ..where((c) => c.id.equals('primary_fund')))
          .write(
        EmergencyFundConfigCompanion(
          currentMinorUnits: Value(currentMinorUnits),
        ),
      );

  /// إضافة مبلغ للصندوق — يُستدعى داخل معاملة ذرية فقط
  Future<void> addToFund(int amountMinorUnits) async {
    final config = await getConfig();
    if (config == null) return;
    await (update(emergencyFundConfig)
          ..where((c) => c.id.equals('primary_fund')))
        .write(
      EmergencyFundConfigCompanion(
        currentMinorUnits:
            Value(config.currentMinorUnits + amountMinorUnits),
      ),
    );
  }

  /// سحب من الصندوق — يتطلب سبباً إلزامياً ويُسجَّل دائماً في سجل السحوبات
  Future<void> withdrawFromFund({
    required String withdrawalId,
    required int amountMinorUnits,
    required String reason,
    String? compensationPlanNotes,
  }) async {
    final config = await getConfig();
    if (config == null) throw StateError('صندوق الطوارئ غير مهيأ');
    if (amountMinorUnits > config.currentMinorUnits) {
      throw ArgumentError('المبلغ المطلوب يتجاوز رصيد صندوق الطوارئ');
    }

    await (update(emergencyFundConfig)
          ..where((c) => c.id.equals('primary_fund')))
        .write(
      EmergencyFundConfigCompanion(
        currentMinorUnits:
            Value(config.currentMinorUnits - amountMinorUnits),
        lastWithdrawalDate: Value(DateTime.now()),
        compensationPlanActive: Value(compensationPlanNotes != null),
      ),
    );

    await into(emergencyWithdrawals).insert(
      EmergencyWithdrawalsCompanion(
        id: Value(withdrawalId),
        amountMinorUnits: Value(amountMinorUnits),
        reason: Value(reason),
        compensationPlanNotes: Value(compensationPlanNotes),
        createdAt: Value(DateTime.now()),
      ),
    );
  }

  Future<List<EmergencyWithdrawalEntry>> getWithdrawalHistory() =>
      (select(emergencyWithdrawals)
            ..orderBy([(w) => OrderingTerm.desc(w.createdAt)]))
          .get();
}

