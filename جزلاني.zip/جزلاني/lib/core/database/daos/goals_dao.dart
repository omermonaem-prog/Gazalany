import 'package:drift/drift.dart';
import '../app_database.dart';

part 'goals_dao.g.dart';

/// DAO الأهداف المالية
@DriftAccessor(tables: [Goals])
class GoalsDao extends DatabaseAccessor<AppDatabase> with _$GoalsDaoMixin {
  GoalsDao(super.db);

  Stream<List<GoalEntry>> watchActiveGoals() =>
      (select(goals)..where((g) => g.status.equals('active'))).watch();

  Future<List<GoalEntry>> getActiveGoals() =>
      (select(goals)..where((g) => g.status.equals('active'))).get();

  /// ضبط المبلغ المدخر بقيمة مطلقة
  Future<void> updateSavedAmount(String id, int savedMinorUnits) =>
      (update(goals)..where((g) => g.id.equals(id))).write(
        GoalsCompanion(savedMinorUnits: Value(savedMinorUnits)),
      );

  Future<GoalEntry?> getGoalById(String id) =>
      (select(goals)..where((g) => g.id.equals(id))).getSingleOrNull();

  Future<void> insertGoal(GoalsCompanion entry) =>
      into(goals).insert(entry);

  /// تحديث المبلغ المدخر — يُستدعى فقط داخل معاملة ذرية
  Future<void> addToSaved(String id, int addedMinorUnits) async {
    final goal = await getGoalById(id);
    if (goal == null) return;
    final newSaved = goal.savedMinorUnits + addedMinorUnits;
    await (update(goals)..where((g) => g.id.equals(id))).write(
      GoalsCompanion(savedMinorUnits: Value(newSaved)),
    );
  }

  /// تحديث حالة الهدف (paused / achieved / purchased)
  Future<void> updateGoalStatus(String id, String status) =>
      (update(goals)..where((g) => g.id.equals(id))).write(
        GoalsCompanion(status: Value(status)),
      );
}

