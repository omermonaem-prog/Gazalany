import 'package:drift/drift.dart';
import '../app_database.dart';

part 'debts_dao.g.dart';

/// DAO الديون والأقساط — يدعم سجل دفعات كامل بدون حذف
@DriftAccessor(tables: [Debts, DebtPayments])
class DebtsDao extends DatabaseAccessor<AppDatabase> with _$DebtsDaoMixin {
  DebtsDao(super.db);

  // ── الديون ───────────────────────────────
  Stream<List<DebtEntry>> watchActiveDebts() =>
      (select(debts)..where((d) => d.status.equals('active'))).watch();

  /// مجموع المتبقي من الديون المستحقة علينا (payable) النشطة
  Future<int> getTotalRemainingPayablesMinorUnits() async {
    final query = selectOnly(debts)
      ..addColumns([debts.remainingMinorUnits.sum()])
      ..where(debts.type.equals('payable') & debts.status.equals('active'));
    final result = await query.getSingle();
    return result.read(debts.remainingMinorUnits.sum()) ?? 0;
  }

  Future<DebtEntry?> getDebtById(String id) =>
      (select(debts)..where((d) => d.id.equals(id))).getSingleOrNull();

  Future<void> insertDebt(DebtsCompanion entry) =>
      into(debts).insert(entry);

  /// تخفيض الرصيد المتبقي بعد كل دفعة — يُستدعى داخل معاملة ذرية
  Future<void> applyPayment(String debtId, int paidMinorUnits) async {
    final debt = await getDebtById(debtId);
    if (debt == null) return;
    final newRemaining = (debt.remainingMinorUnits - paidMinorUnits)
        .clamp(0, debt.totalMinorUnits);
    final newStatus = newRemaining == 0 ? 'settled' : 'active';
    await (update(debts)..where((d) => d.id.equals(debtId))).write(
      DebtsCompanion(
        remainingMinorUnits: Value(newRemaining),
        status: Value(newStatus),
      ),
    );
  }

  // ── دفعات الديون ─────────────────────────
  Future<List<DebtPaymentEntry>> getPaymentsForDebt(String debtId) =>
      (select(debtPayments)
            ..where((p) => p.debtId.equals(debtId))
            ..orderBy([(p) => OrderingTerm.desc(p.paymentDate)]))
          .get();

  Future<void> insertDebtPayment(DebtPaymentsCompanion entry) =>
      into(debtPayments).insert(entry);

  /// مجموع المبالغ المسددة لدين معيّن
  Future<int> getTotalPaidMinorUnits(String debtId) async {
    final query = selectOnly(debtPayments)
      ..addColumns([debtPayments.amountMinorUnits.sum()])
      ..where(debtPayments.debtId.equals(debtId));
    final result = await query.getSingle();
    return result.read(debtPayments.amountMinorUnits.sum()) ?? 0;
  }
}

