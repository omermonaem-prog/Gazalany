import 'package:drift/drift.dart';
import '../app_database.dart';

part 'obligations_dao.g.dart';

/// DAO الالتزامات والفواتير المتكررة
@DriftAccessor(tables: [Obligations])
class ObligationsDao extends DatabaseAccessor<AppDatabase>
    with _$ObligationsDaoMixin {
  ObligationsDao(super.db);

  Stream<List<ObligationEntry>> watchActiveObligations() =>
      (select(obligations)..where((o) => o.isActive.equals(true))).watch();

  Future<List<ObligationEntry>> getActiveObligations() =>
      (select(obligations)..where((o) => o.isActive.equals(true))).get();

  /// اسم بديل متوافق مع مستودع المحرك المالي
  Future<int> getTotalLockedAmountMinorUnits() =>
      getTotalLockedObligationsMinorUnits();

  Future<void> insertObligation(ObligationsCompanion entry) =>
      into(obligations).insert(entry);

  Future<void> deactivateObligation(String id) =>
      (update(obligations)..where((o) => o.id.equals(id))).write(
        const ObligationsCompanion(isActive: Value(false)),
      );

  /// مجموع الالتزامات الشهرية المحجوزة من الراتب
  Future<int> getTotalLockedObligationsMinorUnits() async {
    final query = selectOnly(obligations)
      ..addColumns([obligations.amountMinorUnits.sum()])
      ..where(obligations.isActive.equals(true) &
          obligations.isLockedFromSalary.equals(true) &
          obligations.recurrenceType.equals('monthly'));
    final result = await query.getSingle();
    return result.read(obligations.amountMinorUnits.sum()) ?? 0;
  }
}

