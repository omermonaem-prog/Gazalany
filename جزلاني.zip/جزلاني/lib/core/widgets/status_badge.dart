import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';

/// نوع شارة الحالة
enum StatusBadgeType { success, warning, danger, neutral }

/// شارة حالة مالية (Status Badge)
class StatusBadge extends StatelessWidget {
  final String text;
  final StatusBadgeType? type;
  final Color? color;
  final Color? textColor;

  /// يمكن تمرير النص عبر `text` أو `label`
  const StatusBadge({
    super.key,
    String? text,
    String? label,
    this.type,
    this.color,
    this.textColor,
  }) : text = text ?? label ?? '';

  Color _typeForeground() {
    switch (type) {
      case StatusBadgeType.success:
        return AppColors.cashIn;
      case StatusBadgeType.warning:
        return AppColors.warningAmber;
      case StatusBadgeType.danger:
        return AppColors.criticalRed;
      case StatusBadgeType.neutral:
        return AppColors.slateMuted;
      case null:
        return AppColors.forestGreen;
    }
  }

  @override
  Widget build(BuildContext context) {
    final fg = textColor ?? _typeForeground();
    final bg = color ??
        (type == null
            ? AppColors.surfaceSubtleLight
            : fg.withValues(alpha: 0.12));

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: fg.withValues(alpha: 0.2), width: 0.8),
      ),
      child: Text(
        text,
        style: AppTypography.bodySecondary.copyWith(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: fg,
        ),
      ),
    );
  }
}
