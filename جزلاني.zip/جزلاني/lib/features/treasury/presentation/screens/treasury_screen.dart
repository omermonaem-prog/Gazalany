import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../application/treasury_controller.dart';
import 'package:my_finance/features/treasury/domain/entities/treasury_snapshot.dart';
import '../presentation/widgets/internal_transfer_dialog.dart';
import '../presentation/widgets/treasury_metric_card.dart';
import 'closed_months_history_screen.dart';
import 'month_end_closing_screen.dart';

/// شاشة الخزينة الموحدة والمحافظ (Unified Treasury & Vaults Screen)
class TreasuryScreen extends ConsumerWidget {
  const TreasuryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(treasuryControllerProvider);
    final controller = ref.read(treasuryControllerProvider.notifier);
    final snapshot = state.snapshot;

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('الخزينة الموحدة'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.history, color: AppColors.forestGreen),
            tooltip: 'أرشيف الأشهر المغلقة',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ClosedMonthsHistoryScreen(),
                ),
              );
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadTreasuryData(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. بطاقة إجمالي الأموال (Hero Card) - مفصولة كلياً عن السيولة
              if (snapshot != null) _buildHeroTotalFundsCard(snapshot),
              const SizedBox(height: 16),

              // 2. شبكة المؤشرات الأربعة (السيولة، الادخار، الطوارئ، الأهداف)
              if (snapshot != null) _buildMetricsGrid(snapshot),
              const SizedBox(height: 20),

              // 3. أزرار الإجراءات السريعة (تحويل داخلي، إغلاق الشهر)
              Row(
                children: [
                  Expanded(
                    child: LuxuryButton(
                      label: 'تحويل داخلي',
                      icon: Icons.swap_horiz,
                      type: LuxuryButtonType.secondary,
                      onPressed: () {
                        if (snapshot?.accounts.isNotEmpty == true) {
                          showDialog(
                            context: context,
                            builder: (ctx) => InternalTransferDialog(
                              accounts: snapshot!.accounts,
                              onTransfer: controller.executeInternalTransfer,
                            ),
                          );
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: LuxuryButton(
                      label: 'إغلاق الشهر والفائض',
                      icon: Icons.lock_clock,
                      type: LuxuryButtonType.primary,
                      onPressed: () {
                        final now = DateTime.now();
                        final ym =
                            '${now.year}-${now.month.toString().padLeft(2, '0')}';
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                MonthEndClosingScreen(periodYearMonth: ym),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // 4. قائمة الحسابات والمحافظ المفصلة
              Text('المحافظ والحسابات البنكية', style: AppTypography.headingH2),
              const SizedBox(height: 12),

              if (state.isLoading)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(30),
                    child: CircularProgressIndicator(color: AppColors.forestGreen),
                  ),
                )
              else if (snapshot == null || snapshot.accounts.isEmpty)
                _buildEmptyAccounts()
              else
                ...snapshot.accounts.map((acc) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: LuxuryCard(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: AppColors.forestGreen.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(
                                Icons.account_balance,
                                color: AppColors.forestGreen,
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    acc.name,
                                    style: AppTypography.headingH3.copyWith(
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  Text(
                                    acc.type.name.toUpperCase(),
                                    style: AppTypography.bodySecondary.copyWith(
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              acc.balance.formatArabic(),
                              style: AppTypography.headingH2.copyWith(
                                fontWeight: FontWeight.w700,
                                color: AppColors.forestGreen,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeroTotalFundsCard(TreasurySnapshot snapshot) {
    return LuxuryCard(
      backgroundColor: AppColors.forestGreen,
      borderColor: AppColors.champagneGold,
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'إجمالي الأموال في كافة الحسابات',
                style: AppTypography.bodySecondary.copyWith(
                  color: AppColors.canvasLight.withValues(alpha: 0.8),
                ),
              ),
              const Icon(Icons.shield, color: AppColors.champagneGold, size: 20),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            snapshot.totalFunds.formatArabic(),
            style: AppTypography.displayLarge.copyWith(
              color: AppColors.champagneGoldBright,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'ملاحظة: يشمل كافة الأرصدة البنكية، النقدية، الطوارئ، والادخار.',
            style: AppTypography.bodySecondary.copyWith(
              color: AppColors.canvasLight.withValues(alpha: 0.6),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricsGrid(TreasurySnapshot snapshot) {
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.35,
      children: [
        TreasuryMetricCard(
          title: 'السيولة المتاحة',
          amount: snapshot.availableLiquidity,
          icon: Icons.water_drop,
          color: AppColors.cashIn,
          subtitle: 'حر ومتاح للإنفاق',
        ),
        TreasuryMetricCard(
          title: 'صندوق الطوارئ',
          amount: snapshot.emergencyFund,
          icon: Icons.shield_outlined,
          color: AppColors.criticalRed,
          subtitle: 'معزول للأزمات',
        ),
        TreasuryMetricCard(
          title: 'الادخار العام',
          amount: snapshot.generalSavings,
          icon: Icons.savings_outlined,
          color: AppColors.champagneGold,
          subtitle: 'استثماري تراكمي',
        ),
        TreasuryMetricCard(
          title: 'محجوز للأهداف',
          amount: snapshot.goalsLocked,
          icon: Icons.flag_outlined,
          color: AppColors.forestGreenLight,
          subtitle: 'أهداف ادخارية نشطة',
        ),
      ],
    );
  }

  Widget _buildEmptyAccounts() {
    return LuxuryCard(
      padding: const EdgeInsets.symmetric(vertical: 30),
      child: Center(
        child: Column(
          children: [
            const Icon(Icons.account_balance_wallet_outlined, size: 40, color: AppColors.slateMuted),
            const SizedBox(height: 10),
            Text('لا توجد حسابات مسجلة', style: AppTypography.headingH3),
          ],
        ),
      ),
    );
  }
}

