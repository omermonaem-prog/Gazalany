# MyFinance — المعمارية البرمجية والهندسة التقنية (SOFTWARE_ARCHITECTURE)

## 1. النمط المعماري العام (Clean Architecture & Feature-First)
يعتمد MyFinance معمارية نظيفة مجزأة حسب الميزات (Feature-First Clean Architecture)، تضمن فصلاً كاملاً للمسؤوليات، إمكانية اختبار شاملة (Testability)، واستقلالية تامة للمنطق التجاري والمالي عن واجهات العرض ومكتبات الأجهزة.

```
lib/
├── core/                        # النواة المشتركة
│   ├── database/                # تهيئة SQLite / Drift / SQLCipher
│   ├── security/                # التشفير المحلي، البصمة، وتأمين المفاتيح
│   ├── error/                   # استثناءات النظام والتعامل مع الإخفاقات
│   ├── theme/                   # توكنز نظام التصميم، الخطوط والألوان
│   ├── utils/                   # العمليات الرياضية العشرية والتاريخ العربي
│   └── widgets/                 # المكونات العامة الفاخرة المشتركة
│
├── features/                    # الأنظمة الاثنا عشر
│   ├── 01_dashboard/
│   ├── 02_treasury/
│   ├── 03_income_allocation/
│   ├── 04_expenses/
│   ├── 05_budgets/
│   ├── 06_obligations/
│   ├── 07_emergency_fund/
│   ├── 08_goals/
│   ├── 09_debts/
│   ├── 10_assets_networth/
│   ├── 11_analytics_reports/
│   └── 12_settings_backup/
```

---

## 2. تفصيل الطبقات داخل كل ميزة (Layer Responsibilities)

### 1. طبقة العرض (Presentation Layer)
- **Widgets & Pages:** واجهات المستخدم المكتوبة بمكونات `shadcn_flutter` مع تخصيصات الهوية الفاخرة، داعمة لـ RTL محلياً.
- **State Management (BLoC / Cubit):**
  - استقبال أحداث المستخدم (`Events`).
  - التواصل مع حالات الاستخدام (`Use Cases`).
  - بث الحالات المنظمة (`Initial, Loading, Loaded, Error, ActionSuccess`).
  - معالجة واجهات التأكيد والرسائل التفاعلية دون كتابة أي منطق تجاري داخل الـ Widget.

### 2. طبقة النطاق والمنطق التجاري (Domain Layer)
- **Entities:** كائنات العمل النقية المحمية التي تحتوي على النماذج المالية والخصائص الثابتة.
- **Use Cases (Interactors):**
  - كل عملية مالية تمثل Use Case مستقل (مثال: `ExecuteIncomeAllocationUseCase`, `ProcessEmergencyWithdrawalUseCase`, `CalculateNetWorthUseCase`).
  - تطبيق القواعد والتحققات الرياضية الصارمة قبل استدعاء مستودعات البيانات.
- **Repository Contracts (Interfaces):** عقود مجردة تحدد ما تطلبه طبقة النطاق دون معرفة تفاصيل التخزين.

### 3. طبقة البيانات (Data Layer)
- **Models (DTOs):** نماذج تحويل البيانات بين كيانات النطاق وسجلات قاعدة البيانات.
- **Data Sources (Local DB / SQLCipher):**
  - تنفيذ الاستعلامات عبر Drift ORM المشفر بمكتبة SQLCipher.
  - ضمان تنفيذ العمليات المالية المركبة داخل معاملات ذرية (`Database.transaction(() async { ... })`).
- **Repositories Implementation:** تنفيذ العقود المحددة في طبقة النطاق وإرجاع إما `Right(Data)` أو `Left(Failure)` عبر نمط النتيجة الوظيفية (`fpdart` أو `dartz`).

---

## 3. محرك العمليات الذرية والنزاهة المالية (Atomic Financial Transactions)
- أي عملية تنطوي على أكثر من قيد (مثل: توزيع الراتب على 4 بنود، أو سداد قسط دين يخصم من محفظة ويقلل رصيد الدين ويسجل دفعة) تُنفذ ضمن **Atomic Transaction واحدة**.
- إذا فشلت أي خطوة جزئية أو حدث إغلاق مفاجئ للتطبيق، يقوم محرك قاعدة البيانات بعمل `ROLLBACK` تلقائي، مما يمنع نهائياً فقدان أو تشتت الأموال أو عدم اتساق الأرصدة.

---

## 4. تدفق البيانات والأمان المحلي (Data Flow & Security Architecture)
1. **التحقق البيومتري الفوري:** يتم فك تشفير مفتاح قاعدة البيانات المخزن في Android KeyStore عبر المصادقة البيومترية للمستخدم.
2. **التخزين المشفر:** قاعدة بيانات SQLite مشفرة بخوارزمية AES-256 عبر SQLCipher.
3. **انعدام الاتصال الخارجي (Zero External Calls):** لا يوجد أي كود يستدعي خوادم سحابية، والتقارير والنسخ الاحتياطية يتم توليدها محلياً في ذاكرة التخزين الداخلية للجهاز.

