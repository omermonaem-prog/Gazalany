# MyFinance — مخطط قاعدة البيانات والبيانات المحلية (DATABASE_PLAN)

## 1. مواصفات المحرك المحلي (محدَّث: المرحلة 04)
- **المحرك:** SQLite بدون تشفير في المرحلة الحالية (Phase 04) — تشفير SQLCipher يُضاف في المرحلة 12.
- **طبقة التجريد (ORM):** `drift: ^2.20.0` مع `drift_dev: ^2.20.0` و `build_runner: ^2.4.12` لتوليد الكود.
- **تنسيق القيم النقدية:** `Int64Column` — أعداد صحيحة 64-bit بوحدة الهللة/السنت (Minor Units). مثال: 1250.75 ر.س = 125075 وحدة. **يُمنع تماماً استخدام `RealColumn` للمبالغ المالية.**
- **كود التوليد:** يُشغَّل عبر `flutter pub run build_runner build --delete-conflicting-outputs` عند توفر Flutter SDK.
- **التفعيل الإلزامي:** `PRAGMA foreign_keys = ON` في `beforeOpen` لتطبيق قيود المفاتيح الخارجية.

## 1.1 قرارات التنفيذ المعتمدة (Phase 04 ADRs)
- **ADR-DB-01:** اعتماد `Int64Column` بدلاً من `RealColumn` لكل المبالغ المالية.
- **ADR-DB-02:** محرك المعاملات الذرية `FinancialTransactionEngine` يلفّ جميع العمليات متعددة الجداول في `db.transaction()` لضمان Rollback التلقائي.
- **ADR-DB-03:** الحذف الناعم إلزامي للمعاملات (`is_deleted + deleted_at`) — لا حذف فيزيائي لأي سجل مالي.
- **ADR-DB-04:** `schemaVersion: 1` مع `onUpgrade` جاهز لإضافة Migrations مستقبلية دون فقدان بيانات.
- **ADR-DB-05:** كل DAO ينفّذ `DatabaseAccessor` مستقل — الفصل بين الوصول للبيانات وطبقة النطاق.

---

## 2. جداول النظام والعلاقات (Schema Definition)

### 1. جدول الحسابات والمحافظ (`accounts`)
```sql
CREATE TABLE accounts (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL,
    type TEXT NOT NULL, -- 'bank', 'cash', 'e_wallet', 'vault'
    currency TEXT NOT NULL DEFAULT 'SAR',
    balance_minor_units INTEGER NOT NULL DEFAULT 0,
    is_archived INTEGER NOT NULL DEFAULT 0,
    color_hex TEXT NOT NULL,
    icon_name TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);
```

### 2. جدول التصنيفات والميزانيات (`categories` & `budgets`)
```sql
CREATE TABLE categories (
    id TEXT PRIMARY KEY NOT NULL,
    parent_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    icon_name TEXT NOT NULL,
    color_hex TEXT NOT NULL,
    is_income INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);

CREATE TABLE budgets (
    id TEXT PRIMARY KEY NOT NULL,
    category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    period_year_month TEXT NOT NULL, -- '2026-10'
    allocated_minor_units INTEGER NOT NULL,
    warning_threshold_percent INTEGER NOT NULL DEFAULT 80,
    created_at INTEGER NOT NULL,
    UNIQUE(category_id, period_year_month)
);
```

### 3. جدول المعاملات والقيود المالية (`transactions`)
```sql
CREATE TABLE transactions (
    id TEXT PRIMARY KEY NOT NULL,
    account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
    category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
    destination_account_id TEXT REFERENCES accounts(id) ON DELETE SET NULL, -- للتحويلات الداخلية
    type TEXT NOT NULL, -- 'expense', 'income', 'transfer', 'reconciliation'
    amount_minor_units INTEGER NOT NULL,
    transaction_date INTEGER NOT NULL,
    note TEXT,
    receipt_image_path TEXT,
    is_deleted INTEGER NOT NULL DEFAULT 0, -- Soft Delete
    deleted_at INTEGER,
    created_at INTEGER NOT NULL
);
```

### 4. جدول قواعد توزيع الدخل والراتب (`income_allocation_rules`)
```sql
CREATE TABLE income_allocation_rules (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    target_type TEXT NOT NULL, -- 'emergency_fund', 'goal', 'obligation', 'budget'
    target_id TEXT NOT NULL,
    allocation_mode TEXT NOT NULL, -- 'percentage', 'fixed_amount'
    value_numeric REAL NOT NULL,
    priority_order INTEGER NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1
);
```

### 5. جدول الالتزامات والاشتراكات المتكررة (`obligations`)
```sql
CREATE TABLE obligations (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    biller_name TEXT,
    amount_minor_units INTEGER NOT NULL,
    recurrence_type TEXT NOT NULL, -- 'monthly', 'quarterly', 'yearly', 'weekly'
    due_day_of_month INTEGER NOT NULL,
    linked_account_id TEXT REFERENCES accounts(id) ON DELETE SET NULL,
    is_locked_from_salary INTEGER NOT NULL DEFAULT 1,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL
);
```

### 6. جدول صندوق الطوارئ وسجلات السحب (`emergency_fund` & `emergency_logs`)
```sql
CREATE TABLE emergency_fund_config (
    id TEXT PRIMARY KEY NOT NULL DEFAULT 'primary_fund',
    target_minor_units INTEGER NOT NULL,
    current_minor_units INTEGER NOT NULL DEFAULT 0,
    target_months_coverage INTEGER NOT NULL DEFAULT 3,
    last_withdrawal_date INTEGER,
    compensation_plan_active INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE emergency_withdrawals (
    id TEXT PRIMARY KEY NOT NULL,
    amount_minor_units INTEGER NOT NULL,
    reason TEXT NOT NULL,
    compensation_plan_notes TEXT,
    created_at INTEGER NOT NULL
);
```

### 7. جدول الأهداف المالية وتخصيصاتها (`goals`)
```sql
CREATE TABLE goals (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    target_minor_units INTEGER NOT NULL,
    saved_minor_units INTEGER NOT NULL DEFAULT 0,
    target_date INTEGER,
    status TEXT NOT NULL DEFAULT 'active', -- 'active', 'achieved', 'purchased', 'paused'
    icon_name TEXT NOT NULL,
    color_hex TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
```

### 8. جدول الديون والأقساط (`debts` & `debt_installments`)
```sql
CREATE TABLE debts (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    counterparty_name TEXT NOT NULL, -- الشخص أو البنك المقرض/المقترض
    type TEXT NOT NULL, -- 'payable' (عليّ), 'receivable' (لي)
    total_minor_units INTEGER NOT NULL,
    remaining_minor_units INTEGER NOT NULL,
    monthly_installment_minor_units INTEGER,
    start_date INTEGER NOT NULL,
    due_date INTEGER,
    status TEXT NOT NULL DEFAULT 'active' -- 'active', 'settled'
);

CREATE TABLE debt_payments (
    id TEXT PRIMARY KEY NOT NULL,
    debt_id TEXT NOT NULL REFERENCES debts(id) ON DELETE CASCADE,
    account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
    amount_minor_units INTEGER NOT NULL,
    payment_date INTEGER NOT NULL,
    note TEXT
);
```

### 9. جدول الأصول الرأسمالية (`assets`)
```sql
CREATE TABLE assets (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL, -- 'real_estate', 'vehicle', 'gold', 'stocks', 'other'
    purchase_cost_minor_units INTEGER NOT NULL,
    current_market_value_minor_units INTEGER NOT NULL,
    purchase_date INTEGER NOT NULL,
    last_valuation_date INTEGER NOT NULL,
    notes TEXT
);
```

---

## 3. الفهارس ومحفزات النزاهة (Indices & Constraints)
- **فهارس الأداء السريع:**
  ```sql
  CREATE INDEX idx_transactions_account ON transactions(account_id);
  CREATE INDEX idx_transactions_date ON transactions(transaction_date);
  CREATE INDEX idx_transactions_category ON transactions(category_id);
  CREATE INDEX idx_budgets_period ON budgets(period_year_month);
  CREATE INDEX idx_debts_status ON debts(status);
  ```
- **محفزات النزاهة (Triggers):**
  - تحديث `remaining_minor_units` في جدول `debts` تلقائياً عند إضافة سجل في `debt_payments`.
  - تحديث `saved_minor_units` في جدول `goals` عند تخصيص مبالغ للهدف.

