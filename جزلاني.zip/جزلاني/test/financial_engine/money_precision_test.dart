import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/core/finance/financial_exceptions.dart';
import 'package:my_finance/core/finance/money.dart';

void main() {
  group('Money — الدقة الرياضية والنزاهة المحاسبية', () {
    test('إنشاء كائن Money بوحدات الهللة والوحدات الكبرى بدقة متناهية', () {
      final m1 = Money.fromMinorUnits(125075);
      expect(m1.minorUnits, equals(125075));
      expect(m1.toMajorUnits(), equals(1250.75));

      final m2 = Money.fromMajorUnits(1250.75);
      expect(m2.minorUnits, equals(125075));
      expect(m1, equals(m2));
    });

    test('منع أخطاء الأعداد العشرية العائمة (No Floating Point Error)', () {
      // المشكلة المشهورة في Float: 0.1 + 0.2 = 0.30000000000000004
      // في Money: 10 هللات + 20 هللة = 30 هللة تماماً!
      final tenHalalas = Money.fromMinorUnits(10);
      final twentyHalalas = Money.fromMinorUnits(20);
      final thirtyHalalas = tenHalalas + twentyHalalas;

      expect(thirtyHalalas.minorUnits, equals(30));
      expect(thirtyHalalas, equals(Money.fromMinorUnits(30)));
    });

    test('العمليات الحسابية الأساسية: الجمع، الطرح، الضرب بعدد صحيح، القيمة المطلقة', () {
      final a = Money.fromMajorUnits(100.00);
      final b = Money.fromMajorUnits(45.50);

      final sum = a + b;
      expect(sum.minorUnits, equals(14550));
      expect(sum.formatArabic(), equals('145.50 ر.س'));

      final diff = a - b;
      expect(diff.minorUnits, equals(5450));
      expect(diff.formatArabic(), equals('54.50 ر.س'));

      final multiplied = b * 3;
      expect(multiplied.minorUnits, equals(13650));

      final negative = -a;
      expect(negative.isNegative, isTrue);
      expect(negative.abs(), equals(a));
    });

    test('رفض جمع أو مقارنة عملات مختلفة دون تحويل صريح (Currency Mismatch)', () {
      final sar = Money.fromMajorUnits(100, 'SAR');
      final usd = Money.fromMajorUnits(100, 'USD');

      expect(
        () => sar + usd,
        throwsA(isA<CurrencyMismatchException>()),
      );
      expect(
        () => sar < usd,
        throwsA(isA<CurrencyMismatchException>()),
      );
    });

    test('خوارزمية التوزيع الصفري العادل (Largest Remainder Method) على مبالغ فردية', () {
      // سيناريو رقمي: توزيع 100 ر.س (10000 هللة) بالتساوي على 3 أقسام
      // في الحساب العادي: 100 / 3 = 33.333333... (مجموع 33.33 * 3 = 99.99 هللة، وتضيع هللة واحدة!)
      // مع Largest Remainder: 33.34 + 33.33 + 33.33 = 100.00 بالضبط دون فقدان أي هللة!
      final hundredSar = Money.fromMajorUnits(100.00);
      final shares = Money.apportion(hundredSar, [1, 1, 1]);

      expect(shares.length, equals(3));
      expect(shares[0].minorUnits, equals(3334)); // 33.34 ر.س
      expect(shares[1].minorUnits, equals(3333)); // 33.33 ر.س
      expect(shares[2].minorUnits, equals(3333)); // 33.33 ر.س

      // التحقق الرياضي الحاسم: المجموع = 10000 هللة بالتمام والكمال
      final sumOfShares = shares.fold<Money>(
        const Money.zero(),
        (sum, m) => sum + m,
      );
      expect(sumOfShares, equals(hundredSar));
    });

    test('توزيع بنسب مئوية معقدة مع ضمان ثبات المجموع (Zero-Sum Conservation)', () {
      // سيناريو: راتب 13,755.80 ر.س مقسم بنسب: 45.5%، 25.25%، 20.0%، 9.25% (مجموعها 100%)
      final salary = Money.fromMajorUnits(13755.80);
      final percentages = [45.5, 25.25, 20.0, 9.25];

      final parts = Money.apportionByPercentages(salary, percentages);

      expect(parts.length, equals(4));
      final totalApportioned = parts.fold<Money>(
        const Money.zero(),
        (sum, p) => sum + p,
      );

      // شرط النزاهة المحاسبية الصارم: لا زيادة ولا نقصان هللة واحدة
      expect(totalApportioned, equals(salary));
    });

    test('التنسيق النصي العربي والإنجليزي مع فواصل الآلاف', () {
      final bigAmount = Money.fromMinorUnits(123456789); // 1,234,567.89 SAR
      expect(bigAmount.formatArabic(), equals('1,234,567.89 ر.س'));
      expect(bigAmount.formatEnglish(), equals('SAR 1,234,567.89'));

      final zero = const Money.zero();
      expect(zero.formatArabic(), equals('0.00 ر.س'));
      expect(zero.isZero, isTrue);
    });
  });
}

