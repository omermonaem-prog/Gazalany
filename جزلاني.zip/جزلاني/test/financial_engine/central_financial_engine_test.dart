import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/core/finance/financial_exceptions.dart';
import 'package:my_finance/core/finance/money.dart';
import 'package:my_finance/features/financial_engine/application/central_financial_engine.dart';
import 'package:my_finance/features/financial_engine/data/repositories/in_memory_financial_engine_repository.dart';
import 'package:my_finance/features/financial_engine/domain/entities/account_entity.dart';
import 'package:my_finance/features/financial_engine/domain/entities/allocation_plan.dart';
import 'package:my_finance/features/financial_engine/domain/entities/transaction_entity.dart';

void main() {
  late InMemoryFinancialEngineRepository repo;
  late CentralFinancialEngine engine;

  setUp(() {
    repo = InMemoryFinancialEngineRepository();
    engine = CentralFinancialEngine(repository: repo);
  });

  AccountEntity createTestAccount({
    required String id,
    required String name,
    required Money balance,
    bool isArchived = false,
  }) {
    return AccountEntity(
      id: id,
      name: name,
      type: AccountType.bank,
      currency: 'SAR',
      balance: balance,
      isArchived: isArchived,
      colorHex: '#0E3B2E',
      iconName: 'landmark',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  // ════════════════════════════════════════════════════════════════
  // 1. اختبارات المصروفات والدخل (Expenses & Incomes)
  // ════════════════════════════════════════════════════════════════
  group('1. اختبارات تسجيل المصروفات والدخل', () {
    test('تسجيل مصروف: يخصم بدقة من رصيد الحساب ويوثق في سجل التدقيق', () async {
      repo.accounts['acc-1'] = createTestAccount(
        id: 'acc-1',
        name: 'الراجحي',
        balance: Money.fromMajorUnits(1000.00),
      );

      final txn = await engine.recordExpense(
        transactionId: 'exp-1',
        accountId: 'acc-1',
        categoryId: 'cat-groceries',
        amount: Money.fromMajorUnits(250.50),
        date: DateTime.now(),
        note: 'مشتريات غذائية',
        idempotencyKey: 'idemp-exp-1',
      );

      expect(txn.amount.minorUnits, equals(25050));
      final updatedAcc = repo.accounts['acc-1']!;
      expect(updatedAcc.balance, equals(Money.fromMajorUnits(749.50)));

      // التحقق من إنشاء قيد التدقيق المحاسبي السليم
      final audit = repo.auditTrail.firstWhere((a) => a.transactionId == 'exp-1');
      expect(audit.isMathValid, isTrue);
      expect(audit.balanceBefore, equals(Money.fromMajorUnits(1000.00)));
      expect(audit.delta, equals(Money.fromMajorUnits(-250.50)));
      expect(audit.balanceAfter, equals(Money.fromMajorUnits(749.50)));
    });

    test('فشل المصروف عند عدم كفاية الرصيد (Insufficient Funds)', () async {
      repo.accounts['acc-poor'] = createTestAccount(
        id: 'acc-poor',
        name: 'كاش',
        balance: Money.fromMajorUnits(50.00),
      );

      expect(
        () => engine.recordExpense(
          transactionId: 'exp-fail',
          accountId: 'acc-poor',
          categoryId: null,
          amount: Money.fromMajorUnits(100.00),
          date: DateTime.now(),
          idempotencyKey: 'idemp-poor-1',
        ),
        throwsA(isA<InsufficientFundsException>()),
      );

      // التأكد من عدم المساس بالرصيد
      expect(repo.accounts['acc-poor']!.balance, equals(Money.fromMajorUnits(50.00)));
    });

    test('رفض المبالغ الصفرية أو السالبة للمصروف والدخل', () async {
      repo.accounts['acc-1'] = createTestAccount(
        id: 'acc-1',
        name: 'الحساب',
        balance: Money.fromMajorUnits(500.00),
      );

      expect(
        () => engine.recordExpense(
          transactionId: 'e-zero',
          accountId: 'acc-1',
          categoryId: null,
          amount: const Money.zero(),
          date: DateTime.now(),
          idempotencyKey: 'key-zero',
        ),
        throwsA(isA<ArgumentError>()),
      );

      expect(
        () => engine.recordIncome(
          transactionId: 'i-negative',
          accountId: 'acc-1',
          categoryId: null,
          amount: Money.fromMajorUnits(-100.00),
          date: DateTime.now(),
          idempotencyKey: 'key-neg',
        ),
        throwsA(isA<ArgumentError>()),
      );
    });

    test('تسجيل الدخل: يرفع رصيد الحساب بدقة متناهية', () async {
      repo.accounts['acc-salary'] = createTestAccount(
        id: 'acc-salary',
        name: 'الأهلي',
        balance: Money.fromMajorUnits(2000.00),
      );

      await engine.recordIncome(
        transactionId: 'inc-1',
        accountId: 'acc-salary',
        categoryId: 'cat-freelance',
        amount: Money.fromMajorUnits(1500.25),
        date: DateTime.now(),
        note: 'مكافأة عمل مستقل',
        idempotencyKey: 'idemp-inc-1',
      );

      expect(repo.accounts['acc-salary']!.balance, equals(Money.fromMajorUnits(3500.25)));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 2. اختبارات التحويلات بين الأقسام والحسابات (Internal Transfers)
  // ════════════════════════════════════════════════════════════════
  group('2. اختبارات التحويلات الداخلية وثبات إجمالي الأموال', () {
    test('القيد المحاسبي الصارم: التحويل الداخلي لا يغير إجمالي الأموال (ΔSrc + ΔDst = 0)', () async {
      repo.accounts['acc-src'] = createTestAccount(
        id: 'acc-src',
        name: 'حساب الإنفاق',
        balance: Money.fromMajorUnits(5000.00),
      );
      repo.accounts['acc-dst'] = createTestAccount(
        id: 'acc-dst',
        name: 'الخزينة الاحتياطية',
        balance: Money.fromMajorUnits(2000.00),
      );

      final totalBefore = await engine.getTotalFunds();
      expect(totalBefore, equals(Money.fromMajorUnits(7000.00)));

      // تنفيذ تحويل 1,500.00 ر.س
      await engine.transfer(
        transactionId: 'trx-1',
        fromAccountId: 'acc-src',
        toAccountId: 'acc-dst',
        amount: Money.fromMajorUnits(1500.00),
        date: DateTime.now(),
        idempotencyKey: 'idemp-trx-1',
      );

      // الأرصدة الفردية
      expect(repo.accounts['acc-src']!.balance, equals(Money.fromMajorUnits(3500.00)));
      expect(repo.accounts['acc-dst']!.balance, equals(Money.fromMajorUnits(3500.00)));

      // إجمالي الأموال بعد التحويل ثابت تماماً!
      final totalAfter = await engine.getTotalFunds();
      expect(totalAfter, equals(totalBefore));
    });

    test('منع التحويل الداخلي من الحساب وإلى نفسه', () async {
      repo.accounts['acc-same'] = createTestAccount(
        id: 'acc-same',
        name: 'حساب وحيد',
        balance: Money.fromMajorUnits(1000.00),
      );

      expect(
        () => engine.transfer(
          transactionId: 'trx-same',
          fromAccountId: 'acc-same',
          toAccountId: 'acc-same',
          amount: Money.fromMajorUnits(100.00),
          date: DateTime.now(),
          idempotencyKey: 'idemp-same',
        ),
        throwsA(isA<ArgumentError>()),
      );
    });

    test('منع التحويل في حالة الحساب المؤرشف', () async {
      repo.accounts['acc-archived'] = createTestAccount(
        id: 'acc-archived',
        name: 'حساب قديم',
        balance: Money.fromMajorUnits(1000.00),
        isArchived: true,
      );
      repo.accounts['acc-active'] = createTestAccount(
        id: 'acc-active',
        name: 'حساب نشط',
        balance: Money.fromMajorUnits(500.00),
      );

      expect(
        () => engine.transfer(
          transactionId: 'trx-arch',
          fromAccountId: 'acc-archived',
          toAccountId: 'acc-active',
          amount: Money.fromMajorUnits(100.00),
          date: DateTime.now(),
          idempotencyKey: 'idemp-arch',
        ),
        throwsA(isA<AccountArchivedException>()),
      );
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 3. اختبارات تخصيص الأموال للأهداف (Goal Allocation)
  // ════════════════════════════════════════════════════════════════
  group('3. اختبارات تخصيص الأموال للأهداف المالية', () {
    test('قاعدة محاسبية ملزمة: تخصيص المال للهدف لا يسجل كمصروف، وينقص السيولة المتاحة فقط', () async {
      repo.accounts['acc-main'] = createTestAccount(
        id: 'acc-main',
        name: 'الحساب الرئيسي',
        balance: Money.fromMajorUnits(10000.00),
      );
      repo.goalBalances['goal-car'] = Money.fromMajorUnits(2000.00);

      // السيولة المتاحة قبل التخصيص
      final liquidityBefore = await engine.getAvailableLiquidity();
      expect(liquidityBefore, equals(Money.fromMajorUnits(8000.00))); // 10000 - 2000

      // تخصيص 3,000 ر.س للهدف
      final txn = await engine.allocateToGoal(
        transactionId: 'goal-alloc-1',
        fromAccountId: 'acc-main',
        goalId: 'goal-car',
        amount: Money.fromMajorUnits(3000.00),
        date: DateTime.now(),
        idempotencyKey: 'idemp-goal-1',
      );

      // التأكد أن المعاملة سُجلت كـ goalAllocation وليست expense!
      expect(txn.type, equals(TransactionType.goalAllocation));

      // رصيد الهدف أصبح 5,000 ر.س
      expect(repo.goalBalances['goal-car'], equals(Money.fromMajorUnits(5000.00)));

      // رصيد الحساب تناقص بمقدار 3,000 المحجوزة
      expect(repo.accounts['acc-main']!.balance, equals(Money.fromMajorUnits(7000.00)));

      // السيولة المتاحة تناقصت من 8,000 إلى 2,000
      final liquidityAfter = await engine.getAvailableLiquidity();
      expect(liquidityAfter, equals(Money.fromMajorUnits(2000.00))); // 7000 - 5000
    });

    test('استرداد/سحب مخصصات من الهدف يعيد الأموال فورياً للسيولة المتاحة', () async {
      repo.accounts['acc-main'] = createTestAccount(
        id: 'acc-main',
        name: 'الحساب الرئيسي',
        balance: Money.fromMajorUnits(5000.00),
      );
      repo.goalBalances['goal-travel'] = Money.fromMajorUnits(4000.00);

      await engine.deallocateFromGoal(
        transactionId: 'goal-dealloc-1',
        toAccountId: 'acc-main',
        goalId: 'goal-travel',
        amount: Money.fromMajorUnits(1500.00),
        date: DateTime.now(),
        idempotencyKey: 'idemp-goal-dealloc',
      );

      expect(repo.goalBalances['goal-travel'], equals(Money.fromMajorUnits(2500.00)));
      expect(repo.accounts['acc-main']!.balance, equals(Money.fromMajorUnits(6500.00)));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 4. اختبارات توزيع الدخل والتقريب والنسب (Income Allocation)
  // ════════════════════════════════════════════════════════════════
  group('4. اختبارات محرك توزيع الدخل والراتب والقيد الصفري', () {
    test('قيد ملزم: رفض توزيع الدخل دون تأكيد صريح (Preview & Confirm Invariant)', () async {
      repo.accounts['acc-salary'] = createTestAccount(
        id: 'acc-salary',
        name: 'حساب الراتب',
        balance: Money.fromMajorUnits(0.00),
      );

      final plan = engine.previewIncomeAllocation(
        planId: 'plan-unconfirmed',
        title: 'راتب أكتوبر',
        totalIncome: Money.fromMajorUnits(10000.00),
        items: [
          const AllocationPlanItem(
            id: 'item-ef',
            title: 'صندوق الطوارئ',
            targetType: AllocationTargetType.emergencyFund,
            targetId: 'primary_fund',
            mode: AllocationMode.percentage,
            percentage: 20.0,
          ),
        ],
      );

      // الخطة تنشأ غير مؤكدة تلقائياً
      expect(plan.isConfirmed, isFalse);

      // محاولة التنفيذ مباشرة دون تأكيد يجب أن تُرمى باستثناء صريح
      expect(
        () => engine.executeIncomeAllocation(
          plan: plan,
          depositAccountId: 'acc-salary',
          idempotencyKey: 'idemp-unconf',
        ),
        throwsA(isA<UnconfirmedAllocationException>()),
      );
    });

    test('توزيع الدخل بدقة الهللة وإثبات القيد الصفري (Zero-Sum Invariant)', () async {
      repo.accounts['acc-salary'] = createTestAccount(
        id: 'acc-salary',
        name: 'حساب الراتب',
        balance: const Money.zero(),
      );

      // راتب قدره 12,500.75 ر.س
      final salary = Money.fromMajorUnits(12500.75);

      final unconfirmedPlan = engine.previewIncomeAllocation(
        planId: 'salary-oct-2026',
        title: 'راتب شهر أكتوبر',
        totalIncome: salary,
        items: [
          const AllocationPlanItem(
            id: 'ef-share',
            title: 'تعزيز صندوق الطوارئ',
            targetType: AllocationTargetType.emergencyFund,
            targetId: 'primary_fund',
            mode: AllocationMode.percentage,
            percentage: 20.0, // 20%
          ),
          const AllocationPlanItem(
            id: 'goal-share',
            title: 'هدف دفعة أولى للمنزل',
            targetType: AllocationTargetType.goal,
            targetId: 'goal-house',
            mode: AllocationMode.percentage,
            percentage: 30.0, // 30%
          ),
          AllocationPlanItem(
            id: 'fixed-bill',
            title: 'فاتورة قسط ثابتة',
            targetType: AllocationTargetType.obligation,
            targetId: 'bill-1',
            mode: AllocationMode.fixedAmount,
            fixedAmount: Money.fromMajorUnits(1500.00), // 1500 ر.س
          ),
        ],
      );

      // تأكيد الخطة من المستخدم
      final confirmedPlan = unconfirmedPlan.copyWith(isConfirmed: true);

      final result = await engine.executeIncomeAllocation(
        plan: confirmedPlan,
        depositAccountId: 'acc-salary',
        idempotencyKey: 'salary-exec-1',
      );

      // 1. التحقق من القيد الصفري: مجموع المخصصات + المتبقي المرن = إجمالي الدخل تماماً
      expect(result.isZeroSumValid, isTrue);
      final totalDistributed = result.totalDedicatedAllocations + result.flexibleBudgetRemainder;
      expect(totalDistributed, equals(salary));

      // 2. التحقق من تغذية صندوق الطوارئ
      expect(repo.emergencyFundBalance.minorUnits, greaterThan(0));

      // 3. التحقق من تغذية الهدف
      expect(repo.goalBalances['goal-house']!.minorUnits, greaterThan(0));

      // 4. الرصيد في الحساب يساوي المتبقي المرن
      final finalAccountBalance = repo.accounts['acc-salary']!.balance;
      expect(finalAccountBalance, equals(result.flexibleBudgetRemainder));
    });

    test('رفض خطة توزيع تتجاوز نسبها 100% أو مبالغها الثابتة تفوق الدخل', () {
      expect(
        () => engine.previewIncomeAllocation(
          planId: 'plan-invalid',
          title: 'خطة غير صالحة',
          totalIncome: Money.fromMajorUnits(1000.00),
          items: [
            const AllocationPlanItem(
              id: '1',
              title: 'تخصيص 1',
              targetType: AllocationTargetType.emergencyFund,
              targetId: 'ef',
              mode: AllocationMode.percentage,
              percentage: 70.0,
            ),
            const AllocationPlanItem(
              id: '2',
              title: 'تخصيص 2',
              targetType: AllocationTargetType.goal,
              targetId: 'g',
              mode: AllocationMode.percentage,
              percentage: 40.0, // مجموع = 110%
            ),
          ],
        ),
        throwsA(isA<InvalidAllocationException>()),
      );
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 5. اختبارات عكس وتصحيح العمليات (Reversal & Correction)
  // ════════════════════════════════════════════════════════════════
  group('5. اختبارات عكس وتصحيح العمليات دون حذف التاريخ', () {
    test('عكس المصروف: يعيد المبلغ للحساب ويحدث حالة المعاملة الأصلية دون حذفها', () async {
      repo.accounts['acc-main'] = createTestAccount(
        id: 'acc-main',
        name: 'الحساب',
        balance: Money.fromMajorUnits(1000.00),
      );

      // تسجيل مصروف 300 ر.س
      await engine.recordExpense(
        transactionId: 'exp-to-reverse',
        accountId: 'acc-main',
        categoryId: null,
        amount: Money.fromMajorUnits(300.00),
        date: DateTime.now(),
        idempotencyKey: 'idemp-exp-rev',
      );
      expect(repo.accounts['acc-main']!.balance, equals(Money.fromMajorUnits(700.00)));

      // عكس المصروف
      final revTxn = await engine.reverseTransaction(
        originalTransactionId: 'exp-to-reverse',
        reversalTransactionId: 'rev-exp-1',
        reason: 'خطأ في إدخال المبلغ',
        idempotencyKey: 'idemp-rev-1',
      );

      // تم إعادة الرصيد للحساب كما كان (1000.00 ر.س)
      expect(repo.accounts['acc-main']!.balance, equals(Money.fromMajorUnits(1000.00)));

      // المعاملة الأصلية ما زالت موجودة في السجل وحالتها reversed!
      final originalTxn = repo.transactions['exp-to-reverse']!;
      expect(originalTxn.status, equals(TransactionStatus.reversed));

      // المعاملة العكسية مسجلة ومرتبطة بالأصلية
      expect(revTxn.relatedTransactionId, equals('exp-to-reverse'));
      expect(revTxn.type, equals(TransactionType.reversal));
    });

    test('منع عكس المعاملة المعكوسة مرتين (No Double Reversals)', () async {
      repo.accounts['acc-1'] = createTestAccount(
        id: 'acc-1',
        name: 'الحساب',
        balance: Money.fromMajorUnits(500.00),
      );
      await engine.recordExpense(
        transactionId: 'exp-double',
        accountId: 'acc-1',
        categoryId: null,
        amount: Money.fromMajorUnits(100.00),
        date: DateTime.now(),
        idempotencyKey: 'key-exp-double',
      );

      // العكس الأول: ينجح
      await engine.reverseTransaction(
        originalTransactionId: 'exp-double',
        reversalTransactionId: 'rev-first',
        reason: 'إلغاء',
        idempotencyKey: 'key-rev-first',
      );

      // العكس الثاني لنفس المعاملة: يجب أن يفشل حتماً
      expect(
        () => engine.reverseTransaction(
          originalTransactionId: 'exp-double',
          reversalTransactionId: 'rev-second',
          reason: 'إلغاء مكرر',
          idempotencyKey: 'key-rev-second',
        ),
        throwsA(isA<TransactionAlreadyReversedException>()),
      );
    });

    test('تصحيح المعاملة: يعكس المعاملة القديمة ويثبت المصححة مع ربط الأثر', () async {
      repo.accounts['acc-corr'] = createTestAccount(
        id: 'acc-corr',
        name: 'الحساب',
        balance: Money.fromMajorUnits(1000.00),
      );

      // خطأ في الإدخال: تسجيل 800 ر.س بدلاً من 80 ر.س
      await engine.recordExpense(
        transactionId: 'txn-wrong',
        accountId: 'acc-corr',
        categoryId: null,
        amount: Money.fromMajorUnits(800.00),
        date: DateTime.now(),
        idempotencyKey: 'key-wrong',
      );
      expect(repo.accounts['acc-corr']!.balance, equals(Money.fromMajorUnits(200.00)));

      // تصحيح المبلغ إلى 80 ر.س
      final corrected = TransactionEntity(
        id: 'txn-corrected',
        accountId: 'acc-corr',
        type: TransactionType.expense,
        amount: Money.fromMajorUnits(80.00),
        transactionDate: DateTime.now(),
        note: 'المبلغ الصحيح 80',
        createdAt: DateTime.now(),
      );

      await engine.correctTransaction(
        originalTransactionId: 'txn-wrong',
        reversalTransactionId: 'rev-wrong',
        correctedTransaction: corrected,
        reason: 'تصحيح صفر زائد',
        idempotencyKey: 'key-corr-exec',
      );

      // الرصيد بعد العكس ثم خصم المبلغ المصحح:
      // بعد العكس رجع 1000.00 ثم خصم 80 المصححة = 920.00 ر.س
      expect(repo.accounts['acc-corr']!.balance, equals(Money.fromMajorUnits(920.00)));
      expect(repo.transactions['txn-wrong']!.status, equals(TransactionStatus.reversed));
      expect(repo.transactions['txn-corrected']!.status, equals(TransactionStatus.corrected));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 6. اختبارات منع التكرار (Idempotency Protection)
  // ════════════════════════════════════════════════════════════════
  group('6. اختبارات منع تكرار العمليات (Idempotency)', () {
    test('منع احتساب العملية مرتين عند إعادة المحاولة بنفس المفتاح', () async {
      repo.accounts['acc-dup'] = createTestAccount(
        id: 'acc-dup',
        name: 'الحساب',
        balance: Money.fromMajorUnits(1000.00),
      );

      const idempKey = 'unique-network-request-uuid-123';

      // المحاولة الأولى: تنجح وتخصم 200 ر.س
      await engine.recordExpense(
        transactionId: 'exp-dup-1',
        accountId: 'acc-dup',
        categoryId: null,
        amount: Money.fromMajorUnits(200.00),
        date: DateTime.now(),
        idempotencyKey: idempKey,
      );
      expect(repo.accounts['acc-dup']!.balance, equals(Money.fromMajorUnits(800.00)));

      // المحاولة الثانية (إعادة إرسال نفس الطلب بسبب بطء الشبكة مثلاً):
      expect(
        () => engine.recordExpense(
          transactionId: 'exp-dup-1-retry',
          accountId: 'acc-dup',
          categoryId: null,
          amount: Money.fromMajorUnits(200.00),
          date: DateTime.now(),
          idempotencyKey: idempKey,
        ),
        throwsA(isA<DuplicateTransactionException>()),
      );

      // النتيجة الحاسمة: الرصيد لم يُخصم مرتين أبداً!
      expect(repo.accounts['acc-dup']!.balance, equals(Money.fromMajorUnits(800.00)));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 7. اختبارات فشل العمليات في منتصف التنفيذ والتراجع الذري (Atomic Rollback)
  // ════════════════════════════════════════════════════════════════
  group('7. اختبارات التراجع الذري التام عند حدوث خطأ مفاجئ', () {
    test('إذا فشلت العملية في المنتصف، تعود كافة الأرصدة لسابق عهدها دون أي تشوه (Rollback)', () async {
      repo.accounts['acc-rollback'] = createTestAccount(
        id: 'acc-rollback',
        name: 'حساب الاختبار',
        balance: Money.fromMajorUnits(1000.00),
      );

      // محاكاة عملية مركبة متعددة الخطوات تتعطل في الخطوة الأخيرة
      try {
        await repo.runInTransaction(() async {
          // خطوة 1: تعديل رصيد الحساب
          await repo.updateAccountBalance('acc-rollback', Money.fromMajorUnits(200.00));
          // خطوة 2: تعديل صندوق الطوارئ
          await repo.updateEmergencyFundBalance(Money.fromMajorUnits(500.00));
          // خطوة 3: حدوث عطل غير متوقع أو انقطاع مفاجئ!
          throw StateError('خطأ غير متوقع أثناء حفظ القيد المالي!');
        });
      } catch (e) {
        // توقعنا الخطأ
      }

      // التحقق الحاسم: التراجع الذري التام (Atomic Rollback)
      // رصيد الحساب لم يتأثر
      expect(repo.accounts['acc-rollback']!.balance, equals(Money.fromMajorUnits(1000.00)));
      // صندوق الطوارئ لم يتأثر
      expect(repo.emergencyFundBalance, equals(const Money.zero()));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 8. الفرق الجوهري بين السيولة وإجمالي الأموال وحساب صافي الثروة
  // ════════════════════════════════════════════════════════════════
  group('8. اختبارات الفرق بين السيولة وإجمالي الأموال وصافي الثروة', () {
    test('عزل الطوارئ والأهداف والالتزامات عن السيولة المتاحة، وحساب صافي الثروة الدقيق', () async {
      // 1. حسابات ومحافظ بإجمالي 50,000 ر.س
      repo.accounts['bank-1'] = createTestAccount(
        id: 'bank-1',
        name: 'بنك الراجحي',
        balance: Money.fromMajorUnits(30000.00),
      );
      repo.accounts['bank-2'] = createTestAccount(
        id: 'bank-2',
        name: 'بنك الأهلي',
        balance: Money.fromMajorUnits(20000.00),
      );

      // 2. محجوزات معزولة
      repo.emergencyFundBalance = Money.fromMajorUnits(15000.00); // 15,000 طوارئ معزولة
      repo.goalBalances['goal-1'] = Money.fromMajorUnits(10000.00); // 10,000 أهداف محجوزة
      repo.lockedObligations = Money.fromMajorUnits(5000.00); // 5,000 التزامات محجوزة

      // 3. أصول وديون
      repo.assetsMarketValue = Money.fromMajorUnits(120000.00); // أصول (سيارة + ذهب)
      repo.remainingDebts = Money.fromMajorUnits(40000.00); // ديون متبقية
      repo.dueObligations = Money.fromMajorUnits(2000.00); // فواتير مستحقة فوراً

      final snapshot = await engine.getLiquiditySnapshot();

      // أ) إجمالي الأموال = 30,000 + 20,000 = 50,000 ر.س
      expect(snapshot.totalFunds, equals(Money.fromMajorUnits(50000.00)));

      // ب) إجمالي المحجوزات = 15,000 + 10,000 + 5,000 = 30,000 ر.س
      expect(snapshot.totalLockedFunds, equals(Money.fromMajorUnits(30000.00)));

      // ج) السيولة المتاحة للإنفاق الفعلي = 50,000 - 30,000 = 20,000 ر.س فقط!
      expect(snapshot.availableLiquidity, equals(Money.fromMajorUnits(20000.00)));

      // د) صافي الثروة = (50,000 أموال + 120,000 أصول) - (40,000 ديون + 2,000 مستحقات)
      // 170,000 - 42,000 = 128,000 ر.س
      expect(snapshot.netWorth, equals(Money.fromMajorUnits(128000.00)));
    });
  });
}
