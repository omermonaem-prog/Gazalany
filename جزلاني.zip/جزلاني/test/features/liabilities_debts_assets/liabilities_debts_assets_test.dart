import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/core/finance/money.dart';
import 'package:my_finance/features/financial_engine/application/central_financial_engine.dart';
import 'package:my_finance/features/financial_engine/data/repositories/in_memory_financial_engine_repository.dart';
import 'package:my_finance/features/financial_engine/domain/entities/account_entity.dart';
import 'package:my_finance/features/financial_engine/domain/entities/transaction_entity.dart';
import 'package:my_finance/features/liabilities_debts_assets/application/liabilities_debts_assets_controller.dart';
import 'package:my_finance/features/liabilities_debts_assets/data/repositories/in_memory_liabilities_debts_assets_repository.dart';
import 'package:my_finance/features/liabilities_debts_assets/domain/entities/asset_entity.dart';
import 'package:my_finance/features/liabilities_debts_assets/domain/entities/debt_entity.dart';
import 'package:my_finance/features/liabilities_debts_assets/domain/entities/obligation_entity.dart';

void main() {
  late InMemoryFinancialEngineRepository engineRepo;
  late CentralFinancialEngine engine;
  late InMemoryLiabilitiesDebtsAssetsRepository repository;
  late LiabilitiesDebtsAssetsController controller;

  setUp(() {
    engineRepo = InMemoryFinancialEngineRepository();
    engine = CentralFinancialEngine(repository: engineRepo);
    repository = InMemoryLiabilitiesDebtsAssetsRepository();

    // حساب جاري برصيد 50,000 ر.س
    engineRepo.accounts['acc_main'] = AccountEntity(
      id: 'acc_main',
      name: 'الحساب الجاري الرئيسي',
      type: AccountType.bank,
      currency: 'SAR',
      balance: Money.fromMajorUnits(50000.00),
      colorHex: '#0E3B2E',
      iconName: 'landmark',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    controller = LiabilitiesDebtsAssetsController(
      repository: repository,
      engine: engine,
    );
  });

  // ════════════════════════════════════════════════════════════════
  // 1. اختبارات الالتزامات والفواتير المتكررة (Obligations)
  // ════════════════════════════════════════════════════════════════
  group('1. اختبارات الالتزامات والاشتراكات', () {
    test('إنشاء التزام شهري وتوثيق بياناته وموعد استحقاقه', () async {
      final success = await controller.createObligation(
        title: 'فاتورة الكهرباء',
        billerName: 'شركة الكهرباء السعودية',
        amount: Money.fromMajorUnits(450.00),
        recurrenceType: ObligationRecurrence.monthly,
        dueDayOfMonth: 28,
        isLockedFromSalary: true,
      );

      expect(success, isTrue);
      expect(controller.state.obligations.length, equals(1));

      final ob = controller.state.obligations.first;
      expect(ob.title, equals('فاتورة الكهرباء'));
      expect(ob.amount, equals(Money.fromMajorUnits(450.00)));
      expect(ob.recurrenceType, equals(ObligationRecurrence.monthly));
      expect(ob.dueDayOfMonth, equals(28));
      expect(ob.isActive, isTrue);
    });

    test('سداد التزام مالي يخصم من الحساب البنكي ويسجل كمصروف ويوثق في سجل السداد', () async {
      await controller.createObligation(
        title: 'إيجار شهري',
        amount: Money.fromMajorUnits(3000.00),
        recurrenceType: ObligationRecurrence.monthly,
      );
      final ob = controller.state.obligations.first;

      final paySuccess = await controller.payObligation(
        obligationId: ob.id,
        accountId: 'acc_main',
        amount: Money.fromMajorUnits(3000.00),
        paymentDate: DateTime.now(),
        notes: 'سداد إيجار شهر أكتوبر',
        idempotencyKey: 'idemp_pay_rent_1',
      );

      expect(paySuccess, isTrue);

      // التأكد أن رصيد الحساب نقص من 50,000 إلى 47,000
      final acc = await engineRepo.getAccountById('acc_main');
      expect(acc?.balance, equals(Money.fromMajorUnits(47000.00)));

      // التأكد من توثيق المعاملة كمصروف (وليس كتحويل داخلي)
      final txns = engineRepo.transactions.values.toList();
      expect(txns.any((t) => t.type == TransactionType.expense), isTrue);

      // التأكد من توثيق الدفعة في سجل دفعات الالتزام
      expect(controller.state.obligationPayments.length, equals(1));
      expect(controller.state.obligationPayments.first.obligationTitle, equals('إيجار شهري'));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 2. اختبارات الديون والأقساط (Debts & Installments)
  // ════════════════════════════════════════════════════════════════
  group('2. اختبارات الديون وسداد الأقساط', () {
    test('تسجيل دين مستحق على المستخدم (دين عليّ - التزام)', () async {
      final success = await controller.createDebt(
        title: 'قرض سيارة',
        counterpartyName: 'بنك الراجحي',
        type: DebtType.payable,
        totalAmount: Money.fromMajorUnits(60000.00),
        monthlyInstallmentAmount: Money.fromMajorUnits(1500.00),
        startDate: DateTime.now(),
      );

      expect(success, isTrue);
      expect(controller.state.debts.length, equals(1));

      final debt = controller.state.debts.first;
      expect(debt.title, equals('قرض سيارة'));
      expect(debt.remainingAmount, equals(Money.fromMajorUnits(60000.00)));
      expect(debt.paidAmount, equals(const Money.zero()));
      expect(debt.status, equals(DebtStatus.active));
      expect(debt.progressPercentage, equals(0.0));
    });

    test('سداد قسط من الدين يخصم من الحساب ويخفض المتبقي بدقة رياضية', () async {
      await controller.createDebt(
        title: 'تمويل شخصي',
        counterpartyName: 'البنك الأهلي',
        type: DebtType.payable,
        totalAmount: Money.fromMajorUnits(10000.00),
        monthlyInstallmentAmount: Money.fromMajorUnits(2000.00),
        startDate: DateTime.now(),
      );
      final debt = controller.state.debts.first;

      final paySuccess = await controller.payDebtInstallment(
        debtId: debt.id,
        accountId: 'acc_main',
        amount: Money.fromMajorUnits(2000.00),
        paymentDate: DateTime.now(),
        idempotencyKey: 'idemp_debt_inst_1',
      );

      expect(paySuccess, isTrue);

      final updatedDebt = controller.state.debts.first;
      expect(updatedDebt.remainingAmount, equals(Money.fromMajorUnits(8000.00)));
      expect(updatedDebt.paidAmount, equals(Money.fromMajorUnits(2000.00)));
      expect(updatedDebt.progressPercentage, equals(20.0));

      // رصيد الحساب البنكي نقص 2000
      final acc = await engineRepo.getAccountById('acc_main');
      expect(acc?.balance, equals(Money.fromMajorUnits(48000.00)));
    });

    test('اكتمال سداد كامل الدين يحول حالته إلى settled تلقائياً', () async {
      await controller.createDebt(
        title: 'سلفة مؤقتة',
        counterpartyName: 'صديق',
        type: DebtType.payable,
        totalAmount: Money.fromMajorUnits(1000.00),
        startDate: DateTime.now(),
      );
      final debt = controller.state.debts.first;

      await controller.payDebtInstallment(
        debtId: debt.id,
        accountId: 'acc_main',
        amount: Money.fromMajorUnits(1000.00),
        paymentDate: DateTime.now(),
        idempotencyKey: 'idemp_debt_full_settle',
      );

      final updatedDebt = controller.state.debts.first;
      expect(updatedDebt.remainingAmount, equals(const Money.zero()));
      expect(updatedDebt.status, equals(DebtStatus.settled));
      expect(updatedDebt.isFullyPaid, isTrue);
    });

    test('تسجيل وتحصيل دين مستحق للمستخدم (دين لي - أصل متداول)', () async {
      await controller.createDebt(
        title: 'دين على زميل',
        counterpartyName: 'محمد أحمد',
        type: DebtType.receivable,
        totalAmount: Money.fromMajorUnits(5000.00),
        startDate: DateTime.now(),
      );

      expect(controller.state.totalReceivableDebtsRemaining, equals(Money.fromMajorUnits(5000.00)));

      // استلام دفعة من المدين بقيمة 2000
      final collectSuccess = await controller.payDebtInstallment(
        debtId: controller.state.debts.first.id,
        accountId: 'acc_main',
        amount: Money.fromMajorUnits(2000.00),
        paymentDate: DateTime.now(),
        idempotencyKey: 'idemp_collect_debt_1',
      );

      expect(collectSuccess, isTrue);

      // الحساب البنكي زاد رصيده بدخول المبلغ 2000 (دخل مالي)
      final acc = await engineRepo.getAccountById('acc_main');
      expect(acc?.balance, equals(Money.fromMajorUnits(52000.00)));

      final updatedDebt = controller.state.debts.first;
      expect(updatedDebt.remainingAmount, equals(Money.fromMajorUnits(3000.00)));
      expect(controller.state.totalReceivableDebtsRemaining, equals(Money.fromMajorUnits(3000.00)));
    });

    test('منع سداد مبلغ يتجاوز الرصيد المتبقي على الدين', () async {
      await controller.createDebt(
        title: 'دين بسيط',
        counterpartyName: 'خالد',
        type: DebtType.payable,
        totalAmount: Money.fromMajorUnits(500.00),
        startDate: DateTime.now(),
      );

      final failSuccess = await controller.payDebtInstallment(
        debtId: controller.state.debts.first.id,
        accountId: 'acc_main',
        amount: Money.fromMajorUnits(800.00),
        paymentDate: DateTime.now(),
        idempotencyKey: 'idemp_debt_excess',
      );

      expect(failSuccess, isFalse);
      expect(controller.state.errorMessage, contains('يتجاوز المبلغ المتبقي'));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 3. اختبارات الأصول الرأسمالية (Capital Assets)
  // ════════════════════════════════════════════════════════════════
  group('3. اختبارات الأصول وإعادة التقييم', () {
    test('تسجيل أصل رأسمالي وتوثيق التقييم الافتتاحي', () async {
      final success = await controller.createAsset(
        title: 'أرض سكنية شمال الرياض',
        category: AssetCategory.realEstate,
        purchaseCost: Money.fromMajorUnits(400000.00),
        currentMarketValue: Money.fromMajorUnits(400000.00),
        purchaseDate: DateTime(2024, 1, 15),
      );

      expect(success, isTrue);
      expect(controller.state.assets.length, equals(1));
      expect(controller.state.totalCapitalAssets, equals(Money.fromMajorUnits(400000.00)));

      // التأكد من توثيق التقييم الافتتاحي
      final history = await repository.getValuationHistoryForAsset(controller.state.assets.first.id);
      expect(history.length, equals(1));
      expect(history.first.marketValue, equals(Money.fromMajorUnits(400000.00)));
    });

    test('إعادة تقييم الأصل الرأسمالي مع الاحتفاظ بتاريخ التقييم السابق', () async {
      await controller.createAsset(
        title: 'سبائك ذهب',
        category: AssetCategory.gold,
        purchaseCost: Money.fromMajorUnits(20000.00),
        currentMarketValue: Money.fromMajorUnits(20000.00),
        purchaseDate: DateTime(2025, 1, 1),
      );
      final asset = controller.state.assets.first;

      // ارتفاع سعر الذهب إلى 26,000 ر.س
      final revalSuccess = await controller.revaluateAsset(
        assetId: asset.id,
        newMarketValue: Money.fromMajorUnits(26000.00),
        reason: 'ارتفاع أسعار أونصة الذهب عالمياً',
      );

      expect(revalSuccess, isTrue);

      final updatedAsset = controller.state.assets.first;
      expect(updatedAsset.currentMarketValue, equals(Money.fromMajorUnits(26000.00)));
      expect(updatedAsset.unrealizedGainLoss, equals(Money.fromMajorUnits(6000.00)));
      expect(updatedAsset.gainLossPercentage, equals(30.0));
      expect(updatedAsset.isGaining, isTrue);

      // التأكد من وجود سجل التقييمين (السابق والجديد)
      final history = await repository.getValuationHistoryForAsset(asset.id);
      expect(history.length, equals(2));
      expect(history.last.previousMarketValue, equals(Money.fromMajorUnits(20000.00)));
      expect(history.last.marketValue, equals(Money.fromMajorUnits(26000.00)));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 4. اختبارات صافي الثروة اللحظية الشاملة (Net Worth)
  // ════════════════════════════════════════════════════════════════
  group('4. اختبارات صافي الثروة والمعادلة المحاسبية الصارمة', () {
    test('حساب صافي الثروة اللحظي بدقة تامة: الأصول الشاملة − الخصوم', () async {
      // 1. السيولة في الحسابات: 50,000 ر.س
      // 2. أصل رأسمالي: سيارة بقيمة 80,000 ر.س
      await controller.createAsset(
        title: 'سيارة',
        category: AssetCategory.vehicle,
        purchaseCost: Money.fromMajorUnits(80000.00),
        currentMarketValue: Money.fromMajorUnits(80000.00),
        purchaseDate: DateTime.now(),
      );

      // 3. دين مستحق للمستخدم (دين لي): 10,000 ر.س
      await controller.createDebt(
        title: 'سلفة لشخص',
        counterpartyName: 'أحمد',
        type: DebtType.receivable,
        totalAmount: Money.fromMajorUnits(10000.00),
        startDate: DateTime.now(),
      );

      // 4. دين مستحق على المستخدم (دين عليّ): 30,000 ر.س
      await controller.createDebt(
        title: 'قرض بنكي',
        counterpartyName: 'الراجحي',
        type: DebtType.payable,
        totalAmount: Money.fromMajorUnits(30000.00),
        startDate: DateTime.now(),
      );

      // إجمالي الأصول = 50,000 (سيولة) + 80,000 (أصل) + 10,000 (دين لي) = 140,000 ر.س
      expect(controller.state.totalOverallAssets, equals(Money.fromMajorUnits(140000.00)));

      // إجمالي الخصوم = 30,000 (دين عليّ)
      expect(controller.state.totalOverallLiabilities, equals(Money.fromMajorUnits(30000.00)));

      // صافي الثروة = 140,000 - 30,000 = 110,000 ر.س
      expect(controller.state.currentNetWorth, equals(Money.fromMajorUnits(110000.00)));
    });

    test('سداد دين يخفض السيولة ويخفض الخصوم بنفس المقدار، فيظل صافي الثروة متزناً', () async {
      // رصيد الحساب: 50,000 | دين عليّ: 10,000 -> صافي الثروة = 40,000
      await controller.createDebt(
        title: 'قرض شخصي',
        counterpartyName: 'صديق',
        type: DebtType.payable,
        totalAmount: Money.fromMajorUnits(10000.00),
        startDate: DateTime.now(),
      );

      expect(controller.state.currentNetWorth, equals(Money.fromMajorUnits(40000.00)));

      // سداد 5,000 من الدين
      await controller.payDebtInstallment(
        debtId: controller.state.debts.first.id,
        accountId: 'acc_main',
        amount: Money.fromMajorUnits(5000.00),
        paymentDate: DateTime.now(),
        idempotencyKey: 'idemp_debt_neutral',
      );

      // السيولة أصبحت 45,000، والدين أصبح 5,000
      // صافي الثروة = 45,000 - 5,000 = 40,000 (ثابت محاسبياً)
      expect(controller.state.liquidFunds, equals(Money.fromMajorUnits(45000.00)));
      expect(controller.state.totalPayableDebtsRemaining, equals(Money.fromMajorUnits(5000.00)));
      expect(controller.state.currentNetWorth, equals(Money.fromMajorUnits(40000.00)));
    });
  });
}

