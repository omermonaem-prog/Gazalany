import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/core/finance/money.dart';
import 'package:my_finance/features/financial_engine/application/central_financial_engine.dart';
import 'package:my_finance/features/financial_engine/data/repositories/in_memory_financial_engine_repository.dart';
import 'package:my_finance/features/financial_engine/domain/entities/account_entity.dart';
import 'package:my_finance/features/financial_engine/domain/entities/transaction_entity.dart';
import 'package:my_finance/features/expenses_budgets/application/expenses_budgets_controller.dart';
import 'package:my_finance/features/expenses_budgets/data/repositories/in_memory_expenses_budgets_repository.dart';
import 'package:my_finance/features/expenses_budgets/domain/entities/budget_warning_level.dart';
import 'package:my_finance/features/expenses_budgets/domain/entities/transaction_filter.dart';

void main() {
  late InMemoryFinancialEngineRepository engineRepo;
  late CentralFinancialEngine engine;
  late InMemoryExpensesBudgetsRepository expensesRepo;
  late ExpensesBudgetsController controller;

  setUp(() {
    engineRepo = InMemoryFinancialEngineRepository();
    engine = CentralFinancialEngine(repository: engineRepo);
    expensesRepo = InMemoryExpensesBudgetsRepository();
    controller = ExpensesBudgetsController(engine: engine, repository: expensesRepo);

    // حساب بنكي برصيد 10,000 ر.س
    engineRepo.accounts['acc_main'] = AccountEntity(
      id: 'acc_main',
      name: 'الحساب الرئيسي',
      type: AccountType.bank,
      currency: 'SAR',
      balance: Money.fromMajorUnits(10000.00),
      colorHex: '#0E3B2E',
      iconName: 'landmark',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    // أموال طوارئ وأهداف معزولة
    engineRepo.emergencyFundBalance = Money.fromMajorUnits(5000.00);
    engineRepo.goalBalances['goal_car'] = Money.fromMajorUnits(8000.00);
  });

  group('Phase 07 — نظام المصروفات والميزانيات وسجل المعاملات', () {
    // ── 1. اختبار إضافة المصروف وخصمه من الميزانية المحددة ───────
    test('1. إضافة مصروف: يخصم بدقة من الميزانية المحددة ويحدث المتبقي', () async {
      // إعداد ميزانية بقالة بمبلغ 1,500.00 ر.س
      await controller.createOrUpdateBudget(
        categoryId: 'cat_groceries',
        allocatedAmount: Money.fromMajorUnits(1500.00),
      );

      // تسجيل مصروف بقالة بقيمة 350.25 ر.س
      final success = await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_groceries',
        amount: Money.fromMajorUnits(350.25),
        date: DateTime.now(),
        description: 'شراء خضار ومؤونة',
        idempotencyKey: 'idemp-exp-01',
      );

      expect(success, isTrue);

      // التحقق من ميزانية البقالة
      final budget = controller.state.budgets.firstWhere((b) => b.categoryId == 'cat_groceries');
      expect(budget.spentAmount, equals(Money.fromMajorUnits(350.25)));
      expect(budget.remainingAmount, equals(Money.fromMajorUnits(1149.75))); // 1500 - 350.25

      // التحقق من رصيد الحساب البنكي
      expect(engineRepo.accounts['acc_main']!.balance, equals(Money.fromMajorUnits(9649.75)));
    });

    // ── 2. اختبار تحديث السيولة المتاحة ─────────────────────────
    test('2. تحديث السيولة المتاحة: تساوي مجموع المتبقي في ميزانيات الإنفاق وتتناقص بالمصروف', () async {
      // إعداد ميزانيتين: بقالة 2000، ومطاعم 1000 -> الإجمالي المتبقي 3000 ر.س
      await controller.createOrUpdateBudget(
        categoryId: 'cat_groceries',
        allocatedAmount: Money.fromMajorUnits(2000.00),
      );
      await controller.createOrUpdateBudget(
        categoryId: 'cat_dining',
        allocatedAmount: Money.fromMajorUnits(1000.00),
      );

      expect(controller.state.availableBudgetLiquidity, equals(Money.fromMajorUnits(3000.00)));

      // صرف 500 ر.س من المطاعم
      await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_dining',
        amount: Money.fromMajorUnits(500.00),
        date: DateTime.now(),
        description: 'عشاء عمل',
        idempotencyKey: 'idemp-exp-liquidity',
      );

      // السيولة المتاحة تصبح: 2000 + (1000 - 500) = 2500 ر.س
      expect(controller.state.availableBudgetLiquidity, equals(Money.fromMajorUnits(2500.00)));
    });

    // ── 3. اختبار عدم التأثير على الادخار والطوارئ والأهداف ──────
    test('3. عزل الادخار والطوارئ والأهداف: المصروف لا يمس أي بند محجوز', () async {
      final initialEmergency = engineRepo.emergencyFundBalance;
      final initialGoal = engineRepo.goalBalances['goal_car']!;

      await controller.createOrUpdateBudget(
        categoryId: 'cat_transport',
        allocatedAmount: Money.fromMajorUnits(500.00),
      );

      await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_transport',
        amount: Money.fromMajorUnits(120.00),
        date: DateTime.now(),
        description: 'وقود سيارة',
        idempotencyKey: 'idemp-exp-isolated',
      );

      // الطوارئ والهدف لم يتغيرا إطلاقاً
      expect(engineRepo.emergencyFundBalance, equals(initialEmergency));
      expect(engineRepo.goalBalances['goal_car'], equals(initialGoal));
    });

    // ── 4. اختبار منع المصروف غير الصالح ─────────────────────────
    test('4. منع المصروف غير الصالح: رفض المبالغ الصفرية أو السالبة أو الحساب غير الكافي', () async {
      // إعداد حساب فقير برصيد 50 ر.س فقط
      engineRepo.accounts['acc_poor'] = AccountEntity(
        id: 'acc_poor',
        name: 'كاش',
        type: AccountType.cash,
        balance: Money.fromMajorUnits(50.00),
        colorHex: '#000000',
        iconName: 'wallet',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await controller.createOrUpdateBudget(
        categoryId: 'cat_bills',
        allocatedAmount: Money.fromMajorUnits(1000.00),
      );

      // 1. رفض مبلغ صفري
      final zeroSuccess = await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_bills',
        amount: const Money.zero(),
        date: DateTime.now(),
        description: 'صفر',
        idempotencyKey: 'key-zero',
      );
      expect(zeroSuccess, isFalse);

      // 2. رفض مبلغ سالب
      final negSuccess = await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_bills',
        amount: Money.fromMajorUnits(-50.00),
        date: DateTime.now(),
        description: 'سالب',
        idempotencyKey: 'key-neg',
      );
      expect(negSuccess, isFalse);

      // 3. رفض صرف يفوق رصيد الحساب (500 > 50)
      final poorSuccess = await controller.recordExpense(
        accountId: 'acc_poor',
        categoryId: 'cat_bills',
        amount: Money.fromMajorUnits(500.00),
        date: DateTime.now(),
        description: 'فاتورة كبيرة',
        idempotencyKey: 'key-poor',
      );
      expect(poorSuccess, isFalse);
    });

    // ── 5. اختبار مستويات التحذير والميزانية غير الكافية ──────────
    test('5. مستويات التحذير المالي: تنبيه عند 70%+، تحذير عند 90%+، وإنذار حرج عند التجاوز 100%+', () async {
      await controller.createOrUpdateBudget(
        categoryId: 'cat_dining',
        allocatedAmount: Money.fromMajorUnits(1000.00),
      );

      // صرف 750 ر.س (75% -> Cautionary)
      await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_dining',
        amount: Money.fromMajorUnits(750.00),
        date: DateTime.now(),
        description: 'غداء جماعي',
        idempotencyKey: 'key-75',
      );
      var b = controller.state.budgets.firstWhere((x) => x.categoryId == 'cat_dining');
      expect(b.warningLevel, equals(BudgetWarningLevel.cautionary));

      // صرف 180 ر.س أخرى (المجموع 930 = 93% -> Warning)
      await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_dining',
        amount: Money.fromMajorUnits(180.00),
        date: DateTime.now(),
        description: 'قهوة وحلوى',
        idempotencyKey: 'key-93',
      );
      b = controller.state.budgets.firstWhere((x) => x.categoryId == 'cat_dining');
      expect(b.warningLevel, equals(BudgetWarningLevel.warning));

      // صرف 100 ر.س أخرى (المجموع 1030 = 103% -> Exceeded)
      await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_dining',
        amount: Money.fromMajorUnits(100.00),
        date: DateTime.now(),
        description: 'تجاوز الحد',
        idempotencyKey: 'key-103',
        allowExceeding: true,
      );
      b = controller.state.budgets.firstWhere((x) => x.categoryId == 'cat_dining');
      expect(b.warningLevel, equals(BudgetWarningLevel.exceeded));
      expect(b.isExceeded, isTrue);
    });

    // ── 6. اختبار البحث والتصفية في سجل المعاملات ────────────────
    test('6. البحث والتصفية: دعم البحث بالنص، التصنيف، ونطاق المبالغ', () async {
      await controller.createOrUpdateBudget(
        categoryId: 'cat_groceries',
        allocatedAmount: Money.fromMajorUnits(5000.00),
      );
      await controller.createOrUpdateBudget(
        categoryId: 'cat_health',
        allocatedAmount: Money.fromMajorUnits(2000.00),
      );

      await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_groceries',
        amount: Money.fromMajorUnits(80.00),
        date: DateTime.now(),
        description: 'حليب وأجبان',
        idempotencyKey: 'f-1',
      );

      await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_groceries',
        amount: Money.fromMajorUnits(300.00),
        date: DateTime.now(),
        description: 'لحوم وأسماك',
        idempotencyKey: 'f-2',
      );

      await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_health',
        amount: Money.fromMajorUnits(150.00),
        date: DateTime.now(),
        description: 'أدوية صيدلية',
        idempotencyKey: 'f-3',
      );

      // تصفية بالبحث النصي عن "حليب"
      controller.applyFilter(const TransactionFilter(searchQuery: 'حليب'));
      expect(controller.state.expenses.length, equals(1));
      expect(controller.state.expenses.first.description, equals('حليب وأجبان'));

      // تصفية بتصنيف الصحة
      controller.applyFilter(const TransactionFilter(categoryId: 'cat_health'));
      expect(controller.state.expenses.length, equals(1));
      expect(controller.state.expenses.first.description, equals('أدوية صيدلية'));

      // تصفية بالمبلغ (بين 200 و 500 ر.س)
      controller.applyFilter(TransactionFilter(
        minAmount: Money.fromMajorUnits(200.00),
        maxAmount: Money.fromMajorUnits(500.00),
      ));
      expect(controller.state.expenses.length, equals(1));
      expect(controller.state.expenses.first.description, equals('لحوم وأسماك'));
    });

    // ── 7. اختبار تعديل وتصحيح المعاملة وفق السياسة المحاسبية ─────
    test('7. تعديل المصروف: يعكس المصروف القديم ويثبت المصحح ويسوي أرصدة الميزانيات بدقة', () async {
      await controller.createOrUpdateBudget(
        categoryId: 'cat_groceries',
        allocatedAmount: Money.fromMajorUnits(1000.00),
      );
      await controller.createOrUpdateBudget(
        categoryId: 'cat_dining',
        allocatedAmount: Money.fromMajorUnits(1000.00),
      );

      // خطأ: تسجيل 400 ر.س على البقالة بدلاً من المطاعم
      await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_groceries',
        amount: Money.fromMajorUnits(400.00),
        date: DateTime.now(),
        description: 'عشاء فاخر (مسجل خطأ كبقالة)',
        idempotencyKey: 'exp-wrong-cat',
      );

      final originalExp = controller.state.expenses.first;
      expect(originalExp.amount, equals(Money.fromMajorUnits(400.00)));

      // تصحيح: تغيير التصنيف إلى مطاعم والمبلغ إلى 350 ر.س
      final correctSuccess = await controller.correctExpense(
        originalExpenseId: originalExp.id,
        newAmount: Money.fromMajorUnits(350.00),
        newCategoryId: 'cat_dining',
        newDescription: 'عشاء مطعم مصحح',
        reason: 'تصحيح التصنيف وتعديل الفاتورة الصحيحة',
        idempotencyKey: 'exp-correct-key',
      );

      expect(correctSuccess, isTrue);

      // 1. ميزانية البقالة القديمة استعادت الـ 400 ر.س (المصروف عليها أصبح 0)
      final groceryBudget = controller.state.budgets.firstWhere((b) => b.categoryId == 'cat_groceries');
      expect(groceryBudget.spentAmount, equals(const Money.zero()));

      // 2. ميزانية المطاعم خُصم منها 350 ر.س المصححة
      final diningBudget = controller.state.budgets.firstWhere((b) => b.categoryId == 'cat_dining');
      expect(diningBudget.spentAmount, equals(Money.fromMajorUnits(350.00)));

      // 3. المعاملة القديمة أصبحت reversed والمعاملة الجديدة corrected
      final oldExp = await expensesRepo.getExpenseById(originalExp.id);
      expect(oldExp!.status, equals(TransactionStatus.reversed));
    });

    // ── 8. اختبار حالات الميزانية المنتهية وغير المستخدمة ────────
    test('8. حالات الميزانية: تمييز الميزانية غير المستخدمة والميزانية المستنفذة', () async {
      await controller.createOrUpdateBudget(
        categoryId: 'cat_transport',
        allocatedAmount: Money.fromMajorUnits(500.00),
      );

      var b = controller.state.budgets.firstWhere((x) => x.categoryId == 'cat_transport');
      expect(b.isUnused, isTrue);
      expect(b.isDepleted, isFalse);

      // استهلاك كامل الميزانية (500 من 500)
      await controller.recordExpense(
        accountId: 'acc_main',
        categoryId: 'cat_transport',
        amount: Money.fromMajorUnits(500.00),
        date: DateTime.now(),
        description: 'اشتراك قطار شهري',
        idempotencyKey: 'key-full-deplete',
      );

      b = controller.state.budgets.firstWhere((x) => x.categoryId == 'cat_transport');
      expect(b.isUnused, isFalse);
      expect(b.isDepleted, isTrue);
      expect(b.remainingAmount.isZero, isTrue);
    });
  });
}

