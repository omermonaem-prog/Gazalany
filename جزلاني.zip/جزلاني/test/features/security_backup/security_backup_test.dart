import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/features/security_backup/application/security_backup_controller.dart';
import 'package:my_finance/features/security_backup/application/services/app_lock_service.dart';
import 'package:my_finance/features/security_backup/application/services/data_integrity_verifier.dart';
import 'package:my_finance/features/security_backup/data/repositories/in_memory_security_backup_repository.dart';
import 'package:my_finance/features/security_backup/domain/entities/app_lock_config.dart';
import 'package:my_finance/features/security_backup/domain/entities/backup_payload.dart';

void main() {
  late InMemorySecurityBackupRepository repository;
  late SecurityBackupController controller;

  setUp(() {
    repository = InMemorySecurityBackupRepository();
    controller = SecurityBackupController(repository: repository);
  });

  // ════════════════════════════════════════════════════════════════
  // 1. اختبارات أمان وقفل التطبيق وتشفير PIN
  // ════════════════════════════════════════════════════════════════
  group('1. اختبارات أمان وقفل التطبيق وتشفير PIN', () {
    test('تشفير رمز PIN بتقنية SHA-256 واستخدام ملح أمني عشوائي', () {
      final salt1 = AppLockService.generateSalt();
      final salt2 = AppLockService.generateSalt();

      expect(salt1, isNot(equals(salt2)));

      final hash1 = AppLockService.hashPin('1234', salt1);
      final hash2 = AppLockService.hashPin('1234', salt2);

      // حتى لو كان الرمز نفسه، الملح الأمني يضمن اختلاف التجزئة
      expect(hash1, isNot(equals(hash2)));
      expect(hash1.length, equals(64)); // 64 hex characters for SHA-256
    });

    test('تفعيل قفل التطبيق وفتحه بنجاح بالرمز الصحيح', () async {
      final success = await controller.enablePinLock('1234');
      expect(success, isTrue);
      expect(controller.state.lockConfig.isLockEnabled, isTrue);

      // فتح القفل بالرمز الصحيح
      final unlocked = controller.unlockWithPin('1234');
      expect(unlocked, isTrue);
      expect(controller.state.isAppLocked, isFalse);
      expect(controller.state.lockConfig.failedAttempts, equals(0));
    });

    test('تسجيل المحاولات الخاطئة والحظر المؤقت بعد 5 محاولات فاشلة', () async {
      await controller.enablePinLock('5678');

      // 4 محاولات خاطئة
      for (var i = 1; i <= 4; i++) {
        final unlocked = controller.unlockWithPin('0000');
        expect(unlocked, isFalse);
        expect(controller.state.lockConfig.failedAttempts, equals(i));
        expect(controller.state.lockConfig.isTemporarilyLocked, isFalse);
      }

      // المحاولة الخامسة الخاطئة تؤدي إلى الحظر المؤقت
      final fifthTry = controller.unlockWithPin('0000');
      expect(fifthTry, isFalse);
      expect(controller.state.lockConfig.failedAttempts, equals(5));
      expect(controller.state.lockConfig.isTemporarilyLocked, isTrue);

      // محاولة الإدخال أثناء الحظر مرفوضة
      final duringLockout = controller.unlockWithPin('5678');
      expect(duringLockout, isFalse);
      expect(controller.state.errorMessage, contains('محظور مؤقتاً'));
    });

    test('التحقق من مهلة القفل التلقائي (Auto-Lock Timeout)', () {
      final now = DateTime.now();

      // مهلة فورية (0 ثوانٍ)
      const configImmediate = AppLockConfig(
        isLockEnabled: true,
        pinHash: 'hash',
        autoLockTimeoutSeconds: 0,
      );
      expect(configImmediate.shouldLockNow(now), isTrue);

      // مهلة 5 دقائق (300 ثانية) ولم يمضِ سوى دقيقة
      final config5Min = AppLockConfig(
        isLockEnabled: true,
        pinHash: 'hash',
        autoLockTimeoutSeconds: 300,
        lastActiveTimestamp: now.subtract(const Duration(minutes: 1)),
      );
      expect(config5Min.shouldLockNow(now), isFalse);

      // مهلة 5 دقائق ومضى 6 دقائق -> يستحق القفل
      final configExpired = AppLockConfig(
        isLockEnabled: true,
        pinHash: 'hash',
        autoLockTimeoutSeconds: 300,
        lastActiveTimestamp: now.subtract(const Duration(minutes: 6)),
      );
      expect(configExpired.shouldLockNow(now), isTrue);
    });

    test('إلغاء قفل التطبيق يتطلب رمز PIN الحالي الصحيح', () async {
      await controller.enablePinLock('9999');

      // محاولة الإلغاء برمز خاطئ
      final failDisable = await controller.disablePinLock('1111');
      expect(failDisable, isFalse);
      expect(controller.state.lockConfig.isLockEnabled, isTrue);

      // الإلغاء بالرمز الصحيح
      final successDisable = await controller.disablePinLock('9999');
      expect(successDisable, isTrue);
      expect(controller.state.lockConfig.isLockEnabled, isFalse);
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 2. اختبارات النسخ الاحتياطي وبصمة SHA-256
  // ════════════════════════════════════════════════════════════════
  group('2. اختبارات إنشاء النسخ الاحتياطي وبصمة السلامة', () {
    test('إنشاء نسخة احتياطية وتوليد بصمة SHA-256 وحفظ البيانات الوصفية', () async {
      final payload = await controller.createManualBackup();

      expect(payload, isNotNull);
      expect(payload!.metadata.schemaVersion, equals(1));
      expect(payload.metadata.checksumSha256.length, equals(64));
      expect(payload.metadata.sizeInBytes, greaterThan(0));
      expect(payload.data['accounts'], isNotNull);
      expect(payload.data['transactions'], isNotNull);

      // التحقق من أن بصمة التجزئة مطابقة تماماً للمحتوى
      final dataJson = json.encode(payload.data);
      final isValid = DataIntegrityVerifier.verifyChecksum(
        data: dataJson,
        expectedChecksum: payload.metadata.checksumSha256,
      );
      expect(isValid, isTrue);
    });

    test('تسلسل وإلغاء تسلسل النسخة الاحتياطية بصيغة JSON دون فقدان البيانات', () async {
      final payload = await controller.createManualBackup();
      final jsonStr = payload!.toJsonString();

      // إعادة القراءة من JSON
      final parsed = BackupPayload.fromJsonString(jsonStr);
      expect(parsed.metadata.id, equals(payload.metadata.id));
      expect(parsed.metadata.checksumSha256, equals(payload.metadata.checksumSha256));
      expect(parsed.data['accounts'], equals(payload.data['accounts']));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 3. اختبارات الاستعادة والتحقق قبل الاستبدال (Restore Integrity)
  // ════════════════════════════════════════════════════════════════
  group('3. اختبارات الاستعادة والتحقق من سلامة الملفات', () {
    test('استعادة ناجحة لنسخة احتياطية سليمة', () async {
      final payload = await controller.createManualBackup();

      // تعديل البيانات الحالية
      repository.simulatedAppData['accounts'] = [];

      // تنفيذ الاستعادة
      final restoreSuccess = await controller.restoreBackup(payload!.metadata.id);
      expect(restoreSuccess, isTrue);

      // التأكد من استعادة الحسابات
      expect(repository.simulatedAppData['accounts'], isNotEmpty);
      expect(controller.state.successMessage, contains('تمت استعادة البيانات بنجاح'));
    });

    test('رفض استعادة أي نسخة احتياطية تم التلاعب بها أو تالفة (كشف التلاعب)', () async {
      final payload = await controller.createManualBackup();

      // محاكاة تلاعب في البيانات (Tampering) مع إبقاء البصمة القديمة
      final tamperedData = Map<String, dynamic>.from(payload!.data);
      tamperedData['generalSavingsMinorUnits'] = 999999999; // تغيير الرصيد بدون تحديث البصمة

      final tamperedPayload = BackupPayload(
        metadata: payload.metadata,
        data: tamperedData,
      );

      // محاولة استعادة النسخة المتلاعب بها
      expect(
        () => repository.restoreFromPayload(tamperedPayload),
        throwsA(isA<ArgumentError>().having(
          (e) => e.message,
          'message',
          contains('فشل فحص السلامة'),
        )),
      );
    });

    test('رفض استعادة نسخة احتياطية ذات إصدار مخطط غير متوافق (Schema Version mismatch)', () async {
      final payload = await controller.createManualBackup();

      // محاكاة نسخة من إصدار مستقبلي أعلى من إصدار التطبيق الحالي
      final futureMetadata = payload!.metadata;
      final incompatiblePayload = BackupPayload(
        metadata: futureMetadata,
        data: payload.data,
      );

      // إصدار schemaVersion = 99
      final jsonMap = json.decode(incompatiblePayload.toJsonString()) as Map<String, dynamic>;
      (jsonMap['header'] as Map<String, dynamic>)['schemaVersion'] = 99;

      final parsedFuturePayload = BackupPayload.fromJsonString(json.encode(jsonMap));

      expect(
        () => repository.restoreFromPayload(parsedFuturePayload),
        throwsA(isA<ArgumentError>().having(
          (e) => e.message,
          'message',
          contains('أحدث من الإصدار الحالي'),
        )),
      );
    });
  });
}

