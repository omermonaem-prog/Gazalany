import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_finance/main.dart';

void main() {
  testWidgets('فحص سلامة بناء التطبيق وتحميل الأساس التقني وRTL', (WidgetTester tester) async {
    // بناء التطبيق داخل ProviderScope
    await tester.pumpWidget(
      const ProviderScope(
        child: MyFinanceApp(),
      ),
    );

    // انتظار استقرار الواجهة
    await tester.pump();

    // التحقق من ظهور اسم التطبيق العربي
    expect(find.text('جزلاني'), findsOneWidget);

    // التحقق من وجود مؤشر جاهزية Riverpod
    expect(find.text('Riverpod جاهز ✓'), findsOneWidget);
  });
}

