// ignore_for_file: avoid_print

import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/core/database/app_database.dart';

void main() {
  group('DB-09 — مصفوفة الثوابت المالية (Financial Invariants)', () {
    late AppDatabase db;
    setUp(() => db = AppDatabase(NativeDatabase.memory()));
    tearDown(() => db.close());

    // ── INV-01: Zero-Sum Transfer ─────────────────────────────────
    test('INV-01 التحويل الداخلي: إجمالي الثروة ثابت قبل وبعد التحويل',
        () async {
      await db.accountsDao.insertAccount(_acc('a', 1000000));
      await db.accountsDao.insertAccount(_acc('b', 500000));
      final beforeTotal =
          await db.accountsDao.getTotalBalanceMinorUnits();

      await db.accountsDao.updateBalance('a', 700000);
      await db.accountsDao.updateBalance('b', 800000);

      final afterTotal = await db.accountsDao.getTotalBalanceMinorUnits();
      // الفرق = صفر (لأن التحويل فقط غيّر التوزيع لا المجموع)
      expect(afterTotal, equals(beforeTotal));
    });

    // ── INV-02: No Negative Balance ──────────────────────────────
    test('INV-02 لا يمكن سحب أكثر من الرصيد المتاح', () async {
      await db.accountsDao.insertAccount(_acc('x', 10000));
      // يجب أن تُطلق منطق التحقق قبل الوصول لقاعدة البيانات
      expect(
        () => _subtractAndAssert(db, 'x', 99999, 10000),
        throwsA(isA<AssertionError>()),
      );
    });

    // ── INV-03: Debt Payoff Reduces Remaining ────────────────────
    test('INV-03 سداد القسط: يخفض الرصيد المتبقي بالضبط', () async {
      await db.debtsDao.insertDebt(DebtsCompanion.insert(
        id: 'inv-debt',
        title: 'قرض',
        counterpartyName: 'شخص',
        type: 'payable',
        totalMinorUnits: 300000,
        remainingMinorUnits: 300000,
        startDate: DateTime.now(),
      ));
      await db.debtsDao.applyPayment('inv-debt', 100000);
      final debt = await db.debtsDao.getDebtById('inv-debt');
      expect(debt!.remainingMinorUnits, equals(200000));
      expect(debt.status, equals('active'));
      await db.debtsDao.applyPayment('inv-debt', 200000);
      final settled = await db.debtsDao.getDebtById('inv-debt');
      expect(settled!.status, equals('settled'));
    });

    // ── INV-04: Emergency Fund Isolation ─────────────────────────
    test('INV-04 صندوق الطوارئ: لا يتأثر بالمصروفات العادية', () async {
      await db.emergencyFundDao.upsertConfig(
        EmergencyFundConfigCompanion.insert(
          id: const Value('primary_fund'),
          targetMinorUnits: 100000,
          currentMinorUnits: const Value(80000),
        ),
      );
      await db.accountsDao.insertAccount(_acc('daily', 500000));
      await db.accountsDao.updateBalance('daily', 450000);

      // صندوق الطوارئ لم يتغير
      final fund = await db.emergencyFundDao.getConfig();
      expect(fund!.currentMinorUnits, equals(80000));
    });
  });
}

AccountsCompanion _acc(String id, int balance) =>
    AccountsCompanion.insert(
      id: id,
      name: 'acc-$id',
      type: 'bank',
      colorHex: '#0E3B2E',
      iconName: 'bank',
      balanceMinorUnits: Value(balance),
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

/// دالة مساعدة تُحاكي منطق التحقق على مستوى Use-Case
void _subtractAndAssert(
    AppDatabase db, String accountId, int amount, int currentBalance) {
  assert(amount <= currentBalance, 'رصيد غير كافٍ');
}

